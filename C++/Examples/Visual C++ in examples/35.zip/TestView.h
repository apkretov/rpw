#if !defined(AFX_TESTVIEW_H__CF9B27C0_EB68_45B3_93B4_318133213600__INCLUDED_)
#define AFX_TESTVIEW_H__CF9B27C0_EB68_45B3_93B4_318133213600__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// TestView.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// CTestView form view

#ifndef __AFXEXT_H__
#include <afxext.h>
#endif

#include "ExpertDoc.h"

class CTestView : public CFormView
{
protected:
	CTestView();           // protected constructor used by dynamic creation
	DECLARE_DYNCREATE(CTestView)

// Form Data
public:
	//{{AFX_DATA(CTestView)
	enum { IDD = IDD_TEST_FORM };
	CButton	m_BtnNo;
	CButton	m_BtnYes;
	CString	m_szValue;
	CString	m_szLabel;
	//}}AFX_DATA

// Attributes
public:
	int nIndex;

// Operations
public:
	void UpdateValue();

inline CExpertDoc* CTestView::GetDocument()
   { return (CExpertDoc*)m_pDocument; }

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CTestView)
	public:
	virtual void OnInitialUpdate();
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:
	virtual ~CTestView();
#ifdef _DEBUG
	virtual void AssertValid() const;
	virtual void Dump(CDumpContext& dc) const;
#endif

	// Generated message map functions
	//{{AFX_MSG(CTestView)
	afx_msg void OnBtnYes();
	afx_msg void OnBtnNo();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};


/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_TESTVIEW_H__CF9B27C0_EB68_45B3_93B4_318133213600__INCLUDED_)
