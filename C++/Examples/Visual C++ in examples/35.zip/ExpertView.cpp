// ExpertView.cpp : implementation of the CExpertView class
//

#include "stdafx.h"
#include "Expert.h"

#include "ExpertDoc.h"
#include "ExpertView.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CExpertView

IMPLEMENT_DYNCREATE(CExpertView, CFormView)

BEGIN_MESSAGE_MAP(CExpertView, CFormView)
	//{{AFX_MSG_MAP(CExpertView)
	ON_EN_CHANGE(IDC_VALUE1, OnChangeValue1)
	ON_EN_CHANGE(IDC_INDEX1, OnChangeIndex1)
	ON_EN_CHANGE(IDC_INDEX2, OnChangeIndex2)
	ON_EN_CHANGE(IDC_INDEX3, OnChangeIndex3)
	ON_BN_CLICKED(IDC_ANSWER, OnAnswer)
	//}}AFX_MSG_MAP
	// Standard printing commands
	ON_COMMAND(ID_FILE_PRINT, CFormView::OnFilePrint)
	ON_COMMAND(ID_FILE_PRINT_DIRECT, CFormView::OnFilePrint)
	ON_COMMAND(ID_FILE_PRINT_PREVIEW, CFormView::OnFilePrintPreview)
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CExpertView construction/destruction

CExpertView::CExpertView()
	: CFormView(CExpertView::IDD)
{
	//{{AFX_DATA_INIT(CExpertView)
	m_nIndex1 = 1;
	m_nIndex2 = 0;
	m_nIndex3 = 0;
	m_szValue1 = _T("");
	m_szValue2 = _T("");
	m_szValue3 = _T("");
	m_bAnswer = FALSE;
	//}}AFX_DATA_INIT
	// TODO: add construction code here

}

CExpertView::~CExpertView()
{
}

void CExpertView::DoDataExchange(CDataExchange* pDX)
{
	CFormView::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CExpertView)
	DDX_Control(pDX, IDC_SPIN3, m_Spin3);
	DDX_Control(pDX, IDC_SPIN2, m_Spin2);
	DDX_Control(pDX, IDC_SPIN1, m_Spin1);
	DDX_Text(pDX, IDC_INDEX1, m_nIndex1);
	DDX_Text(pDX, IDC_INDEX2, m_nIndex2);
	DDX_Text(pDX, IDC_INDEX3, m_nIndex3);
	DDX_Text(pDX, IDC_VALUE1, m_szValue1);
	DDX_Text(pDX, IDC_VALUE2, m_szValue2);
	DDX_Text(pDX, IDC_VALUE3, m_szValue3);
	DDX_Check(pDX, IDC_ANSWER, m_bAnswer);
	//}}AFX_DATA_MAP
}

BOOL CExpertView::PreCreateWindow(CREATESTRUCT& cs)
{
	// TODO: Modify the Window class or styles here by modifying
	//  the CREATESTRUCT cs

	return CFormView::PreCreateWindow(cs);
}

void CExpertView::OnInitialUpdate()
{
	CFormView::OnInitialUpdate();

	m_Spin1.SetRange(1, 2000);
	m_Spin2.SetRange(0, 2000);
	m_Spin3.SetRange(0, 2000);

	CExpertDoc *pDoc = GetDocument();

	m_nIndex2 = pDoc->vElem[m_nIndex1 - 1].yes + 1;
	m_nIndex3 = pDoc->vElem[m_nIndex1 - 1].no + 1;
	m_szValue1 = pDoc->vElem[m_nIndex1 - 1].value;
	m_bAnswer = pDoc->vElem[m_nIndex1 - 1].answer;

	if(m_nIndex2 > 0) 
	{
		if(pDoc->vElem.size() < m_nIndex2) m_szValue2 =  "����� ������";
		else m_szValue2 = pDoc->vElem[m_nIndex2 - 1].value;
	}
	else m_szValue2.Empty();

	if(m_nIndex3 > 0) 
	{
		if(pDoc->vElem.size() < m_nIndex3) m_szValue3 =  "����� ������";
		else m_szValue3 = pDoc->vElem[m_nIndex3 - 1].value;
	}
	else m_szValue3.Empty();

	UpdateData(FALSE);
}

/////////////////////////////////////////////////////////////////////////////
// CExpertView diagnostics

#ifdef _DEBUG
void CExpertView::AssertValid() const
{
	CFormView::AssertValid();
}

void CExpertView::Dump(CDumpContext& dc) const
{
	CFormView::Dump(dc);
}

CExpertDoc* CExpertView::GetDocument() // non-debug version is inline
{
	ASSERT(m_pDocument->IsKindOf(RUNTIME_CLASS(CExpertDoc)));
	return (CExpertDoc*)m_pDocument;
}
#endif //_DEBUG

/////////////////////////////////////////////////////////////////////////////
// CExpertView message handlers

void CExpertView::OnChangeValue1() 
{
	CExpertDoc *pDoc = GetDocument();

	if(pDoc == NULL || !IsWindowVisible()) return;
	UpdateData();
	
	if(pDoc->vElem.size() < m_nIndex1)
		pDoc->vElem.resize(m_nIndex1);
	
	pDoc->vElem[m_nIndex1 - 1].value = m_szValue1;
	pDoc->vElem[m_nIndex1 - 1].yes = m_nIndex2 - 1;
	pDoc->vElem[m_nIndex1 - 1].no = m_nIndex3 - 1;
	pDoc->vElem[m_nIndex1 - 1].answer = m_bAnswer;
	
	pDoc->SetModifiedFlag();
}

void CExpertView::OnChangeIndex1() 
{
	CExpertDoc *pDoc = GetDocument();

	if(pDoc == NULL || !IsWindowVisible()) return;
	UpdateData();
	
	if(m_nIndex1<1) return;

	if(pDoc->vElem.size() < m_nIndex1)
	{
		m_nIndex2 = 0;
		m_nIndex3 = 0;
		m_szValue1 = "����� ������";
		m_bAnswer = FALSE;
	}
	else
	{
		m_nIndex2 = pDoc->vElem[m_nIndex1 - 1].yes + 1;
		m_nIndex3 = pDoc->vElem[m_nIndex1 - 1].no + 1;
		m_szValue1 = pDoc->vElem[m_nIndex1 - 1].value;
		m_bAnswer = pDoc->vElem[m_nIndex1 - 1].answer;
	}
	
	if(m_nIndex2 > 0) 
	{
		if(pDoc->vElem.size() < m_nIndex2) m_szValue2 =  "����� ������";
		else m_szValue2 = pDoc->vElem[m_nIndex2 - 1].value;
	}
	else m_szValue2.Empty();

	if(m_nIndex3 > 0) 
	{
		if(pDoc->vElem.size() < m_nIndex3) m_szValue3 =  "����� ������";
		else m_szValue3 = pDoc->vElem[m_nIndex3 - 1].value;
	}
	else m_szValue3.Empty();

	UpdateData(FALSE);
}

void CExpertView::OnChangeIndex2() 
{
	CExpertDoc *pDoc = GetDocument();
	if(pDoc == NULL || !IsWindowVisible()) return;
	
	OnChangeValue1();
	
	if(m_nIndex2 > 0) 
	{
		if(pDoc->vElem.size() < m_nIndex2) m_szValue2 =  "����� ������";
		else m_szValue2 = pDoc->vElem[m_nIndex2 - 1].value;
	}
	else m_szValue2.Empty();
	UpdateData(FALSE);
}

void CExpertView::OnChangeIndex3() 
{
	CExpertDoc *pDoc = GetDocument();
	if(pDoc == NULL || !IsWindowVisible()) return;
	
	OnChangeValue1();
	
	if(m_nIndex3 > 0) 
	{
		if(pDoc->vElem.size() < m_nIndex3) m_szValue3 =  "����� ������";
		else m_szValue3 = pDoc->vElem[m_nIndex3 - 1].value;
	}
	else m_szValue3.Empty();
	UpdateData(FALSE);
}

void CExpertView::OnAnswer() 
{
	OnChangeValue1();
}
