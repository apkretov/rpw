// ExpertView.h : interface of the CExpertView class
//
/////////////////////////////////////////////////////////////////////////////

#if !defined(AFX_EXPERTVIEW_H__F308E8A4_E397_4E4F_BC14_CE696620EE36__INCLUDED_)
#define AFX_EXPERTVIEW_H__F308E8A4_E397_4E4F_BC14_CE696620EE36__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000


class CExpertView : public CFormView
{
protected: // create from serialization only
	CExpertView();
	DECLARE_DYNCREATE(CExpertView)

public:
	//{{AFX_DATA(CExpertView)
	enum { IDD = IDD_EXPERT_FORM };
	CSpinButtonCtrl	m_Spin3;
	CSpinButtonCtrl	m_Spin2;
	CSpinButtonCtrl	m_Spin1;
	int		m_nIndex1;
	int		m_nIndex2;
	int		m_nIndex3;
	CString	m_szValue1;
	CString	m_szValue2;
	CString	m_szValue3;
	BOOL	m_bAnswer;
	//}}AFX_DATA

// Attributes
public:
	CExpertDoc* GetDocument();

// Operations
public:

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CExpertView)
	public:
	virtual BOOL PreCreateWindow(CREATESTRUCT& cs);
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	virtual void OnInitialUpdate(); // called first time after construct
	//}}AFX_VIRTUAL

// Implementation
public:
	virtual ~CExpertView();
#ifdef _DEBUG
	virtual void AssertValid() const;
	virtual void Dump(CDumpContext& dc) const;
#endif

protected:

// Generated message map functions
protected:
	//{{AFX_MSG(CExpertView)
	afx_msg void OnChangeValue1();
	afx_msg void OnChangeIndex1();
	afx_msg void OnChangeIndex2();
	afx_msg void OnChangeIndex3();
	afx_msg void OnAnswer();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

#ifndef _DEBUG  // debug version in ExpertView.cpp
inline CExpertDoc* CExpertView::GetDocument()
   { return (CExpertDoc*)m_pDocument; }
#endif

/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_EXPERTVIEW_H__F308E8A4_E397_4E4F_BC14_CE696620EE36__INCLUDED_)
