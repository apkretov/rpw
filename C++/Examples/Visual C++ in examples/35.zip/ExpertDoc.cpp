// ExpertDoc.cpp : implementation of the CExpertDoc class
//

#include "stdafx.h"
#include "Expert.h"

#include "ExpertDoc.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CExpertDoc

IMPLEMENT_DYNCREATE(CExpertDoc, CDocument)

BEGIN_MESSAGE_MAP(CExpertDoc, CDocument)
	//{{AFX_MSG_MAP(CExpertDoc)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CExpertDoc construction/destruction

CExpertDoc::CExpertDoc()
{
	// TODO: add one-time construction code here

}

CExpertDoc::~CExpertDoc()
{
}

BOOL CExpertDoc::OnNewDocument()
{
	if (!CDocument::OnNewDocument())
		return FALSE;

	// TODO: add reinitialization code here
	// (SDI documents will reuse this document)

	vElem.push_back(elem());

	return TRUE;
}



/////////////////////////////////////////////////////////////////////////////
// CExpertDoc serialization

void CExpertDoc::Serialize(CArchive& ar)
{
	int i;
	if (ar.IsStoring())
	{
		ar << vElem.size();
		for(i=0; i<vElem.size(); i++)
		{
			ar << vElem[i].value;
			ar << vElem[i].yes;
			ar << vElem[i].no;
			ar << vElem[i].answer;
		}
	}
	else
	{
		int nSize;
		ar >> nSize;
		vElem.clear();
		vElem.resize(nSize);
		for(i=0; i<nSize; i++)
		{
			ar >> vElem[i].value;
			ar >> vElem[i].yes;
			ar >> vElem[i].no;
			ar >> vElem[i].answer;
		}
	}
}

/////////////////////////////////////////////////////////////////////////////
// CExpertDoc diagnostics

#ifdef _DEBUG
void CExpertDoc::AssertValid() const
{
	CDocument::AssertValid();
}

void CExpertDoc::Dump(CDumpContext& dc) const
{
	CDocument::Dump(dc);
}
#endif //_DEBUG

/////////////////////////////////////////////////////////////////////////////
// CExpertDoc commands
