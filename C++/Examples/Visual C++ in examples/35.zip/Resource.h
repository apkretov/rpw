//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by Expert.rc
//
#define IDD_ABOUTBOX                    100
#define IDD_EXPERT_FORM                 101
#define IDD_TEST_FORM                   102
#define IDR_MAINFRAME                   128
#define IDR_EXPERTTYPE                  129
#define IDR_TEST                        130
#define IDC_VALUE1                      1000
#define IDC_INDEX1                      1001
#define IDC_INDEX2                      1002
#define IDC_INDEX3                      1003
#define IDC_VALUE2                      1004
#define IDC_VALUE3                      1005
#define IDC_ANSWER                      1006
#define IDC_SPIN1                       1007
#define IDC_SPIN2                       1008
#define IDC_BTN_YES                     1008
#define IDC_SPIN3                       1009
#define IDC_BTN_NO                      1009
#define IDC_VALUE                       1010
#define IDC_STATIC1                     1011
#define ID_EXPERT_BEGINTEST             32771
#define ID_EXPERT_NEW                   32773

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_3D_CONTROLS                     1
#define _APS_NEXT_RESOURCE_VALUE        130
#define _APS_NEXT_COMMAND_VALUE         32774
#define _APS_NEXT_CONTROL_VALUE         1012
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
