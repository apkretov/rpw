// TestView.cpp : implementation file
//

#include "stdafx.h"
#include "Expert.h"
#include "TestView.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CTestView

IMPLEMENT_DYNCREATE(CTestView, CFormView)

CTestView::CTestView()
	: CFormView(CTestView::IDD)
{
	//{{AFX_DATA_INIT(CTestView)
	m_szValue = _T("");
	m_szLabel = _T("");
	//}}AFX_DATA_INIT
}

CTestView::~CTestView()
{
}

void CTestView::DoDataExchange(CDataExchange* pDX)
{
	CFormView::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CTestView)
	DDX_Control(pDX, IDC_BTN_NO, m_BtnNo);
	DDX_Control(pDX, IDC_BTN_YES, m_BtnYes);
	DDX_Text(pDX, IDC_VALUE, m_szValue);
	DDX_Text(pDX, IDC_STATIC1, m_szLabel);
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CTestView, CFormView)
	//{{AFX_MSG_MAP(CTestView)
	ON_BN_CLICKED(IDC_BTN_YES, OnBtnYes)
	ON_BN_CLICKED(IDC_BTN_NO, OnBtnNo)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CTestView diagnostics

#ifdef _DEBUG
void CTestView::AssertValid() const
{
	CFormView::AssertValid();
}

void CTestView::Dump(CDumpContext& dc) const
{
	CFormView::Dump(dc);
}
#endif //_DEBUG

/////////////////////////////////////////////////////////////////////////////
// CTestView message handlers

void CTestView::OnInitialUpdate() 
{
	CFormView::OnInitialUpdate();
	
	// TODO: Add your specialized code here and/or call the base class
	
	nIndex = 0;	
	m_szLabel = "������";
	UpdateValue();
}

void CTestView::OnBtnYes() 
{
	nIndex = GetDocument()->vElem[nIndex].yes;
	UpdateValue();	
}

void CTestView::UpdateValue()
{
	if(!GetDocument()->vElem[nIndex].yes) return;
	m_szValue = GetDocument()->vElem[nIndex].value;
	if(GetDocument()->vElem[nIndex].answer) 
	{
		m_szLabel = "����������";
		m_BtnYes.EnableWindow(FALSE);
		m_BtnNo.EnableWindow(FALSE);
	}
	UpdateData(FALSE);
}

void CTestView::OnBtnNo() 
{
	nIndex = GetDocument()->vElem[nIndex].no;
	UpdateValue();		
}
