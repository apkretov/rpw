// ExpertDoc.h : interface of the CExpertDoc class
//
/////////////////////////////////////////////////////////////////////////////

#if !defined(AFX_EXPERTDOC_H__F390F10A_A2A5_47F2_883B_06061F97672A__INCLUDED_)
#define AFX_EXPERTDOC_H__F390F10A_A2A5_47F2_883B_06061F97672A__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#include <vector>

using namespace std;

class elem
{
public:
	CString value;
	int yes, no;
	BOOL answer;
	elem()
	{
		value = "����� ������";
		yes = -1;
		no = -1;
		answer = FALSE;
	}
};


class CExpertDoc : public CDocument
{
protected: // create from serialization only
	CExpertDoc();
	DECLARE_DYNCREATE(CExpertDoc)

// Attributes
public:

	//int nSize;
	vector <elem> vElem;

// Operations
public:

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CExpertDoc)
	public:
	virtual BOOL OnNewDocument();
	virtual void Serialize(CArchive& ar);
	//}}AFX_VIRTUAL

// Implementation
public:
	virtual ~CExpertDoc();
#ifdef _DEBUG
	virtual void AssertValid() const;
	virtual void Dump(CDumpContext& dc) const;
#endif

protected:

// Generated message map functions
protected:
	//{{AFX_MSG(CExpertDoc)
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_EXPERTDOC_H__F390F10A_A2A5_47F2_883B_06061F97672A__INCLUDED_)
