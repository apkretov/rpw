// TestFrame.cpp : implementation file
//

#include "stdafx.h"
#include "Expert.h"
#include "TestFrame.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CTestFrame

IMPLEMENT_DYNCREATE(CTestFrame, CMDIChildWnd)

CTestFrame::CTestFrame()
{
}

CTestFrame::~CTestFrame()
{
}


BEGIN_MESSAGE_MAP(CTestFrame, CMDIChildWnd)
	//{{AFX_MSG_MAP(CTestFrame)
		// NOTE - the ClassWizard will add and remove mapping macros here.
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CTestFrame message handlers

BOOL CTestFrame::PreCreateWindow(CREATESTRUCT& cs) 
{
	// TODO: Add your specialized code here and/or call the base class

	cs.cx = 492;
	cs.cy = 205;
	
	return CMDIChildWnd::PreCreateWindow(cs);
}
