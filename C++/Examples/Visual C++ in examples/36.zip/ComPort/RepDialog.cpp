// RepDialog.cpp : implementation file
//

#include "stdafx.h"
#include "comport.h"
#include "RepDialog.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CRepDialog dialog


CRepDialog::CRepDialog(CWnd* pParent /*=NULL*/)
	: CDialog(CRepDialog::IDD, pParent)
{
	//{{AFX_DATA_INIT(CRepDialog)
	m_RepString = _T("");
	//}}AFX_DATA_INIT
}


void CRepDialog::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CRepDialog)
	DDX_Text(pDX, IDC_REPSTRING, m_RepString);
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CRepDialog, CDialog)
	//{{AFX_MSG_MAP(CRepDialog)
	ON_BN_CLICKED(IDC_BUTTONEXIT, OnButtonexit)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CRepDialog message handlers

void CRepDialog::OnButtonexit() 
{
	OnOK();	
}
