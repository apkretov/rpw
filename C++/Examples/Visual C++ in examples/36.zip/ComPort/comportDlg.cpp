// comportDlg.cpp : implementation file
//

#include "stdafx.h"
#include "comport.h"
#include "comportDlg.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CAboutDlg dialog used for App About

class CAboutDlg : public CDialog
{
public:
	CAboutDlg();

// Dialog Data
	//{{AFX_DATA(CAboutDlg)
	enum { IDD = IDD_ABOUTBOX };
	//}}AFX_DATA

	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CAboutDlg)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:
	//{{AFX_MSG(CAboutDlg)
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

CAboutDlg::CAboutDlg() : CDialog(CAboutDlg::IDD)
{
	//{{AFX_DATA_INIT(CAboutDlg)
	//}}AFX_DATA_INIT
}

void CAboutDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CAboutDlg)
	//}}AFX_DATA_MAP
}

BEGIN_MESSAGE_MAP(CAboutDlg, CDialog)
	//{{AFX_MSG_MAP(CAboutDlg)
		// No message handlers
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CComportDlg dialog

CComportDlg::CComportDlg(CWnd* pParent /*=NULL*/)
	: CDialog(CComportDlg::IDD, pParent)
{
	//{{AFX_DATA_INIT(CComportDlg)
		// NOTE: the ClassWizard will add member initialization here
	//}}AFX_DATA_INIT
	// Note that LoadIcon does not require a subsequent DestroyIcon in Win32
	m_hIcon = AfxGetApp()->LoadIcon(IDR_MAINFRAME);
}

void CComportDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CComportDlg)
		// NOTE: the ClassWizard will add DDX and DDV calls here
	//}}AFX_DATA_MAP
}

BEGIN_MESSAGE_MAP(CComportDlg, CDialog)
	//{{AFX_MSG_MAP(CComportDlg)
	ON_WM_SYSCOMMAND()
	ON_WM_PAINT()
	ON_WM_QUERYDRAGICON()
	ON_WM_TIMER()
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CComportDlg message handlers

BOOL CComportDlg::OnInitDialog()
{
	CDialog::OnInitDialog();

	// Add "About..." menu item to system menu.

	// IDM_ABOUTBOX must be in the system command range.
	ASSERT((IDM_ABOUTBOX & 0xFFF0) == IDM_ABOUTBOX);
	ASSERT(IDM_ABOUTBOX < 0xF000);

	CMenu* pSysMenu = GetSystemMenu(FALSE);
	if (pSysMenu != NULL)
	{
		CString strAboutMenu;
		strAboutMenu.LoadString(IDS_ABOUTBOX);
		if (!strAboutMenu.IsEmpty())
		{
			pSysMenu->AppendMenu(MF_SEPARATOR);
			pSysMenu->AppendMenu(MF_STRING, IDM_ABOUTBOX, strAboutMenu);
		}
	}

	// Set the icon for this dialog.  The framework does this automatically
	//  when the application's main window is not a dialog
	SetIcon(m_hIcon, TRUE);			// Set big icon
	SetIcon(m_hIcon, FALSE);		// Set small icon
	
	bIniError = FALSE;
	//��������� ������ �� INI-�����
	CString sBaudRate=ReadIni("settings","BaudRate");
	CString sByteSize=ReadIni("settings","ByteSize");
	CString sReadIntervalTimeout=ReadIni("settings","ReadIntervalTimeout");
	CString sReadTotalTimeoutConstant=ReadIni("settings","ReadTotalTimeoutConstant");
	CString sReadTotalTimeoutMultiplier=ReadIni("settings","ReadTotalTimeoutMultiplier");
	CString sWriteTotalTimeoutConstant=ReadIni("settings","WriteTotalTimeoutConstant");
	CString sWriteTotalTimeoutMultiplier=ReadIni("settings","WriteTotalTimeoutMultiplier");
	sFirstCommand=ReadIni("settings","FirstCommand");
	sSecondCommand=ReadIni("settings","SecondCommand");
	if(bIniError)
	{
		AfxMessageBox("������ � INI-�����!", MB_OK | MB_ICONSTOP, 0);
		OnOK();
		return FALSE;
	}
	//���� ��� ���������, ��������� ������ � �������� ���������
	nBaudRate=atoi(sBaudRate);
	nByteSize=atoi(sByteSize);
	nReadIntervalTimeout=atoi(sReadIntervalTimeout);
	nReadTotalTimeoutConstant=atoi(sReadTotalTimeoutConstant);
	nReadTotalTimeoutMultiplier=atoi(sReadTotalTimeoutMultiplier);
	nWriteTotalTimeoutConstant=atoi(sWriteTotalTimeoutConstant);
	nWriteTotalTimeoutMultiplier=atoi(sWriteTotalTimeoutMultiplier);
	SetModem(); //����������� �����
	
	return TRUE;  // return TRUE  unless you set the focus to a control
}

void CComportDlg::OnSysCommand(UINT nID, LPARAM lParam)
{
	if ((nID & 0xFFF0) == IDM_ABOUTBOX)
	{
		CAboutDlg dlgAbout;
		dlgAbout.DoModal();
	}
	else
	{
		CDialog::OnSysCommand(nID, lParam);
	}
}

// If you add a minimize button to your dialog, you will need the code below
//  to draw the icon.  For MFC applications using the document/view model,
//  this is automatically done for you by the framework.

void CComportDlg::OnPaint() 
{
	if (IsIconic())
	{
		CPaintDC dc(this); // device context for painting

		SendMessage(WM_ICONERASEBKGND, (WPARAM) dc.GetSafeHdc(), 0);

		// Center icon in client rectangle
		int cxIcon = GetSystemMetrics(SM_CXICON);
		int cyIcon = GetSystemMetrics(SM_CYICON);
		CRect rect;
		GetClientRect(&rect);
		int x = (rect.Width() - cxIcon + 1) / 2;
		int y = (rect.Height() - cyIcon + 1) / 2;

		// Draw the icon
		dc.DrawIcon(x, y, m_hIcon);
	}
	else
	{
		CDialog::OnPaint();
	}
}

// The system calls this to obtain the cursor to display while the user drags
//  the minimized window.
HCURSOR CComportDlg::OnQueryDragIcon()
{
	return (HCURSOR) m_hIcon;
}

CString CComportDlg::ReadIni(CString strSect, CString strKey)
{
	//��������� �������� �� INI-�����
	GetCurrentDirectory(MAX_BUF,(char*)sBuffer);
	CString strIniPath=(CString)sBuffer+"\\comport.ini";
	GetPrivateProfileString(strSect,strKey,"inifile_error",sBuffer,sizeof(sBuffer),strIniPath);
	CString strIniString=(CString)sBuffer;
	if(strIniString=="inifile_error") bIniError=TRUE;
	return strIniString;
}

void CComportDlg::SetModem() //����������� �����
{
	BOOL bResult = TRUE;
	m_sComPort = "Com1";
	m_hCom = CreateFile(m_sComPort, 
		GENERIC_READ | GENERIC_WRITE,
		0, // ������������ ������
		NULL, // ������� ������������ :-)
		OPEN_EXISTING,
		0,
		NULL);

	m_bPortReady = SetupComm(m_hCom, 128, 128); // ��������� ������� ������
	m_bPortReady = GetCommState(m_hCom, &m_dcb);
	m_dcb.BaudRate = nBaudRate; //38400
	m_dcb.ByteSize = nByteSize; //8
	m_dcb.Parity = NOPARITY;
	m_dcb.StopBits = ONESTOPBIT;
	m_dcb.fAbortOnError = TRUE;
	m_bPortReady = SetCommState(m_hCom, &m_dcb);

	m_bPortReady = GetCommTimeouts (m_hCom, &m_CommTimeouts);
	m_CommTimeouts.ReadIntervalTimeout = nReadIntervalTimeout; //50
	m_CommTimeouts.ReadTotalTimeoutConstant = nReadTotalTimeoutConstant; //50
	m_CommTimeouts.ReadTotalTimeoutMultiplier = nReadTotalTimeoutMultiplier; //10
	m_CommTimeouts.WriteTotalTimeoutConstant = nWriteTotalTimeoutConstant; //50
	m_CommTimeouts.WriteTotalTimeoutMultiplier = nWriteTotalTimeoutMultiplier; //10
	m_bPortReady = SetCommTimeouts (m_hCom, &m_CommTimeouts);
	sFirstCommand+="\r"; //AT&ATQ0
	sSecondCommand+="\r"; //ATS7=20

	//������ �������
	bWriteRC = WriteFile(m_hCom, (LPCVOID) sFirstCommand, 8, &iBytesWritten, NULL);
	ReadPortData(); //��������� �����
	if(sPortValue.Find("OK", 0) != -1) //���� ��������� "��" ��� "0"
	{
		//������ ������� (���� �����)
		bWriteRC = WriteFile(m_hCom, (LPCVOID) sSecondCommand, 8, &iBytesWritten, NULL);
		ReadPortData();
		if(sPortValue.Find("OK", 0) == -1) bResult = FALSE;
	}
	else bResult = FALSE;
	//��������� ����� ������
	if(bResult) dlgRep.m_RepString="Modem initialization is OK";
		else dlgRep.m_RepString="Modem initialization error occur";
	
	CloseHandle(m_hCom);
	m_uTimerID = SetTimer(0x451,1000,NULL);
	dlgRep.DoModal(); //���� � ���������� � ����������
}

void CComportDlg::ReadPortData()
{
	//��������� ������ �� �����
	Sleep(100);
	bReadRC = ReadFile(m_hCom, &sBuffer, 8, &iBytesRead, NULL);
	bReadRC = ReadFile(m_hCom, &sBuffer, 8, &iBytesRead, NULL);
	sPortValue = (CString) sBuffer;
}

void CComportDlg::OnTimer(UINT nIDEvent)
{
	//������� ���� � ����������
	CDialog::OnTimer(nIDEvent);
	KillTimer(m_uTimerID);
	CDialog::OnOK();
	dlgRep.CloseWindow();
	dlgRep.OnButtonexit();
}
