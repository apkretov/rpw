// comportDlg.h : header file
//

#if !defined(AFX_COMPORTDLG_H__8C8E1B87_58FA_11D6_89E3_000423014B27__INCLUDED_)
#define AFX_COMPORTDLG_H__8C8E1B87_58FA_11D6_89E3_000423014B27__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#include "RepDialog.h"
#define MAX_BUF 2048

/////////////////////////////////////////////////////////////////////////////
// CComportDlg dialog

class CComportDlg : public CDialog
{
// Construction
public:
	CComportDlg(CWnd* pParent = NULL);	// standard constructor
	void ReadPortData();
	void SetModem();
	CString ReadIni(CString strSect, CString strKey);
	//variables reference
	BOOL	m_bPortReady;
	HANDLE	m_hCom;
	CString	m_sComPort;
	DCB		m_dcb;
	COMMTIMEOUTS	m_CommTimeouts;
	BOOL	bWriteRC, bReadRC;
	DWORD	iBytesWritten;
	DWORD	iBytesRead;
	char	sBuffer[MAX_BUF];
	CString	sPortValue;
	CRepDialog dlgRep;
	BOOL	bIniError;
	DWORD	nBaudRate, nByteSize, nReadIntervalTimeout,
			nReadTotalTimeoutConstant, nReadTotalTimeoutMultiplier,
			nWriteTotalTimeoutConstant, nWriteTotalTimeoutMultiplier;
	CString	sFirstCommand, sSecondCommand;

// Dialog Data
	//{{AFX_DATA(CComportDlg)
	enum { IDD = IDD_COMPORT_DIALOG };
		// NOTE: the ClassWizard will add data members here
	//}}AFX_DATA

	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CComportDlg)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);	// DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:
	HICON m_hIcon;
	UINT m_uTimerID;

	// Generated message map functions
	//{{AFX_MSG(CComportDlg)
	virtual BOOL OnInitDialog();
	afx_msg void OnSysCommand(UINT nID, LPARAM lParam);
	afx_msg void OnPaint();
	afx_msg HCURSOR OnQueryDragIcon();
	afx_msg void OnTimer(UINT nIDEvent);
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_COMPORTDLG_H__8C8E1B87_58FA_11D6_89E3_000423014B27__INCLUDED_)
