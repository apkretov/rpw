#if !defined(AFX_REPDIALOG_H__009F7605_5904_11D6_89E3_000423014B27__INCLUDED_)
#define AFX_REPDIALOG_H__009F7605_5904_11D6_89E3_000423014B27__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// RepDialog.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// CRepDialog dialog

class CRepDialog : public CDialog
{
// Construction
public:
	CRepDialog(CWnd* pParent = NULL);   // standard constructor
	void OnButtonexit();

// Dialog Data
	//{{AFX_DATA(CRepDialog)
	enum { IDD = IDD_REPORTDIALOG };
	CString	m_RepString;
	//}}AFX_DATA


// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CRepDialog)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:

	// Generated message map functions
	//{{AFX_MSG(CRepDialog)
	//afx_msg void OnButtonexit();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_REPDIALOG_H__009F7605_5904_11D6_89E3_000423014B27__INCLUDED_)
