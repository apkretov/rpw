// testscr.cpp : Defines the entry point for the application.
//

#include "stdafx.h"
#include "resource.h"

#define MAX_LOADSTRING 100
#define MAX_BUF 2048

// Global Variables:
HINSTANCE hInst;								// current instance
TCHAR szTitle[MAX_LOADSTRING];					// ��������� ����
TCHAR szWindowClass[MAX_LOADSTRING];			
int iLastX, iLastY;
BOOL bPlusX, bPlusY;
char szPassword[MAX_BUF];
char szRealPsw[MAX_BUF];
char szAdminPsw[MAX_BUF];
char *stopstring;

// Foward declarations of functions included in this code module:
ATOM				MyRegisterClass(HINSTANCE hInstance);
BOOL				InitInstance(HINSTANCE, int);
LRESULT CALLBACK	WndProc(HWND, UINT, WPARAM, LPARAM);

int APIENTRY WinMain(HINSTANCE hInstance,
                     HINSTANCE hPrevInstance,
                     LPSTR     lpCmdLine,
                     int       nCmdShow)
{
	MSG msg;
	HACCEL hAccelTable;
	// Initialize global strings
	LoadString(hInstance, IDS_APP_TITLE, szTitle, MAX_LOADSTRING);
	LoadString(hInstance, IDC_TESTSCR, szWindowClass, MAX_LOADSTRING);
	MyRegisterClass(hInstance);
	// Perform application initialization:
	if (FindWindow(NULL,szTitle) != NULL)
		return FALSE;
	if (!InitInstance (hInstance, nCmdShow)) 
		return FALSE;
	hAccelTable = LoadAccelerators(hInstance, (LPCTSTR)IDC_TESTSCR);
	// Main message loop:
	while (GetMessage(&msg, NULL, 0, 0)) 
	{
		if (!TranslateAccelerator(msg.hwnd, hAccelTable, &msg)) 
		{
			TranslateMessage(&msg);
			DispatchMessage(&msg);
		}
	}
	return msg.wParam;
}

ATOM MyRegisterClass(HINSTANCE hInstance)
{
	WNDCLASSEX wcex;
	wcex.cbSize = sizeof(WNDCLASSEX); 
	wcex.style			= CS_HREDRAW | CS_VREDRAW;
	wcex.hbrBackground	= CreateSolidBrush(BLACK_BRUSH);
	wcex.lpfnWndProc	= (WNDPROC)WndProc;
	wcex.cbClsExtra		= 0;
	wcex.cbWndExtra		= 0;
	wcex.style          = CS_VREDRAW | CS_HREDRAW | CS_SAVEBITS | CS_DBLCLKS;
	wcex.hInstance		= hInstance;
	wcex.hIcon			= LoadIcon(hInstance, NULL);
	wcex.hCursor		= LoadCursor(NULL, NULL);
	wcex.lpszMenuName	= (LPCSTR)IDC_TESTSCR;
	wcex.lpszClassName	= szWindowClass;
	wcex.hIconSm		= LoadIcon(wcex.hInstance, (LPCTSTR)IDI_SMALL);
	return RegisterClassEx(&wcex);
}

BOOL InitInstance(HINSTANCE hInstance, int nCmdShow)
{
   HWND hWnd;
   hInst = hInstance; // Store instance handle in our global variable
   hWnd = CreateWindow(szWindowClass,
	   szTitle, WS_POPUPWINDOW,
	   0, 0, 
	   ::GetSystemMetrics(SM_CXSCREEN),
	   ::GetSystemMetrics(SM_CYSCREEN),
	   NULL, NULL, hInstance, NULL);
   if (!hWnd)
   {
      return FALSE;
   }
   ShowWindow(hWnd, nCmdShow);
   UpdateWindow(hWnd);
   return TRUE;
}

LRESULT CALLBACK WndProc(HWND hWnd, UINT message, WPARAM wParam, LPARAM lParam)
{
	static UINT uTimer;
	static PAINTSTRUCT ps;
	static HDC hdc, hMemDC;
	static HBITMAP bmLogo;
	switch (message) 
	{
		case WM_DESTROY:
			PostQuitMessage(0);
			break;
		case WM_QUIT:
			KillTimer(hWnd, uTimer);
			break;
		case WM_CREATE:
			//��������� ��������� ��������
			iLastX = 0;
			iLastY = 100 + rand()/3200;
			//����� ����������� ����������
			bPlusX = bPlusY = TRUE;
			//������������� ������
			uTimer = SetTimer(hWnd, 1, 100, NULL);
			//��������� ��������
			bmLogo = LoadBitmap(hInst, MAKEINTRESOURCE(IDB_LOGOBITMAP));
			break;
		case WM_TIMER:
            hdc = GetDC(hWnd); 
			// ���������� ��������� ��������
			if ((iLastX + 200) > ::GetSystemMetrics(SM_CXSCREEN))
				bPlusX = FALSE;
			if (iLastX < 0)
				bPlusX = TRUE;
			if ((iLastY + 100) > ::GetSystemMetrics(SM_CYSCREEN))
				bPlusY = FALSE;
			if (iLastY < 0)
				bPlusY = TRUE;
			if (bPlusX) iLastX += 10;
				else iLastX -= 10;
			if (bPlusY) iLastY += 10;
				else iLastY -= 10;
			// ���������� ��������
			hMemDC = CreateCompatibleDC(hdc); 
			SelectObject(hMemDC, bmLogo); 
			BitBlt(hdc, iLastX, iLastY,	iLastX + 400, iLastY + 200, hMemDC, 0, 0, SRCCOPY);
			DeleteObject(bmLogo);
			ReleaseDC(hWnd,hdc);
			DeleteDC(hMemDC);
			break;
		case WM_SETCURSOR:
			SetCursor(NULL);
			break;
		case WM_LBUTTONDOWN:
		case WM_MBUTTONDOWN:
		case WM_RBUTTONDOWN:
		case WM_KEYDOWN:
		case WM_SYSKEYDOWN:
			PostQuitMessage(0);
			break;
		default:
			return DefWindowProc(hWnd, message, wParam, lParam);
   }
   return 0;
}
