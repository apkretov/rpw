//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by StatusBar.rc
//
#define IDD_ABOUTBOX                    100
#define IDR_MAINFRAME                   128
#define IDR_STATUSTYPE                  129
#define IDI_SMILE1                      130
#define IDI_SMILE2                      131
#define IDI_SMILE3                      132
#define IDI_JMNCO                       133
#define ID_INDICATOR_PROGRESS           1000
#define ID_INDICATOR_EDIT               1001
#define ID_INDICATOR_COMBO              1002
#define ID_INDICATOR_ICON               1003
#define IDS_FIRST_VALUE                 1004
#define IDS_STRING1005                  1005
#define IDS_STRING1006                  1006
#define IDS_STRING1007                  1007
#define IDS_STRING1008                  1008
#define IDS_LAST_VALUE                  1009
#define IDS_EVENT                       1010
#define IDS_TEXT                        1011
#define IDS_CBN_SELCHANGE               1012
#define IDS_EN_CHANGE                   1013
#define IDS_CREATE_EDIT                 1014
#define IDS_DESTROY_EDIT                1015
#define IDS_CREATE_COMBO                1016
#define IDS_DESTROY_COMBO               1017
#define IDS_CREATE_STATIC               1018
#define IDS_DESTROY_STATIC              1019
#define IDS_CREATE_PROGRESS             1020
#define IDS_DESTROY_PROGRESS            1021
#define IDS_SM_SETICON                  1022
#define IDS_PBM_SETPOS                  1023
#define ID_STATUS_ICON                  32771
#define ID_STATUS_EDIT                  32772
#define ID_STATUS_COMBO                 32773
#define ID_STATUS_PROGRESS              32774

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_3D_CONTROLS                     1
#define _APS_NEXT_RESOURCE_VALUE        133
#define _APS_NEXT_COMMAND_VALUE         32775
#define _APS_NEXT_CONTROL_VALUE         1000
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
