// MyButton.cpp : implementation file
//

#include "stdafx.h"
#include "TMP5.h"
#include "MyButton.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CMyButton

CMyButton::CMyButton()
{
}

CMyButton::~CMyButton()
{
}


BEGIN_MESSAGE_MAP(CMyButton, CButton)
	//{{AFX_MSG_MAP(CMyButton)
	ON_CONTROL_REFLECT(BN_CLICKED, OnClicked)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CMyButton message handlers

void CMyButton::OnClicked() 
{
	// TODO: Add your control notification handler code here
	//CMyButton::GetParent()->GetParent()->SendMessage(CMyButton::m_Mothclick,0,0);
	CMyButton::GetParent()->SendMessage(CMyButton::m_Mothclick,(WPARAM)m_ParentBy,0);
}
