#if !defined(AFX_DIALOGEDITDETAL_H__72341FE3_9F01_11D5_A502_92718DF6D21B__INCLUDED_)
#define AFX_DIALOGEDITDETAL_H__72341FE3_9F01_11D5_A502_92718DF6D21B__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// DialogEditDetal.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// CDialogEditDetal dialog

class CDialogEditDetal : public CDialog
{
// Construction
public:
	CDialogEditDetal(CWnd* pParent = NULL);   // standard constructor

// Dialog Data
	//{{AFX_DATA(CDialogEditDetal)
	enum { IDD = IDD_DIALOGEDITDETAL };
		// NOTE: the ClassWizard will add data members here
	//}}AFX_DATA


// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CDialogEditDetal)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:

	// Generated message map functions
	//{{AFX_MSG(CDialogEditDetal)
		// NOTE: the ClassWizard will add member functions here
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_DIALOGEDITDETAL_H__72341FE3_9F01_11D5_A502_92718DF6D21B__INCLUDED_)
