// DialogEditClient.cpp : implementation file
//

#include "stdafx.h"
#include "TMP5.h"
#include "DialogEditClient.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CDialogEditClient dialog


CDialogEditClient::CDialogEditClient(CWnd* pParent /*=NULL*/)
	: CDialog(CDialogEditClient::IDD, pParent)
{
	//{{AFX_DATA_INIT(CDialogEditClient)
		// NOTE: the ClassWizard will add member initialization here
	//}}AFX_DATA_INIT
}


void CDialogEditClient::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CDialogEditClient)
		// NOTE: the ClassWizard will add DDX and DDV calls here
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CDialogEditClient, CDialog)
	//{{AFX_MSG_MAP(CDialogEditClient)
		// NOTE: the ClassWizard will add message map macros here
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CDialogEditClient message handlers
