// EditButtom.cpp : implementation file
//

#include "stdafx.h"
#include "TMP5.h"
#include "EditButtom.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CEditButtom

CEditButtom::CEditButtom()
{
	m_BPoint.x=	20;	
}

CEditButtom::~CEditButtom()
{

}


BEGIN_MESSAGE_MAP(CEditButtom, CEdit)
	//{{AFX_MSG_MAP(CEditButtom)
	ON_WM_CREATE()
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CEditButtom message handlers


int CEditButtom::OnCreate(LPCREATESTRUCT lpCreateStruct) 
{
	if (CEdit::OnCreate(lpCreateStruct) == -1)
		return -1;

	CEditButtom::MoveWindow(
		lpCreateStruct->x,lpCreateStruct->y,
		lpCreateStruct->cx-m_BPoint.x,
		lpCreateStruct->cy,TRUE);
	

	// TODO: Add your specialized creation code here
	
	if (!m_BButton.Create("..", WS_CHILD | WS_VISIBLE | WS_BORDER , 
		CRect(
			lpCreateStruct->x +lpCreateStruct->cx-m_BPoint.x  ,
			lpCreateStruct->y,
			lpCreateStruct->x + lpCreateStruct->cx ,
			lpCreateStruct->y+lpCreateStruct->cy),
			CEditButtom::GetParent(),1002))
		AfxMessageBox("Error create Burron");
	return 0;
}


