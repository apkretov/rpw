#if !defined(AFX_EDITBUTTOM_H__365B9CEF_9CCD_11D5_A502_8095410B931B__INCLUDED_)
#define AFX_EDITBUTTOM_H__365B9CEF_9CCD_11D5_A502_8095410B931B__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// EditButtom.h : header file
//
#include "MyButton.h"
/////////////////////////////////////////////////////////////////////////////
// CEditButtom window

class CEditButtom : public CEdit
{
// Construction
public:
	CEditButtom();
	CPoint m_BPoint;
	CMyButton m_BButton;
// Attributes
public:

// Operations
public:

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CEditButtom)
	//}}AFX_VIRTUAL

// Implementation
public:
	virtual ~CEditButtom();

	// Generated message map functions
protected:
	//{{AFX_MSG(CEditButtom)
	afx_msg int OnCreate(LPCREATESTRUCT lpCreateStruct);
	//}}AFX_MSG

	DECLARE_MESSAGE_MAP()
};

/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_EDITBUTTOM_H__365B9CEF_9CCD_11D5_A502_8095410B931B__INCLUDED_)
