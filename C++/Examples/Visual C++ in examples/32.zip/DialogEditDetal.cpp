// DialogEditDetal.cpp : implementation file
//

#include "stdafx.h"
#include "TMP5.h"
#include "DialogEditDetal.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CDialogEditDetal dialog


CDialogEditDetal::CDialogEditDetal(CWnd* pParent /*=NULL*/)
	: CDialog(CDialogEditDetal::IDD, pParent)
{
	//{{AFX_DATA_INIT(CDialogEditDetal)
		// NOTE: the ClassWizard will add member initialization here
	//}}AFX_DATA_INIT
}


void CDialogEditDetal::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CDialogEditDetal)
		// NOTE: the ClassWizard will add DDX and DDV calls here
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CDialogEditDetal, CDialog)
	//{{AFX_MSG_MAP(CDialogEditDetal)
		// NOTE: the ClassWizard will add message map macros here
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CDialogEditDetal message handlers
