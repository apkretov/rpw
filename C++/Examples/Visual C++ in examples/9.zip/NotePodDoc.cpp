// NotePodDoc.cpp : implementation of the CNotePodDoc class
//

#include "stdafx.h"
#include "NotePod.h"

#include "NotePodDoc.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CNotePodDoc

IMPLEMENT_DYNCREATE(CNotePodDoc, CDocument)

BEGIN_MESSAGE_MAP(CNotePodDoc, CDocument)
	//{{AFX_MSG_MAP(CNotePodDoc)
		// NOTE - the ClassWizard will add and remove mapping macros here.
		//    DO NOT EDIT what you see in these blocks of generated code!
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CNotePodDoc construction/destruction

CNotePodDoc::CNotePodDoc()
{
	// TODO: add one-time construction code here

}

CNotePodDoc::~CNotePodDoc()
{
}

BOOL CNotePodDoc::OnNewDocument()
{
	if (!CDocument::OnNewDocument())
		return FALSE;

	// TODO: add reinitialization code here
	// (SDI documents will reuse this document)

	return TRUE;
}



/////////////////////////////////////////////////////////////////////////////
// CNotePodDoc serialization

void CNotePodDoc::Serialize(CArchive& ar)
{
	// CEditView contains an edit control which handles all serialization
	((CEditView*)m_viewList.GetHead())->SerializeRaw(ar);
}

/////////////////////////////////////////////////////////////////////////////
// CNotePodDoc diagnostics

#ifdef _DEBUG
void CNotePodDoc::AssertValid() const
{
	CDocument::AssertValid();
}

void CNotePodDoc::Dump(CDumpContext& dc) const
{
	CDocument::Dump(dc);
}
#endif //_DEBUG

/////////////////////////////////////////////////////////////////////////////
// CNotePodDoc commands
