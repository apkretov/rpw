// NotePodView.h : interface of the CNotePodView class
//
/////////////////////////////////////////////////////////////////////////////

#if !defined(AFX_NOTEPODVIEW_H__3FCC150F_F9F8_11D1_837C_444553540000__INCLUDED_)
#define AFX_NOTEPODVIEW_H__3FCC150F_F9F8_11D1_837C_444553540000__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000


class CNotePodView : public CEditView
{
protected: // create from serialization only
	CNotePodView();
	DECLARE_DYNCREATE(CNotePodView)

// Attributes
public:
	CNotePodDoc* GetDocument();

// Operations
public:

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CNotePodView)
	public:
	virtual void OnDraw(CDC* pDC);  // overridden to draw this view
	virtual BOOL PreCreateWindow(CREATESTRUCT& cs);
	virtual void OnInitialUpdate();
	protected:
	virtual BOOL OnPreparePrinting(CPrintInfo* pInfo);
	virtual void OnBeginPrinting(CDC* pDC, CPrintInfo* pInfo);
	virtual void OnEndPrinting(CDC* pDC, CPrintInfo* pInfo);
	//}}AFX_VIRTUAL

// Implementation
public:
	virtual ~CNotePodView();
#ifdef _DEBUG
	virtual void AssertValid() const;
	virtual void Dump(CDumpContext& dc) const;
#endif

protected:

// Generated message map functions
protected:
	//{{AFX_MSG(CNotePodView)
		// NOTE - the ClassWizard will add and remove member functions here.
		//    DO NOT EDIT what you see in these blocks of generated code !
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

#ifndef _DEBUG  // debug version in NotePodView.cpp
inline CNotePodDoc* CNotePodView::GetDocument()
   { return (CNotePodDoc*)m_pDocument; }
#endif

/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_NOTEPODVIEW_H__3FCC150F_F9F8_11D1_837C_444553540000__INCLUDED_)
