// NotePodView.cpp : implementation of the CNotePodView class
//

#include "stdafx.h"
#include "NotePod.h"

#include "NotePodDoc.h"
#include "NotePodView.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CNotePodView

IMPLEMENT_DYNCREATE(CNotePodView, CEditView)

BEGIN_MESSAGE_MAP(CNotePodView, CEditView)
	//{{AFX_MSG_MAP(CNotePodView)
		// NOTE - the ClassWizard will add and remove mapping macros here.
		//    DO NOT EDIT what you see in these blocks of generated code!
	//}}AFX_MSG_MAP
	// Standard printing commands
	ON_COMMAND(ID_FILE_PRINT, CEditView::OnFilePrint)
	ON_COMMAND(ID_FILE_PRINT_DIRECT, CEditView::OnFilePrint)
	ON_COMMAND(ID_FILE_PRINT_PREVIEW, CEditView::OnFilePrintPreview)
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CNotePodView construction/destruction

CNotePodView::CNotePodView()
{
	// TODO: add construction code here

}

CNotePodView::~CNotePodView()
{
}

BOOL CNotePodView::PreCreateWindow(CREATESTRUCT& cs)
{
	// TODO: Modify the Window class or styles here by modifying
	//  the CREATESTRUCT cs

	BOOL bPreCreated = CEditView::PreCreateWindow(cs);
	cs.style &= ~(ES_AUTOHSCROLL|WS_HSCROLL);	// Enable word-wrapping

	return bPreCreated;
}

/////////////////////////////////////////////////////////////////////////////
// CNotePodView drawing

void CNotePodView::OnDraw(CDC* pDC)
{
	CNotePodDoc* pDoc = GetDocument();
	ASSERT_VALID(pDoc);

	// TODO: add draw code for native data here
}

/////////////////////////////////////////////////////////////////////////////
// CNotePodView printing

BOOL CNotePodView::OnPreparePrinting(CPrintInfo* pInfo)
{
	// default CEditView preparation
	return CEditView::OnPreparePrinting(pInfo);
}

void CNotePodView::OnBeginPrinting(CDC* pDC, CPrintInfo* pInfo)
{
	// Default CEditView begin printing.
	CEditView::OnBeginPrinting(pDC, pInfo);
}

void CNotePodView::OnEndPrinting(CDC* pDC, CPrintInfo* pInfo)
{
	// Default CEditView end printing
	CEditView::OnEndPrinting(pDC, pInfo);
}

/////////////////////////////////////////////////////////////////////////////
// CNotePodView diagnostics

#ifdef _DEBUG
void CNotePodView::AssertValid() const
{
	CEditView::AssertValid();
}

void CNotePodView::Dump(CDumpContext& dc) const
{
	CEditView::Dump(dc);
}

CNotePodDoc* CNotePodView::GetDocument() // non-debug version is inline
{
	ASSERT(m_pDocument->IsKindOf(RUNTIME_CLASS(CNotePodDoc)));
	return (CNotePodDoc*)m_pDocument;
}
#endif //_DEBUG

/////////////////////////////////////////////////////////////////////////////
// CNotePodView message handlers

void CNotePodView::OnInitialUpdate() 
{
	CEditView::OnInitialUpdate();
	
	// TODO: Add your specialized code here and/or call the base class
	SetTabStops(16);
}
