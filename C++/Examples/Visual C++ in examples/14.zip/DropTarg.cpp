#include "stdafx.h"
#include "DropTarg.h"
#include "fmtetc.h"

//
// CTreeDropTarget constructor
CTreeDropTarget::CTreeDropTarget()
{
    m_pTree = NULL;
    m_fIsDragging = FALSE;
    m_hDragItem = NULL;
}

//
// OnDragEnter - called when a drag item initially passes over
// the window associated with this object. In most cases, this call
// is delegated to OnDragOver.
DROPEFFECT CTreeDropTarget::OnDragEnter(CWnd*           pWnd,
                                        COleDataObject* pObj,
                                        DWORD           dwKeyState,
                                        CPoint          pt)
{
    return OnDragOver(pWnd, pObj, dwKeyState, pt);
}

//
// OnDragOver - called as a drag item passes over the window
// associated with this object. Two things happen in this
// function. First, the tree control item under the mouse is
// highlighted to provide feedback to the user. Second, the
// mouse cursor is set to the move cursor if the OLE Clipboard
// has text data avilable, or the copy cursor if the text is
// available and the Control key is pressed.
DROPEFFECT CTreeDropTarget::OnDragOver(CWnd*           pWnd,
                                       COleDataObject* pObj,
                                       DWORD           dwKeyState,
                                       CPoint          pt)
{
    UINT uHitTest = TVHT_ONITEM;
    HTREEITEM hTarget = m_pTree->HitTest(pt, &uHitTest);
    m_pTree->SelectDropTarget(hTarget);

    DROPEFFECT deResult = DROPEFFECT_NONE;
    if(pObj->IsDataAvailable(CF_TEXT))
    {
        if(dwKeyState & MK_CONTROL)
            deResult = DROPEFFECT_COPY;
        else
            deResult = DROPEFFECT_MOVE;
    }
    return deResult;
}

//
// OnDrop - called when the user drops the drag item on our window
// The text string is collected from the OLE Clipboard, and a new
// item is created for the tree control.
BOOL CTreeDropTarget::OnDrop(CWnd*           pWnd,
                             COleDataObject* pObj,
                             DROPEFFECT      de,
                             CPoint          pt)
{
    CFormatEtc  fe;
    STGMEDIUM   stg;
    // Test to see if the dropper can give us text
    BOOL fHasText = pObj->GetData(CF_TEXT, &stg, &fe);
    if(fHasText == FALSE)
        return FALSE;
    LPSTR pszObj = (LPSTR)GlobalLock(stg.hGlobal);
    if(pszObj)
    {
        HTREEITEM hNewItem;
        UINT uHitTest = TVHT_ONITEM;
        HTREEITEM hTarget = m_pTree->HitTest(pt, &uHitTest);
        // Drop to self is not allowed.
        if(m_fIsDragging && (hTarget == m_hDragItem))
            return FALSE;

        if(hTarget != NULL)
        {
            hNewItem = m_pTree->InsertItem(pszObj,
                                           hTarget,
                                           TVI_FIRST);
        }
        else // Add at root
        {
            hNewItem = m_pTree->InsertItem(pszObj,
                                           TVI_ROOT,
                                           TVI_LAST);
        }
        m_pTree->SelectDropTarget(NULL);
        m_pTree->SelectItem(hNewItem);
        GlobalUnlock(stg.hGlobal);
        GlobalFree(stg.hGlobal);
        return TRUE;
    }
    return FALSE;
}

//
// SetParent - called by the CTreeCtrl object associated with this
// drop target. The pointer to the CTreeCtrl object is used to add
// items to the tree, and highlight the drop target.
void CTreeDropTarget::SetParent(CTreeCtrl* pCtrl)
{
    m_pTree = pCtrl;
}

//
// SetDragItem - called by the CTreeCtrl object when a drag begins
// or ends. The drag item is used to prevent dropping an object on
// itself, which is a meaningless operation.
void CTreeDropTarget::SetDragItem(HTREEITEM hItem)
{
    m_hDragItem = hItem;
    if(hItem)
        m_fIsDragging = TRUE;
    else
        m_fIsDragging = FALSE;
}
