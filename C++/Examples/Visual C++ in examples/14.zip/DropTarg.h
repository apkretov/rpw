#pragma once

class CTreeDropTarget:public COleDropTarget
{
// Constructor
public:
    CTreeDropTarget();

// Interfaces
public:
    virtual DROPEFFECT OnDragEnter(CWnd*           pWnd,
                                   COleDataObject* pObj,
                                   DWORD           dwKeyState,
                                   CPoint          pt);
    virtual DROPEFFECT OnDragOver(CWnd*           pWnd,
                                  COleDataObject* pObj,
                                  DWORD           dwKeyState,
                                  CPoint          pt);
    virtual BOOL OnDrop(CWnd*           pWnd,
                        COleDataObject* pObj,
                        DROPEFFECT      de,
                        CPoint          pt);
// Operations
public:
    void SetDragItem(HTREEITEM hItem);
    void SetParent(CTreeCtrl* pTree);

// Implementation
private:
    CTreeCtrl* m_pTree;
    BOOL       m_fIsDragging;
    HTREEITEM  m_hDragItem;
};
