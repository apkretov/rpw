// DragTree.cpp : implementation file
//

#include "stdafx.h"
#include "OleTree.h"
#include "DragTree.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CDragTree

CDragTree::CDragTree()
{
}

CDragTree::~CDragTree()
{
}


BEGIN_MESSAGE_MAP(CDragTree, CTreeCtrl)
	//{{AFX_MSG_MAP(CDragTree)
	ON_NOTIFY_REFLECT(TVN_BEGINDRAG, OnBegindrag)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CDragTree message handlers

// Handle the start of a drag. Since the tree control detects that
// the drag has actually begun, it isn't necessary to detect the
// mouse drag. The text of the drag item is placed onto the OLE
// Clipboard, and DoDragDrop is called. The handle of the item that
// is dragged is passed to m_dropTarget to prevent tree items being
// dropped on themselves.
void CDragTree::OnBegindrag(NMHDR* pNMHDR, LRESULT* pResult)
{
    NM_TREEVIEW* pNMTreeView = (NM_TREEVIEW*)pNMHDR;
    // Only nodes without children are eligible for dragging
    HTREEITEM hDragItem = pNMTreeView->itemNew.hItem;
    if(ItemHasChildren(hDragItem) == FALSE)
    {
        CString strItem = GetItemText(hDragItem);
        if(strItem.IsEmpty() == FALSE)
        {
            HGLOBAL hGlobal = GlobalAlloc(GMEM_SHARE,
                              strItem.GetLength() + 1);
            LPSTR   pszGlobal = (LPSTR)GlobalLock(hGlobal);
            ASSERT(pszGlobal);
            lstrcpy(pszGlobal, strItem);
            GlobalUnlock(hGlobal);
            m_dragSource.CacheGlobalData(CF_TEXT, hGlobal);

            m_dropTarget.SetDragItem(hDragItem);
            DROPEFFECT  de;
            de = m_dragSource.DoDragDrop(DROPEFFECT_COPY|
                                         DROPEFFECT_MOVE);
            // The drop is over - delete the drag item if
            // neccessary, and reset the drop target.
            if(de == DROPEFFECT_MOVE)
                DeleteItem(hDragItem);
            m_dropTarget.SetDragItem(NULL);
            SelectDropTarget(NULL);
        }
    }
    *pResult = 0;
}

//
// Register the tree control window as a drop target, and
// pass a pointer to this window, so that the drop target
// can pass messages back to us.
void CDragTree::Register()
{
    m_dropTarget.Register(this);
    m_dropTarget.SetParent(this);
}
