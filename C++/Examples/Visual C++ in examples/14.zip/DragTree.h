#if !defined(AFX_DRAGTREE_H__63B70250_7E36_11D2_B867_00104B36573E__INCLUDED_)
#define AFX_DRAGTREE_H__63B70250_7E36_11D2_B867_00104B36573E__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// DragTree.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// CDragTree window

#include "droptarg.h"
class CDragTree : public CTreeCtrl
{
// Construction
public:
	CDragTree();

// Attributes
public:

// Operations
public:
    void Register();

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CDragTree)
	//}}AFX_VIRTUAL

// Implementation
public:
	virtual ~CDragTree();

	// Generated message map functions
protected:
    CTreeDropTarget m_dropTarget;
    COleDataSource  m_dragSource;

    //{{AFX_MSG(CDragTree)
	afx_msg void OnBegindrag(NMHDR* pNMHDR, LRESULT* pResult);
	//}}AFX_MSG

	DECLARE_MESSAGE_MAP()
};

/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_DRAGTREE_H__63B70250_7E36_11D2_B867_00104B36573E__INCLUDED_)
