//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by FourUp.rc
//
#define IDM_ABOUTBOX                    0x0010
#define IDD_ABOUTBOX                    100
#define IDS_ABOUTBOX                    101
#define IDD_FOURUP_DIALOG               102
#define IDR_MAINFRAME                   128
#define IDI_SPADE                       129
#define IDI_CLUB                        130
#define IDI_DIAMOND                     131
#define IDI_HEART                       132
#define IDB_BITMAP1                     133
#define IDC_CARD1                       1000
#define IDC_CARD2                       1001
#define IDC_CARD3                       1002
#define IDC_AMT_LEFT                    1004
#define IDC_DEALCARDS                   1005
#define IDC_CARD4                       1006

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        134
#define _APS_NEXT_COMMAND_VALUE         32771
#define _APS_NEXT_CONTROL_VALUE         1007
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
