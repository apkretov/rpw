// FourUpDlg.cpp : implementation file
//

#include "stdafx.h"
#include "FourUp.h"
#include "FourUpDlg.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CAboutDlg dialog used for App About

class CAboutDlg : public CDialog
{
public:
	CAboutDlg();

// Dialog Data
	//{{AFX_DATA(CAboutDlg)
	enum { IDD = IDD_ABOUTBOX };
	//}}AFX_DATA

	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CAboutDlg)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:
	//{{AFX_MSG(CAboutDlg)
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

CAboutDlg::CAboutDlg() : CDialog(CAboutDlg::IDD)
{
	//{{AFX_DATA_INIT(CAboutDlg)
	//}}AFX_DATA_INIT
}

void CAboutDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CAboutDlg)
	//}}AFX_DATA_MAP
}

BEGIN_MESSAGE_MAP(CAboutDlg, CDialog)
	//{{AFX_MSG_MAP(CAboutDlg)
		// No message handlers
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CFourUpDlg dialog

CFourUpDlg::CFourUpDlg(CWnd* pParent /*=NULL*/)
	: CDialog(CFourUpDlg::IDD, pParent)
{
	//{{AFX_DATA_INIT(CFourUpDlg)
		// NOTE: the ClassWizard will add member initialization here
	//}}AFX_DATA_INIT
	// Note that LoadIcon does not require a subsequent DestroyIcon in Win32
	m_hIcon = AfxGetApp()->LoadIcon(IDR_MAINFRAME);

    m_Club      = AfxGetApp()->LoadIcon(IDI_CLUB);
    m_Diamond   = AfxGetApp()->LoadIcon(IDI_DIAMOND);
    m_Heart     = AfxGetApp()->LoadIcon(IDI_HEART);
    m_Spade     = AfxGetApp()->LoadIcon(IDI_SPADE);

	//  seed the random number generator
	srand( (unsigned) time(NULL));

    // Initialize AmountRemaining field
    m_Amt_Remaining = 100.0;
}

void CFourUpDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CFourUpDlg)
	DDX_Control(pDX, IDC_CARD4, m_Card4);
	DDX_Control(pDX, IDC_CARD3, m_Card3);
	DDX_Control(pDX, IDC_CARD2, m_Card2);
	DDX_Control(pDX, IDC_CARD1, m_Card1);
	DDX_Control(pDX, IDC_AMT_LEFT, m_Amt_Left);
	//}}AFX_DATA_MAP
}

BEGIN_MESSAGE_MAP(CFourUpDlg, CDialog)
	//{{AFX_MSG_MAP(CFourUpDlg)
	ON_WM_SYSCOMMAND()
	ON_WM_PAINT()
	ON_WM_QUERYDRAGICON()
	ON_BN_CLICKED(IDC_DEALCARDS, OnDealCards)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CFourUpDlg message handlers

BOOL CFourUpDlg::OnInitDialog()
{
	CDialog::OnInitDialog();

	// Add "About..." menu item to system menu.

	// IDM_ABOUTBOX must be in the system command range.
	ASSERT((IDM_ABOUTBOX & 0xFFF0) == IDM_ABOUTBOX);
	ASSERT(IDM_ABOUTBOX < 0xF000);

	CMenu* pSysMenu = GetSystemMenu(FALSE);
	if (pSysMenu != NULL)
	{
		CString strAboutMenu;
		strAboutMenu.LoadString(IDS_ABOUTBOX);
		if (!strAboutMenu.IsEmpty())
		{
			pSysMenu->AppendMenu(MF_SEPARATOR);
			pSysMenu->AppendMenu(MF_STRING, IDM_ABOUTBOX, strAboutMenu);
		}
	}

	// Set the icon for this dialog.  The framework does this automatically
	//  when the application's main window is not a dialog
	SetIcon(m_hIcon, TRUE);			// Set big icon
	SetIcon(m_hIcon, FALSE);		// Set small icon
	
	// TODO: Add extra initialization here
	
	return TRUE;  // return TRUE  unless you set the focus to a control
}

void CFourUpDlg::OnSysCommand(UINT nID, LPARAM lParam)
{
	if ((nID & 0xFFF0) == IDM_ABOUTBOX)
	{
		CAboutDlg dlgAbout;
		dlgAbout.DoModal();
	}
	else
	{
		CDialog::OnSysCommand(nID, lParam);
	}
}

// If you add a minimize button to your dialog, you will need the code below
//  to draw the icon.  For MFC applications using the document/view model,
//  this is automatically done for you by the framework.

void CFourUpDlg::OnPaint() 
{
	if (IsIconic())
	{
		CPaintDC dc(this); // device context for painting

		SendMessage(WM_ICONERASEBKGND, (WPARAM) dc.GetSafeHdc(), 0);

		// Center icon in client rectangle
		int cxIcon = GetSystemMetrics(SM_CXICON);
		int cyIcon = GetSystemMetrics(SM_CYICON);
		CRect rect;
		GetClientRect(&rect);
		int x = (rect.Width() - cxIcon + 1) / 2;
		int y = (rect.Height() - cyIcon + 1) / 2;

		// Draw the icon
		dc.DrawIcon(x, y, m_hIcon);
	}
	else
	{
		CDialog::OnPaint();
	}
}

// The system calls this to obtain the cursor to display while the user drags
//  the minimized window.
HCURSOR CFourUpDlg::OnQueryDragIcon()
{
	return (HCURSOR) m_hIcon;
}

void CFourUpDlg::OnCancel() 
{
	// TODO: Add extra cleanup here
    CString s;
    s.Format("Great game! You have $ %.2f left.", m_Amt_Remaining);
    MessageBox(s, "Thanks for playing FourUp!");

	CDialog::OnCancel();
}

void CFourUpDlg::OnDealCards() 
{
	// TODO: Add your control notification handler code here
	    // 1. Subtract our 2.00, whatever else happens
    m_Amt_Remaining -= 2.00;  

    // 2. Deal the cards. Don't know how, just yet
    DealCards();

    // 3. Calculate the winnings and add to AmountRemaining
    CalculateWinnings();

    // 4. Display total AmountRemaining
    CString s;
    s.Format("Amount Remaining $ %.2f", m_Amt_Remaining);

	m_Amt_Left.SetWindowText(s);
}

void CFourUpDlg::DealCards()
{
    // Initialize the m_Cards array
    for(int i = 0; i < 4; i++)
        m_Cards[i] = 0;

    m_Card1.SetIcon(PickRandomCard());
    m_Card2.SetIcon(PickRandomCard());
    m_Card3.SetIcon(PickRandomCard());
    m_Card4.SetIcon(PickRandomCard());
}

HICON& CFourUpDlg::PickRandomCard()
{
    int num = (rand() % 4);
    m_Cards[num] ++;    // Update scoring array

    switch(num)
    {
        case 0: return m_Club;
        case 1: return m_Diamond;
        case 2: return m_Heart;
    }
	return m_Spade;
}

void CFourUpDlg::CalculateWinnings()
{
    int pairs = 0;
    for (int i = 0; i < 4; i++)
    {
        if (m_Cards[i] == 2)
        {
            if (pairs > 0)
            {
                m_Amt_Remaining += 3.00;
                break;
            }
            else
            {
                pairs++;
            }
        }
        else if (m_Cards[i] == 3)
        {
            m_Amt_Remaining += 6.00;
            break;
        }
        else if (m_Cards[i] == 4)
        {
            m_Amt_Remaining += 9.00;
            break;
        }
    }
}
