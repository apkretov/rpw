// Tray42 - systray example header
// See tray42.c for copyright

// Icon
#define IDI_42 10

// Menu
#define IDM_CONTEXTMAIN 20
#define IDM_CONTEXTPOPUP 21
#define IDM_MESSAGEBOX 22
#define IDM_EXIT 23
