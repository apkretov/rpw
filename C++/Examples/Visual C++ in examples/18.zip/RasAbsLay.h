#if !defined(AFX_RASABSLAY_H__0E2891A1_2101_11D3_8E7D_00C0DF411981__INCLUDED_)
#define AFX_RASABSLAY_H__0E2891A1_2101_11D3_8E7D_00C0DF411981__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

//
// This object implements encapsulates the portion of the RAS API that we need 
// but using dinamic linking
//

#include <ras.h>
#include <raserror.h>


class CRas
{

public:

	CRas();
	~CRas();

	// RAS API
	DWORD RasDeleteEntry(LPCTSTR lpszPhonebook, LPCTSTR lpszEntry);
	DWORD RasSetEntryDialParams(LPCTSTR lpszPhonebook,  LPRASDIALPARAMS lprasdialparams,                         
			BOOL fRemovePassword);

	DWORD RasSetEntryProperties( LPCTSTR lpszPhonebook,   LPCTSTR lpszEntry,   LPRASENTRY lpRasEntry,
			DWORD dwEntryInfoSize, LPBYTE lpbDeviceInfo,   DWORD dwDeviceInfoSize);

	DWORD RasValidateEntryName(LPCTSTR lpszPhonebook, LPCTSTR lpszEntry);


	DWORD RasEnumDevices(LPRASDEVINFO lpRasDevInfo,  
			LPDWORD lpcb, LPDWORD lpcDevices);

	BOOL	LoadLibrary();
	BOOL	ReleaseLibrary();

	// Data
	HINSTANCE   m_hRasLib;	

};

class CRasAbsLay 
{
// Construction
public:

	CRasAbsLay();

	// Members

	static DWORD RasDeleteEntry(CString &strEntry);
	static BOOL CreatePhoneBookEntry(CString& strName,	// Connection name
								CString&	strPhoneNumber,	// Phone Number 
								CString&	strUserName,
								CString&	strUserPassword,								
								CString&	strDNS1,
								CString&	strDNS2,
								CString&	strDevType,
								CString&	strDevName);	

	static BOOL EnumDevices(CArray <RASDEVINFO, RASDEVINFO> &ArRasDevInfo);
	static BOOL FromStringToIpAddr(CString str, RASIPADDR &rasIP);

	
// Implementation
public:
	virtual ~CRasAbsLay();

};

/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_RASABSLAY_H__0E2891A1_2101_11D3_8E7D_00C0DF411981__INCLUDED_)
