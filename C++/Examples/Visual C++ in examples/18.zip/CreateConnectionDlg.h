// CreateConnectionDlg.h : header file
//

#if !defined(AFX_CREATECONNECTIONDLG_H__A975FC25_83D9_11D3_98E5_0080C82091EC__INCLUDED_)
#define AFX_CREATECONNECTIONDLG_H__A975FC25_83D9_11D3_98E5_0080C82091EC__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

/////////////////////////////////////////////////////////////////////////////
// CCreateConnectionDlg dialog

#include "rasabslay.h"

class CCreateConnectionDlg : public CDialog
{
// Construction
public:
	CCreateConnectionDlg(CWnd* pParent = NULL);	// standard constructor

	CRasAbsLay						m_ras;
	CArray <RASDEVINFO, RASDEVINFO> m_ArRasDevInfo;

// Dialog Data
	//{{AFX_DATA(CCreateConnectionDlg)
	enum { IDD = IDD_CREATECONNECTION_DIALOG };
	CComboBox	m_AdapterCtrl;
	CString	m_strDNS1;
	CString	m_strDNS2;
	CString	m_strID;
	CString	m_strPass;
	CString	m_strPassCheck;
	CString	m_strPhone;
	//}}AFX_DATA

	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CCreateConnectionDlg)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);	// DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:
	HICON m_hIcon;

	// Generated message map functions
	//{{AFX_MSG(CCreateConnectionDlg)
	virtual BOOL OnInitDialog();
	afx_msg void OnPaint();
	afx_msg HCURSOR OnQueryDragIcon();
	afx_msg void OnCreateConnection();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_CREATECONNECTIONDLG_H__A975FC25_83D9_11D3_98E5_0080C82091EC__INCLUDED_)
