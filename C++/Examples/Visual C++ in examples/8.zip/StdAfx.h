// stdafx.h : include file for standard system include files,
//  or project specific include files that are used frequently, but
//      are changed infrequently
//

#define VC_EXTRALEAN		// Exclude rarely-used stuff from Windows headers

#include <afxwin.h>         // MFC core and standard components
#include <afxext.h>         // MFC extensions
#include <afxtempl.h>			  // MFC template classes
#include <afxsock.h>        // MFC Sockets
#include <afxdisp.h>        // Required by afxpriv.h
#include <afxpriv.h>        // to get access to the T2A macro



