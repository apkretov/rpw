#include "stdafx.h"
#include "smtp.h"


class CApp : public CWinApp
{
protected:
  virtual BOOL InitInstance();
};

CApp theApp;


BOOL CApp::InitInstance()
{
	//initialise sockets
	if (!AfxSocketInit())
  {
    TRACE(_T("Failed to initialise the Winsock stack\n"));
    return FALSE;
  }

  //Create the SMTP connection
  CSMTPConnection smtp;

  //Connect to the server
  if (!smtp.Connect(_T("127.0.0.1")))
  {
    DWORD dwError = ::GetLastError();
    CString sResponse = smtp.GetLastCommandResponse();
    TRACE(_T("Failed to connect to SMTP server\n"));
    return FALSE;
  }

  //Create a test message
  CSMTPMessage m;
  CSMTPAddress From(_T("Some Person"), _T("someone@yourdomain.com"));	 //Change these values to your settings
  m.m_From = From;
  CSMTPAddress To(_T("Another Person"), _T("someone2@yourdomain.com")); //Change these values to your settings
  m.AddRecipient(To);
  m.m_sSubject = _T("Test Message");
  m.AddBody(_T("The CSMTPConnection classes allows\r\n.\r\n.you to send SMTP messages from MFC code"));

	//Testing Reply To support
	//m.m_ReplyTo = CSMTPAddress(_T("Another PJ"), _T("pj.naughter@softech-telecom.com"));

	//Testing attachment support
	CSMTPAttachment attachment;
  attachment.Attach(_T("C:\\AUTOEXEC.BAT"));
  m.AddAttachment(&attachment);

  //Sent the message
  if (!smtp.SendMessage(m))
  {
    DWORD dwError = ::GetLastError();
    CString sResponse = smtp.GetLastCommandResponse();
    TRACE(_T("Failed to send the SMTP message\n"));
    return FALSE;
  }

  //Disconnect from the server
  smtp.Disconnect();

	return FALSE;
}