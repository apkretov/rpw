// Tmp6.h : main header file for the TMP6 application
//

#if !defined(AFX_TMP6_H__930F2A65_AF65_11D5_BC2A_0050043919FC__INCLUDED_)
#define AFX_TMP6_H__930F2A65_AF65_11D5_BC2A_0050043919FC__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#ifndef __AFXWIN_H__
	#error include 'stdafx.h' before including this file for PCH
#endif

#include "resource.h"		// main symbols

/////////////////////////////////////////////////////////////////////////////
// CTmp6App:
// See Tmp6.cpp for the implementation of this class
//

class CTmp6App : public CWinApp
{
public:
	CTmp6App();

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CTmp6App)
	public:
	virtual BOOL InitInstance();
	//}}AFX_VIRTUAL

// Implementation

	//{{AFX_MSG(CTmp6App)
		// NOTE - the ClassWizard will add and remove member functions here.
		//    DO NOT EDIT what you see in these blocks of generated code !
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};


/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_TMP6_H__930F2A65_AF65_11D5_BC2A_0050043919FC__INCLUDED_)
