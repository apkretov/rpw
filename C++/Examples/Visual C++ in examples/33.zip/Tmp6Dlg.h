// Tmp6Dlg.h : header file
//

#if !defined(AFX_TMP6DLG_H__930F2A67_AF65_11D5_BC2A_0050043919FC__INCLUDED_)
#define AFX_TMP6DLG_H__930F2A67_AF65_11D5_BC2A_0050043919FC__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#include "StaticColor.h"

/////////////////////////////////////////////////////////////////////////////
// CTmp6Dlg dialog

class CTmp6Dlg : public CDialog
{
// Construction
public:
	CTmp6Dlg(CWnd* pParent = NULL);	// standard constructor

// Dialog Data
	//{{AFX_DATA(CTmp6Dlg)
	enum { IDD = IDD_TMP6_DIALOG };
	CStaticColor	m_static1;
	//}}AFX_DATA

	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CTmp6Dlg)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);	// DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:
	HICON m_hIcon;

	// Generated message map functions
	//{{AFX_MSG(CTmp6Dlg)
	virtual BOOL OnInitDialog();
	afx_msg void OnSysCommand(UINT nID, LPARAM lParam);
	afx_msg void OnPaint();
	afx_msg HCURSOR OnQueryDragIcon();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_TMP6DLG_H__930F2A67_AF65_11D5_BC2A_0050043919FC__INCLUDED_)
