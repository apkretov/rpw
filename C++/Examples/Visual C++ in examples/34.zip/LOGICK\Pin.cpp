// Pin.cpp: implementation of the CPin class.
//
//////////////////////////////////////////////////////////////////////

#include "stdafx.h"
#include "Logick.h"
#include "Pin.h"
#include <math.h>
#include "Block.h"

#ifdef _DEBUG
#undef THIS_FILE
static char THIS_FILE[]=__FILE__;
#define new DEBUG_NEW
#endif


IMPLEMENT_SERIAL( CPin     , CObject ,1)
IMPLEMENT_SERIAL( CNetLine , CObList ,1)
IMPLEMENT_SERIAL( CPinIn   , CPin  ,  1)
IMPLEMENT_SERIAL( CPinOut  , CPinIn , 1)


//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////
CPin::~CPin()
{
}
//----------------------------------------------
bool CPin::IsCloseToPin(CPoint point)
{
	int dx = m_p.x - point.x ;
	int dy = m_p.y - point.y ;
	return (sqrt(dx*dx + dy*dy) < 9) ;

}
void CPin::Serialize(CArchive& ar)
{
	CObject::Serialize (ar);

	if(ar.IsStoring())
	{
		ar <<  m_p.x << m_p.y ;
		ar << n_IDpin  ;
	} 
	else
	{
		ar >> m_p.x >> m_p.y ;
		ar >> n_IDpin  ;
	}
}
//----------------------------------------------
void CPinIn::Draw(CDC *pDC, CBrush *b)
{
	CBrush* Old = pDC->SelectObject(b) ;
	
	CRect rect( m_p.x - 3 , m_p.y-6 , m_p.x + 3 ,m_p.y);
	pDC->Ellipse (rect);

	pDC->SelectObject(Old) ;
}
//----------------------------------------------
void CPinOut::Draw(CDC *pDC, CBrush *b)
{
	CBrush* Old = pDC->SelectObject(b) ;

	CRect rect( m_p.x - 3 , m_p.y , m_p.x + 3 ,m_p.y + 6);
	pDC->Ellipse (rect);

	pDC->SelectObject(Old) ;
}
//----------------------------------------------
/////////////////////////////////////////////////
void CPinIn::KillerLinks()
{
	m_pPrevOut->pNext = NULL ; 	
	m_pPrevOut->m_Line.RemoveAll();	
	m_pPrevOut->m_IsClose = false; 
	m_pPrevOut = NULL;
	m_IsClose = false ;
}
void CPinOut::KillerLinks()
{

}
void CPinIn::Serialize(CArchive& ar)
{
	CPin::Serialize (ar);

	if(ar.IsStoring())
	{
		ar << m_IsClose ;
//		ar << m_pPrevOut;
	} 
	else
	{
		ar >> m_IsClose ;
//		ar >> m_pPrevOut;
	}
}
void CPinOut::Serialize(CArchive& ar)
{
	CPinIn::Serialize(ar);
	m_Line.Serialize(ar);

/*	if(ar.IsStoring())
	{
 		ar << pNext ;
	}
	else
	{
		ar >> pNext ;
	}
	*/
}
/////////////////////////////////////////////////
void CNetLine::Delete() 
{
   POSITION pos1, pos2;
   CObject* pa;
   pos1 = GetHeadPosition();
   while (pos1)
   {
		pos2 = pos1;
		GetNext( pos1 ) ;
		pa = GetAt( pos2 ); // Save the old pointer for deletion.
        RemoveAt( pos2 );
        delete pa;  // Deletion avoids memory leak.
   }
}
//----------------------------------------------
void CNetLine::Hide(CDC* pDC)
{
	bool  first = true ;
	CPen* oldPen = pDC->SelectObject(&m_Pen);
	pDC->SetBkMode(TRANSPARENT);
	pDC->SetROP2(R2_NOT);

	POSITION pos = GetHeadPosition();
	while(pos)
	{
		CObject* pObj = GetNext(pos);
		if(first)
		{
			first = false;
			pDC->MoveTo(((CPin*)pObj)->m_p);
		}
		else
			pDC->LineTo(((CPin*)pObj)->m_p); 
	}

	pDC->SetROP2(R2_COPYPEN);
	pDC->SelectObject(oldPen);
	
}
//----------------------------------------------
void CNetLine::Show(CDC* pDC)
{
	bool  first = true ;
	CPen* oldPen = pDC->SelectObject(&m_Pen);
	pDC->SetBkMode(TRANSPARENT);
	pDC->SetROP2(R2_NOT);

	POSITION pos = GetHeadPosition();
	while(pos)
	{
		CObject* pObj = GetNext(pos);
		if(first)
		{
			first = false;
			pDC->MoveTo(((CPin*)pObj)->m_p);
		}
		else
			pDC->LineTo(((CPin*)pObj)->m_p); 
	}

	pDC->SetROP2(R2_COPYPEN);
	pDC->SelectObject(oldPen);
	
}
//----------------------------------------------
void CNetLine::DrawTMP(CDC* pDC,CPin* pCurentPin)
{
	Hide(pDC);
	if(GetTail() != GetHead())
	RemoveTail();
	AddTail (pCurentPin);	
	Show(pDC);
}
//----------------------------------------------
void CNetLine::SetPin(CPin* pCurentPin)
{
	if( !IsEmpty()  && ( GetTail() !=  GetHead()) )
		RemoveTail();
	AddTail (pCurentPin);
}
//----------------------------------------------
void CNetLine::Draw (CDC* pDC)
{
	bool  first = true ;
	CPen ColorLine(PS_SOLID,1, RGB(0 , 0, 255));
	CPen* oldPen = pDC->SelectObject(&ColorLine);
	pDC->SetBkMode(TRANSPARENT);

	CPoint p1 , p2 ;
	POSITION	pos = GetHeadPosition();
	while(pos)
	{
		CObject* pObj = GetNext(pos);
		if(first)
		{
			first = false;
			p1 = (((CPin*)pObj)->m_p);
		}
		else
			p2 = (((CPin*)pObj)->m_p); 
	}
	//---------------------------------------------
	if (p1.x <= p2.x )
	{
		if( p1.y <= p2.y )
		{
			pDC->MoveTo(p1);                    // *p1
			pDC->LineTo(p1.x ,(p1.y + p2.y)/2 );//  |____
			pDC->LineTo(p2.x,(p1.y + p2.y)/2) ; //       |
			pDC->LineTo(p2);                    //      *p2
		}
		else
		{                                       
			pDC->MoveTo(p1);                   //    ________
			pDC->LineTo(p1.x,p1.y + 15);       //   |       |
			pDC->LineTo (p1.x -70,(p1.y +15)); //   *p2     |
			pDC->LineTo (p1.x -70,(p2.y -15)); //           |
			pDC->LineTo (p2.x ,(p2.y -15));    //      *p1  |
			pDC->LineTo (p2);                  //      |____|   
											
		}
	}
	else
	{
		if( p1.y <= p2.y )
		{
			pDC->MoveTo(p1);                    //      *p1
			pDC->LineTo(p1.x ,(p1.y + p2.y)/2 );//  ____|
			pDC->LineTo(p2.x,(p1.y + p2.y)/2) ; // |
			pDC->LineTo(p2);                    // *p2
		}
		else //p1.y > p2.y && p1.x > p2.y
		{
			pDC->MoveTo (p1);                   //  _______     
			pDC->LineTo (p1.x ,(p1.y +15));     // |       |
			pDC->LineTo (p1.x + 70,(p1.y +15)); // |       *p2
			pDC->LineTo (p1.x + 70,(p2.y -15)); // |
			pDC->LineTo (p2.x ,(p2.y -15));     // |   *p1
			pDC->LineTo (p2);                   // |___|
		}
	}

	//---------------------------------------------
	pDC->SelectObject(oldPen);	
}//---------------------------------------------- 

void CNetLine::Serialize(CArchive& ar)
{
	CObList::Serialize(ar); 
}