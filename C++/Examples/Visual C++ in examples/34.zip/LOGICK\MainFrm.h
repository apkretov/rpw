// MainFrm.h : interface of the CMainFrame class
//
/////////////////////////////////////////////////////////////////////////////

#if !defined(AFX_MAINFRM_H__A0A86169_32FA_11D5_9D8E_BE3D01A9D579__INCLUDED_)
#define AFX_MAINFRM_H__A0A86169_32FA_11D5_9D8E_BE3D01A9D579__INCLUDED_

#include"DialogViewDlg.h"

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

class CMainFrame : public CMDIFrameWnd
{
	DECLARE_DYNAMIC(CMainFrame)
public:
	CMainFrame();

// Attributes
public:
		UINT   m_SelectTools;
// Operations
public:

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CMainFrame)
	virtual BOOL PreCreateWindow(CREATESTRUCT& cs);
	//}}AFX_VIRTUAL

// Implementation
public:
	virtual ~CMainFrame();
#ifdef _DEBUG
	virtual void AssertValid() const;
	virtual void Dump(CDumpContext& dc) const;
#endif

protected:  // control bar embedded members
	CStatusBar  m_wndStatusBar;
	CToolBar    m_wndToolBar;
	CToolBar    m_wndTools   ; // IRD_TOOLSBAR
//	UINT		m_nToolsCol  ;


// Generated message map functions
protected:
	//{{AFX_MSG(CMainFrame)
	afx_msg int OnCreate(LPCREATESTRUCT lpCreateStruct);
	afx_msg void OnNewSelect();
	afx_msg void OnUpdateNewSelect(CCmdUI* pCmdUI);
	afx_msg void OnNewNode();
	afx_msg void OnUpdateNewNode(CCmdUI* pCmdUI);
	afx_msg void OnNewNetline();
	afx_msg void OnUpdateNewNetline(CCmdUI* pCmdUI);
	afx_msg void OnNewOperator();
	afx_msg void OnUpdateNewOperator(CCmdUI* pCmdUI);
	afx_msg void OnNewOperation();
	afx_msg void OnUpdateNewOperation(CCmdUI* pCmdUI);
	afx_msg void OnNewIf();
	afx_msg void OnUpdateNewIf(CCmdUI* pCmdUI);
	afx_msg void OnNewIfelse();
	afx_msg void OnUpdateNewIfelse(CCmdUI* pCmdUI);
	afx_msg void OnNewFor();
	afx_msg void OnUpdateNewFor(CCmdUI* pCmdUI);
	afx_msg void OnNewWhile();
	afx_msg void OnUpdateNewWhile(CCmdUI* pCmdUI);
	afx_msg void OnNewDowhile();
	afx_msg void OnUpdateNewDowhile(CCmdUI* pCmdUI);
	afx_msg void OnNewSwitch();
	afx_msg void OnUpdateNewSwitch(CCmdUI* pCmdUI);
	afx_msg void OnNewText();
	afx_msg void OnUpdateNewText(CCmdUI* pCmdUI);
	afx_msg void OnTools();
	afx_msg void OnUpdateTools(CCmdUI* pCmdUI);
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};
////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_MAINFRM_H__A0A86169_32FA_11D5_9D8E_BE3D01A9D579__INCLUDED_)
