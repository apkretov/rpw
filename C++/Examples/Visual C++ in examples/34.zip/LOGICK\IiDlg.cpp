// IiDlg.cpp : implementation file
//

#include "stdafx.h"
#include "logick.h"
#include "IiDlg.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CIiDlg dialog


CIfDlg::CIfDlg(CWnd* pParent /*=NULL*/)
	: CDialog(CIfDlg::IDD, pParent)
{
	//{{AFX_DATA_INIT(CIiDlg)
	m_Oper = _T("");
	m_Sourse1 = _T("");
	m_Sourse2 = _T("");
	//}}AFX_DATA_INIT
}


void CIfDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CIiDlg)
	DDX_CBString(pDX, IDC_COMBO1, m_Oper);
	DDX_Text(pDX, IDC_EDIT1, m_Sourse1);
	DDX_Text(pDX, IDC_EDIT2, m_Sourse2);
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CIfDlg, CDialog)
	//{{AFX_MSG_MAP(CIiDlg)
		// NOTE: the ClassWizard will add message map macros here
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CIiDlg message handlers
