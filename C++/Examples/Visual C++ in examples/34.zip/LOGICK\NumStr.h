// NumStr.h: interface for the CNumStr class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_NUMSTR_H__2A5FFEA1_3F52_11D5_9D8E_F1948412BD68__INCLUDED_)
#define AFX_NUMSTR_H__2A5FFEA1_3F52_11D5_9D8E_F1948412BD68__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

//-------------------------------------------------
class VNumStr : public CString  
{
public:
	VNumStr()        { ;};   // Construction
	BOOL IsNumStr();         // if(string=="number"return(rtue) else return(false))
	long TransformStrToInt();// Transform CString to Integer
	void operator = (CString X){ CString::operator = (X) ;};
	virtual ~VNumStr(){ ;};  // Destruction

};
//-------------------------------------------------
class Variable : public CObject
{
public:	
	CString  m_stName ;
	long     m_lValue ;
public:
	Variable() { m_stName = "", m_lValue = 0 ;};
};
//-------------------------------------------------
class VarList : public CObList
{
public:

	COLORREF m_textColor ;

	VarList():CObList(){  m_textColor  = RGB(0,0,255) ;};
	Variable* FindName(CString & Str);// if Name if to VarList return *
	void AddVariable(Variable* pVar) ;// if(FindName)Add ->this else Add->new
	void Draw(CDC* pDC);
	~VarList() { RemoveAll() ;};
};

//-------------------------------------------------
#endif // !defined(AFX_NUMSTR_H__2A5FFEA1_3F52_11D5_9D8E_F1948412BD68__INCLUDED_)
