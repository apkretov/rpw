#if !defined(AFX_DIALOGVIEWDLG_H__60BEE700_5586_11D5_94BC_C5CD6487AD57__INCLUDED_)
#define AFX_DIALOGVIEWDLG_H__60BEE700_5586_11D5_94BC_C5CD6487AD57__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// DialogViewDlg.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// CDialogViewDlg dialog

class CDialogViewDlg : public CDialog
{
// Construction
public:
	CDialogViewDlg(CWnd* pParent = NULL);   // standard constructor
	CHeaderCtrl m_wndHead  ;
	CListCtrl   m_list     ;

// Dialog Data
	//{{AFX_DATA(CDialogViewDlg)
	enum { IDD = IDD_DIALVIEW };
		// NOTE: the ClassWizard will add data members here
	//}}AFX_DATA


// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CDialogViewDlg)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support

	//}}AFX_VIRTUAL

// Implementation
protected:

	// Generated message map functions
	//{{AFX_MSG(CDialogViewDlg)
	virtual BOOL OnInitDialog();
	afx_msg void OnPaint();
	afx_msg void OnDrawItem(int nIDCtl, LPDRAWITEMSTRUCT lpDrawItemStruct);
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_DIALOGVIEWDLG_H__60BEE700_5586_11D5_94BC_C5CD6487AD57__INCLUDED_)
