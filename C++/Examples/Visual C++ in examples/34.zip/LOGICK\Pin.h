// pin.h: interface for the Cpin class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_pIN_H__C2F51042_33E7_11D5_9D8E_E39C785C8D41__INCLUDED_)
#define AFX_pIN_H__C2F51042_33E7_11D5_9D8E_E39C785C8D41__INCLUDED_

				
#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000


class CPin : public CObject   
{
DECLARE_SERIAL( CPin )
public:
	CPoint m_p ;
	int   n_IDpin  ; 
public:
	CPin(            ){ m_p.x = 0, m_p.y = 0 , n_IDpin = 0  ;};
	CPin(int X, int Y){ m_p.x = X, m_p.y = Y , n_IDpin = 0 ;};
	CPin(  CPoint Ap ){ m_p = Ap ,  n_IDpin = 0 ;};

	bool IsCloseToPin(  CPoint point   );
	virtual ~CPin();
	void Serialize(CArchive& ar);

};
////////////////////////////////////////////////////////
class CNetLine : public CObList
{	
DECLARE_SERIAL( CNetLine )
public:
	CPen m_Pen;
	
public:
	CNetLine():CObList(){  m_Pen.CreatePen(PS_DOT,1,RGB(0,0,0))  ;};

	void AddPin(CPin* pCPin){ AddTail( pCPin ) ;};
	void SetPin(CPin* pCurentPin);	
	void Serialize(CArchive& ar);
	void Delete();

	void Show(CDC* pDC);
	void Hide(CDC* pDC);
	void DrawTMP(CDC* pDC,CPin* pCurentPin);
	void Draw(CDC* pDC);


	~CNetLine()  { RemoveAll() ;};

};
////////////////////////////////////////////////////////
class CPinOut ;

class CPinIn:public CPin
{
DECLARE_SERIAL( CPinIn )
public:
	BOOL m_IsClose  ;
	CPinOut* m_pPrevOut;
public:	
	CPinIn():CPin(){ m_IsClose = false,
					 m_pPrevOut = NULL ;};

	CPinIn(int X, int Y):CPin(X,Y){ m_IsClose = false,
									m_pPrevOut = NULL ;};
	void Draw(CDC* pDC, CBrush* b);
	void KillerLinks();
	void Serialize(CArchive& ar);
};
////////////////////////////////////////////////////////

class CBlock ;

class CPinOut : public CPinIn
{
DECLARE_SERIAL( CPinOut )
public:
	CNetLine m_Line;
	CBlock*  pNext ;
	
public:
	CPinOut():CPinIn(){ pNext = NULL   ;};
	CPinOut(int X, int Y):CPinIn(X,Y){ ;};
	void Draw(CDC* pDC,CBrush* b);
	void KillerLinks();
	void Serialize(CArchive& ar);	
};
////////////////////////////////////////////////////////
#endif // !defined(AFX_pIN_H__C2F51042_33E7_11D5_9D8E_E39C785C8D41__INCLUDED_)
