



/////////////////////////////////////////////////////////////////////////////
// LogickView.h : interface of the CLogickView class
//
/////////////////////////////////////////////////////////////////////////////

#if !defined(AFX_LOGICKVIEW_H__A0A8616F_32FA_11D5_9D8E_BE3D01A9D579__INCLUDED_)
#define AFX_LOGICKVIEW_H__A0A8616F_32FA_11D5_9D8E_BE3D01A9D579__INCLUDED_

#if _MSC_VER > 1000
	#pragma once
#endif       // _MSC_VER > 1000


class CLogickView : public CScrollView
{
protected: // create from serialization only
	CLogickView();
	DECLARE_DYNCREATE(CLogickView)
private :
	bool m_bRunTimeFlaf;
// Attributes
public:
	CLogickDoc* GetDocument();

// Operations
public:
	CPoint m_ContextMenuPoint ;
	bool   m_IsDragingNetLine ;
	CPinOut* m_pOut ;
	CBlock*  m_pBlockActivSetLine;// (OnLButtonUp&&Down) ReSet Pinsfor line to
								  //  coordinades logi
	int m_nTime          ;

	CRect m_RectFocus    ;
	bool m_bRectDraging  ;
// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CLogickView)
	public:
	virtual void OnDraw(CDC* pDC);  // overridden to draw this view
	virtual BOOL PreCreateWindow(CREATESTRUCT& cs);
	virtual void OnInitialUpdate();
	virtual void OnPrepareDC(CDC* pDC, CPrintInfo* pInfo = NULL);
	protected:
	virtual BOOL OnPreparePrinting(CPrintInfo* pInfo);
	virtual void OnBeginPrinting(CDC* pDC, CPrintInfo* pInfo);
	virtual void OnEndPrinting(CDC* pDC, CPrintInfo* pInfo);
	virtual void OnUpdate(CView* pSender, LPARAM lHint, CObject* pHint);
	//}}AFX_VIRTUAL

// Implementation
public:
	void DrawRectFocus(CDC* pDC , CPoint point);
	void HideRectFocus(CDC* pDC);
	virtual ~CLogickView();
#ifdef _DEBUG
	virtual void AssertValid() const;
	virtual void Dump(CDumpContext& dc) const;
#endif

protected:

// Generated message map functions
protected:
	//{{AFX_MSG(CLogickView)
	afx_msg void OnLButtonDown(UINT nFlags, CPoint point);
	afx_msg void OnMouseMove(UINT nFlags, CPoint point);
	afx_msg void OnLButtonUp(UINT nFlags, CPoint point);
	afx_msg BOOL OnSetCursor(CWnd* pWnd, UINT nHitTest, UINT message);
	afx_msg void OnRButtonDown(UINT nFlags, CPoint point);
	afx_msg void OnOpenProperti();
	afx_msg void OnNewSelect();
	afx_msg void OnNewOperation();
	afx_msg void OnNewOperator();
	afx_msg void OnNewIf();
	afx_msg void OnNewIfelse();
	afx_msg void OnNewNode();
	afx_msg void OnNewNetline();
	afx_msg void OnNewFor();
	afx_msg void OnNewWhile();
	afx_msg void OnNewDowhile();
	afx_msg void OnNewSwitch();
	afx_msg void OnBlocDelete();
	afx_msg void OnLButtonDblClk(UINT nFlags, CPoint point);
	afx_msg void OnSoursViewer();
	afx_msg void OnTimer(UINT nIDEvent);
	afx_msg void OnRun();
	afx_msg void OnStopRun();
	afx_msg void OnSetTime();
	afx_msg void OnStepBy();
	afx_msg void OnUpdateRun(CCmdUI* pCmdUI);
	afx_msg void OnUpdateStop(CCmdUI* pCmdUI);
	afx_msg void OnUpdateStepBy(CCmdUI* pCmdUI);
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

#ifndef _DEBUG  // debug version in LogickView.cpp
inline CLogickDoc* CLogickView::GetDocument()
   { return (CLogickDoc*)m_pDocument; }
#endif

/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_LOGICKVIEW_H__A0A8616F_32FA_11D5_9D8E_BE3D01A9D579__INCLUDED_)
