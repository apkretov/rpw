// LogickDoc.cpp : implementation of the CLogickDoc class
//
#include "stdafx.h"
#include "Logick.h"

#include "LogickDoc.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CLogickDoc

IMPLEMENT_DYNCREATE(CLogickDoc, CDocument)

BEGIN_MESSAGE_MAP(CLogickDoc, CDocument)
	//{{AFX_MSG_MAP(CLogickDoc)
		
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CLogickDoc construction/destruction
CLogickDoc::CLogickDoc()
{
}
CLogickDoc::~CLogickDoc()
{
}
//---------------------------------------------------------------------------
BOOL CLogickDoc::OnNewDocument() 
{
	if (!CDocument::OnNewDocument())
		return FALSE;

	CRect rect;  

	rect.left   = 420;
	rect.right  = rect.left + 130;

	rect.top    = 10;
	rect.bottom = 34;

	CBStart*  pStart = new CBStart(rect);
	m_BlockList.AddBlock(pStart);
		
		rect.left   = 420;
		rect.right  = rect.left + 130;

		rect.top    = 470;
		rect.bottom = 494;

	CBEnd* pEnd = new CBEnd(rect);
	m_BlockList.AddBlock(pEnd);

	return TRUE;
}



/////////////////////////////////////////////////////////////////////////////
// CLogickDoc serialization

void CLogickDoc::Serialize(CArchive& ar)
{
	if (ar.IsStoring())
	{
		m_BlockList.Serialize(ar) ;
	}
	else
	{
		m_BlockList.RemoveAll();
		m_BlockList.Serialize(ar) ;
		
	}
}

/////////////////////////////////////////////////////////////////////////////
// CLogickDoc diagnostics

#ifdef _DEBUG
void CLogickDoc::AssertValid() const
{
	CDocument::AssertValid();
}

void CLogickDoc::Dump(CDumpContext& dc) const
{
	CDocument::Dump(dc);
}
#endif //_DEBUG

/////////////////////////////////////////////////////////////////////////////
// CLogickDoc commands
void CLogickDoc::DeleteContents() 
{
	m_BlockList.RemoveAll ();
	CDocument::DeleteContents();
}