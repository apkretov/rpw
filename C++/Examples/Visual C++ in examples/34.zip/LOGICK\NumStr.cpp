// NumStr.cpp: implementation of the CNumStr class.
//
//////////////////////////////////////////////////////////////////////

#include "stdafx.h"
#include "NumStr.h"

//////////////////////////////////////////////////////////////////////
// 
//////////////////////////////////////////////////////////////////////
BOOL VNumStr::IsNumStr()
{
	for (int i = 0; i < GetLength(); i++ )
	{
		char ch = GetAt(i) ;
		if( (ch > '9') || (ch < '0' ) )
			return (false) ;
	}
	return (true);
}
long VNumStr::TransformStrToInt()
{
	long Number = 0 ;
	long k = 1;

	for(int i = GetLength(); i >0 ; i--)
	{
		char ch = GetAt( i - 1 );

		int Sifra = ch - '0' ;
		Number += Sifra * k ;
		k *= 10 ;
	}
	return (Number) ;
}
//-------------------------------------------------
Variable* VarList::FindName(CString & Str) 
{
	POSITION pos = GetHeadPosition();
	while(pos)
	{
		CObject* pObj = GetNext(pos);

		if( ((Variable*)pObj)->m_stName == Str )
			return ((Variable*)pObj) ;
	}
	return NULL ; 
}

void VarList::AddVariable(Variable* pVar)
{
//  finding a Name 
	CString ChecName = pVar->m_stName ;

	POSITION OldPos , CurPos; 	

	CurPos = GetHeadPosition();
	while( CurPos )
	{
		OldPos = CurPos ; 
		CObject* pObj = GetNext(CurPos);
		if( ChecName == ((Variable*)pObj)->m_stName )
		{
			CObject* ra = GetAt(OldPos);//  Save the old pointer 
										//  for deletion
			SetAt(OldPos,pVar);  // Replace the element.       
			delete  ra;          // Deletion avoids memory leak.
			return;
		}
	}
	AddTail(pVar);
}

void VarList::Draw(CDC *pDC)
{
	CString Str ;
	long    Tmp ;
	CString Type;
	int  y = 30 ;

	POSITION pos = GetHeadPosition();
	while(pos)
	{
		CObject* pObj = GetNext(pos);
		Str = ((Variable*)pObj)->m_stName ;
		Tmp = ((Variable*)pObj)->m_lValue ; 
	//--------------------------------------
	char chArr[20]; // transform long to CSrtring 	
	int j = 0   ;
	bool bSiman = (Tmp > -1)? true : false ;
	if(!bSiman)
		Tmp *= -1;
	while(Tmp)
	{
		int Sifra = Tmp % 10 ;
		chArr[j] = Sifra + '0' ;
		Tmp = Tmp / 10       ;
		j++ ;
		
	}
	if(bSiman)
		chArr[j] = 0 ;
	else
		chArr[j] = '-' ;
		chArr[j+1] = 0 ;

	CString strLong = chArr ;
	strLong.MakeReverse();	
	//---------------------------------------
	pDC->SetTextColor(m_textColor);
	pDC->TextOut(20 ,y,Str) ;
	if( strLong == "" )  
			strLong = "0" ;
	pDC->TextOut(120,y,strLong); 
	y  += 20;
	}
}
