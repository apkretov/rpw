// DialogViewDlg.cpp : implementation file
//

#include "stdafx.h"
#include "logick.h"
#include "DialogViewDlg.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CDialogViewDlg dialog


CDialogViewDlg::CDialogViewDlg(CWnd* pParent /*=NULL*/)
	: CDialog(CDialogViewDlg::IDD, pParent)
{
	//{{AFX_DATA_INIT(CDialogViewDlg)
		// NOTE: the ClassWizard will add member initialization here
	//}}AFX_DATA_INIT
}


void CDialogViewDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CDialogViewDlg)
		// NOTE: the ClassWizard will add DDX and DDV calls here
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CDialogViewDlg, CDialog)
	//{{AFX_MSG_MAP(CDialogViewDlg)
	ON_WM_PAINT()
	ON_WM_DRAWITEM()
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CDialogViewDlg message handlers

//	CRect rect ;
//	GetClientRect(rect);

//	m_list.SetWindowPos(this, rect.left ,rect.top ,rect.Width(),rect.Height() ,SWP_SHOWWINDOW); 
BOOL CDialogViewDlg::OnInitDialog() 
{
	CDialog::OnInitDialog();
	CRect rect ;
	GetClientRect(rect);
	m_list.Create( LVS_REPORT | LVS_ICON |WS_VISIBLE, rect ,this,1);	
	return TRUE; 
	// return TRUE unless you set the focus to a control
	// EXCEPTION: OCX Property Pages should return FALSE
}
void CDialogViewDlg::OnPaint() 
{
	CPaintDC dc(this); // device context for painting


	// Do not call CDialog::OnPaint() for painting messages
}

void CDialogViewDlg::OnDrawItem(int nIDCtl, LPDRAWITEMSTRUCT lpDrawItemStruct) 
{
	CRect rect ;
	GetClientRect(rect);

	m_list.SetWindowPos(this, rect.left ,rect.top ,rect.Width(), rect.Height() ,
		               SWP_SHOWWINDOW); 
	// TODO: Add your message handler code here and/or call default
	
	CDialog::OnDrawItem(nIDCtl, lpDrawItemStruct);
}
