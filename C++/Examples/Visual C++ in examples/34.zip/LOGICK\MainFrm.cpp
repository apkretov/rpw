// MainFrm.cpp : implementation of the CMainFrame class
//

#include "stdafx.h"
#include "Logick.h"
#include "Splash.h"

#include "MainFrm.h"


#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CMainFrame

IMPLEMENT_DYNAMIC(CMainFrame, CMDIFrameWnd)

BEGIN_MESSAGE_MAP(CMainFrame, CMDIFrameWnd)
	//{{AFX_MSG_MAP(CMainFrame)
	ON_WM_CREATE()
	ON_COMMAND(ID_NEW_SELECT, OnNewSelect)
	ON_UPDATE_COMMAND_UI(ID_NEW_SELECT, OnUpdateNewSelect)
	ON_COMMAND(ID_NEW_NODE, OnNewNode)
	ON_UPDATE_COMMAND_UI(ID_NEW_NODE, OnUpdateNewNode)
	ON_COMMAND(ID_NEW_NETLINE, OnNewNetline)
	ON_UPDATE_COMMAND_UI(ID_NEW_NETLINE, OnUpdateNewNetline)
	ON_COMMAND(ID_NEW_OPERATOR, OnNewOperator)
	ON_UPDATE_COMMAND_UI(ID_NEW_OPERATOR, OnUpdateNewOperator)
	ON_COMMAND(ID_NEW_OPERATION, OnNewOperation)
	ON_UPDATE_COMMAND_UI(ID_NEW_OPERATION, OnUpdateNewOperation)
	ON_COMMAND(ID_NEW_IF, OnNewIf)
	ON_UPDATE_COMMAND_UI(ID_NEW_IF, OnUpdateNewIf)
	ON_COMMAND(ID_NEW_IFELSE, OnNewIfelse)
	ON_UPDATE_COMMAND_UI(ID_NEW_IFELSE, OnUpdateNewIfelse)
	ON_COMMAND(ID_NEW_FOR, OnNewFor)
	ON_UPDATE_COMMAND_UI(ID_NEW_FOR, OnUpdateNewFor)
	ON_COMMAND(ID_NEW_WHILE, OnNewWhile)
	ON_UPDATE_COMMAND_UI(ID_NEW_WHILE, OnUpdateNewWhile)
	ON_COMMAND(ID_NEW_DOWHILE, OnNewDowhile)
	ON_UPDATE_COMMAND_UI(ID_NEW_DOWHILE, OnUpdateNewDowhile)
	ON_COMMAND(ID_NEW_SWITCH, OnNewSwitch)
	ON_UPDATE_COMMAND_UI(ID_NEW_SWITCH, OnUpdateNewSwitch)
	ON_COMMAND(ID_NEW_TEXT, OnNewText)
	ON_UPDATE_COMMAND_UI(ID_NEW_TEXT, OnUpdateNewText)
	ON_COMMAND(ID_TOOLS, OnTools)
	ON_UPDATE_COMMAND_UI(ID_TOOLS, OnUpdateTools)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

static UINT indicators[] =
{
	ID_SEPARATOR,           // status line indicator
	ID_INDICATOR_CAPS,
	ID_INDICATOR_NUM,
	ID_INDICATOR_SCRL,
};

/////////////////////////////////////////////////////////////////////////////
// CMainFrame construction/destruction

CMainFrame::CMainFrame()
{
	m_SelectTools = ID_NEW_SELECT;

	
}

CMainFrame::~CMainFrame()
{
		
}

int CMainFrame::OnCreate(LPCREATESTRUCT lpCreateStruct)
{
	if (CMDIFrameWnd::OnCreate(lpCreateStruct) == -1)
		return -1;
	
	if (!m_wndToolBar.CreateEx(this, TBSTYLE_FLAT, WS_CHILD | WS_VISIBLE | CBRS_TOP
		| CBRS_GRIPPER | CBRS_TOOLTIPS | CBRS_FLYBY | CBRS_SIZE_DYNAMIC) ||
		!m_wndToolBar.LoadToolBar(IDR_MAINFRAME))
	{
		TRACE0("Failed to create toolbar\n");
		return -1;      // fail to create
	}
	m_wndToolBar.EnableDocking(CBRS_ALIGN_ANY);
	EnableDocking(CBRS_ALIGN_ANY);
	DockControlBar(&m_wndToolBar);
	//------------------------------------------------------
	if (!m_wndStatusBar.Create(this) ||
		!m_wndStatusBar.SetIndicators(indicators,
		  sizeof(indicators)/sizeof(UINT)))
	{
		TRACE0("Failed to create status bar\n");
		return -1;      // fail to create
	}
	//-------------------------------------------------------
	//	CToolBar    m_wndTools   ; // IRD_TOOLSBAR
	if (!m_wndTools.CreateEx(this, TBSTYLE_FLAT, WS_CHILD | WS_VISIBLE | CBRS_RIGHT   
		| CBRS_GRIPPER | CBRS_TOOLTIPS | CBRS_FLYBY | CBRS_SIZE_DYNAMIC) ||
		!m_wndTools.LoadToolBar(IDR_TOOLSBAR))
	{
		TRACE0("Failed to create toolbar\n");
		return -1;      // fail to create
	}
	m_wndTools.EnableDocking(CBRS_ALIGN_ANY);
	EnableDocking(CBRS_ALIGN_ANY);
	DockControlBar(&m_wndTools);

	m_wndTools.SetWindowText(_T("ToolBar ---> Select"));

//----------------------------------------x,y:
//	CPoint pt(::GetSystemMetrics(SM_CYSCREEN)-340,
//			  ::GetSystemMetrics(SM_CYSCREEN)-120) ; 
//	CPoint pt(188,380);
//	FloatControlBar(&m_wndTools , pt) ;
	//------------------------------- for CSplashWnd
	CSplashWnd::ShowSplashScreen(this);
	//----------------------------------------------	
	return 0;
}

BOOL CMainFrame::PreCreateWindow(CREATESTRUCT& cs)
{
	if( !CMDIFrameWnd::PreCreateWindow(cs) )
		return FALSE;
	
	return TRUE;
}

/////////////////////////////////////////////////////////////////////////////
// CMainFrame diagnostics

#ifdef _DEBUG
void CMainFrame::AssertValid() const
{
	CMDIFrameWnd::AssertValid();
}

void CMainFrame::Dump(CDumpContext& dc) const
{
	CMDIFrameWnd::Dump(dc);
}

#endif //_DEBUG

/////////////////////////////////////////////////////////////////////////////
// CMainFrame message handlers

void CMainFrame::OnTools() 
{
	BOOL bVisible = ((m_wndTools.GetStyle()&WS_VISIBLE)!=0);
	ShowControlBar(&m_wndTools,!bVisible,FALSE);
	RecalcLayout();
}

void CMainFrame::OnUpdateTools(CCmdUI* pCmdUI) 
{
	BOOL bVisible = ((m_wndTools.GetStyle()&WS_VISIBLE)!=0);
	pCmdUI->SetCheck (bVisible);
}
//-----------------------------------------------------------
// m_SelectTools = ID
//-----------------------------------------------------------
void CMainFrame::OnNewSelect() 
{
	m_SelectTools = ID_NEW_SELECT ;
}

void CMainFrame::OnUpdateNewSelect(CCmdUI* pCmdUI) 
{
	pCmdUI->SetCheck (m_SelectTools == ID_NEW_SELECT ? 1:0);	
}
//------------------------------------------------------------
void CMainFrame::OnNewNode() 
{
	m_SelectTools = ID_NEW_NODE;	
}

void CMainFrame::OnUpdateNewNode(CCmdUI* pCmdUI) 
{
	pCmdUI->SetCheck (m_SelectTools == ID_NEW_NODE ? 1:0);	
	
}
//------------------------------------------------------------
void CMainFrame::OnNewNetline() 
{
	m_SelectTools = ID_NEW_NETLINE;	
}

void CMainFrame::OnUpdateNewNetline(CCmdUI* pCmdUI) 
{
	pCmdUI->SetCheck (m_SelectTools == ID_NEW_NETLINE ? 1:0);		
}
//------------------------------------------------------------
void CMainFrame::OnNewOperator() 
{
	m_SelectTools = ID_NEW_OPERATOR;	
}

void CMainFrame::OnUpdateNewOperator(CCmdUI* pCmdUI) 
{
pCmdUI->SetCheck (m_SelectTools == ID_NEW_OPERATOR ? 1:0);		
}
//------------------------------------------------------------
void CMainFrame::OnNewOperation() 
{
	m_SelectTools = ID_NEW_OPERATION;	
}

void CMainFrame::OnUpdateNewOperation(CCmdUI* pCmdUI) 
{
pCmdUI->SetCheck (m_SelectTools == ID_NEW_OPERATION ? 1:0);
}
//------------------------------------------------------------
void CMainFrame::OnNewIf() 
{
	m_SelectTools = ID_NEW_IF;
}

void CMainFrame::OnUpdateNewIf(CCmdUI* pCmdUI) 
{
pCmdUI->SetCheck (m_SelectTools == ID_NEW_IF ? 1:0);	
}
//------------------------------------------------------------
void CMainFrame::OnNewIfelse() 
{
	m_SelectTools = ID_NEW_IFELSE;
}

void CMainFrame::OnUpdateNewIfelse(CCmdUI* pCmdUI) 
{
pCmdUI->SetCheck (m_SelectTools == ID_NEW_IFELSE ? 1:0);		
}
//------------------------------------------------------------
void CMainFrame::OnNewFor() 
{
	m_SelectTools = ID_NEW_FOR;	
}

void CMainFrame::OnUpdateNewFor(CCmdUI* pCmdUI) 
{
pCmdUI->SetCheck (m_SelectTools == ID_NEW_FOR ? 1:0);		
}
//------------------------------------------------------------
void CMainFrame::OnNewWhile() 
{
	m_SelectTools = ID_NEW_WHILE;		
}

void CMainFrame::OnUpdateNewWhile(CCmdUI* pCmdUI) 
{
pCmdUI->SetCheck (m_SelectTools == ID_NEW_WHILE ? 1:0);		
}
//------------------------------------------------------------
void CMainFrame::OnNewDowhile() 
{
	m_SelectTools = ID_NEW_DOWHILE;	
}

void CMainFrame::OnUpdateNewDowhile(CCmdUI* pCmdUI) 
{
pCmdUI->SetCheck (m_SelectTools ==  ID_NEW_DOWHILE ? 1:0);		
}
//------------------------------------------------------------
void CMainFrame::OnNewSwitch() 
{
	m_SelectTools = ID_NEW_SWITCH;		
}

void CMainFrame::OnUpdateNewSwitch(CCmdUI* pCmdUI) 
{
pCmdUI->SetCheck (m_SelectTools ==  ID_NEW_SWITCH ? 1:0);			
}
//------------------------------------------------------------
void CMainFrame::OnNewText() 
{
	m_SelectTools = ID_NEW_TEXT;
	
}
void CMainFrame::OnUpdateNewText(CCmdUI* pCmdUI) 
{
pCmdUI->SetCheck (m_SelectTools ==  ID_NEW_TEXT ? 1:0);	
}
//------------------------------------------------------------


