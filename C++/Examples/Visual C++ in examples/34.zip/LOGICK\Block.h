// Block.h: interface for the CBlock class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_BLOCK_H__21AF6319_33E4_11D5_9D8E_E39C785C8D41__INCLUDED_)
#define AFX_BLOCK_H__21AF6319_33E4_11D5_9D8E_E39C785C8D41__INCLUDED_


//-----------------------------------------------------------
#include "NumStr.h"  // including al class : VNumStr 
//                                           Variable 
#include "Pin.h"
//-----------------------------------------------------------

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
////////////////////////////////////////////////////////////////////////////

////////////////////////////////////////////////////////////////////////////
class CMyTracker:public CRectTracker // helper 
{
public:                                  
	virtual UINT GetHandleMask( ) const
	{	//        * Set 4  Mask Tracker - Pins, for tracker
		return (15)       //                   CRectTracker
	;};   	//          0*____*1      1*____*2	                         	 
	        //           |    |	       |    |    ( 15 )
	        //          3*----*2      8*----*4           
};   //-----------------------------------------------------------------


////////////////////////////////////////////////////////////
//							C B L O C K - basis class 
////////////////////////////////////////////////////////////
class CBlock : public CObject 
{
DECLARE_SERIAL( CBlock )
public://   Attributes
	static COLORREF Gamma[8];  // * Color Gamma          
	COLORREF    bk_color    ;  // * bjgraund  color
	COLORREF    oper_color  ;  // * opetation color (run)
public:
	CMyTracker m_Track  ;      //  m_Track.m_rect - device coordinates ...
	CRect      m_LogRect;      //  m_LogRect - logical coordinates ....
	CString m_Text      ;      //  text
	BOOL InOperMode     ;      //  if( In Operation Mode) == TRUE  (run)
	int n_ID            ;      //  for Serialize  //

public://   Construction : 
	CBlock();                  // ()
	CBlock(CPoint point) ; // ( CPoint )
	CBlock(CRect   rect) ; // ( CRect  ) 
    //--------------------------------------- Operations :

	//	Draw  :
	void Draw(CDC* pDC)  ;
	void DrawTXT(CDC* pDC);
	virtual void DrawBlock (CDC* pDC) { ;} ;
	virtual void DrawPin   (CDC* pDC) { ;} ;
	virtual void  DrawLines(CDC* pDC) { ;} ;
	//---------------------------------------------------

	//---------------------------------------------------
	virtual void SetPins  (CRect rect) { ;} ;// helper for DrawPin()
	virtual void EnterProperties()     { ;} ;	
	virtual void Operat(VarList& pVars,CWnd* pCWnd){ ;}

	virtual CBlock* Next() {return NULL ;} ;
	virtual CPinIn*  IsCloseToPinIn (CPoint point,CBlock* &pBlock){return NULL ;};
	virtual CPinOut* IsCloseToPinOut(CPoint point,CBlock* &pBlock){return NULL ;};	
	//---------------------------------------------------

	//    Tracking :
	virtual bool IsClosePinInToLine() {return false ;} ;
	virtual CPinOut* IsClosePinOutToLine(){return NULL ;} ;
	virtual void ReSetLine() { ;};
	//---------------------------------------------------
	
	//   Serialize :									   //  helper :
	virtual void SavePinOutID(int nID)     {            ;};//  save file
	virtual bool SavePinInID (CBlock* pCar){return false;};//  save file
	virtual int HelperSavePinInID(CPinOut* pPrev){return NULL;};//save file
	virtual bool FindNext ( CBlock* pCar)  {return false;}; //  open file
	virtual CBlock* HelperFindNext(int ID ){return NULL;};  //  open file
	virtual bool FindPrevOut(CBlock* pCar ){return false;}; //  open file
	virtual CPinOut* HelperFindPrevOut(int ID){return NULL;}; //open file
	void Serialize(CArchive& ar);
	//---------------------------------------------------

	//    Delete
	virtual void OpenBlockNext() { ;};   
	virtual void OpenBlockPrev() { ;};    
	virtual ~CBlock(){             ;}; 
	//---------------------------------------------------

};
////////////////////////////////////////////////////////////
//						         C B O P E R A T O R
////////////////////////////////////////////////////////////
class CBOperator : public CBlock
{

DECLARE_SERIAL( CBOperator )
public:// Attributes :
	CPinIn	m_PinIn ;
	CPinOut m_PinOut;
	//      d a t a  :
	VNumStr m_Name ;
	VNumStr m_Value;

public://  Construction :
	CBOperator():CBlock()                  { ;};
	CBOperator(CPoint point):CBlock(point) {m_Name = "" ; m_Value = "";};
	CBOperator(CRect rect):CBlock(rect)    { ;};
    //--------------------------------------- Operations :
	//      Draw   :
	virtual void DrawBlock(CDC* pDC);
	virtual void DrawPin(CDC* pDC);
	virtual void  DrawLines(CDC* pDC);
	//----------------------------------------------------
	//----------------------------------------------------
	virtual void SetPins(CRect rect);
	virtual void EnterProperties();
	virtual void Operat(VarList& pVars,CWnd* pCWnd)  ;

	virtual CPinIn*  IsCloseToPinIn (CPoint point,CBlock* &pBlock);
	virtual CPinOut* IsCloseToPinOut(CPoint point,CBlock* &pBlock);
	virtual CBlock* Next(){ return (m_PinOut.pNext) ;};

	//----------------------------------------------------
	//	Tracking  :
	virtual bool IsClosePinInToLine() ;
	virtual CPinOut* IsClosePinOutToLine() ;
	virtual void ReSetLine(); 
	//---------------------------------------------------
	//  Serialize:                            // helpers :
	virtual void SavePinOutID(int nID);       //  save file
	virtual bool SavePinInID (CBlock* pCar);  //  save file
	virtual int HelperSavePinInID(CPinOut* pPrev);//save file
	virtual bool FindNext    (CBlock* pCar);  //  open file
	virtual CBlock* HelperFindNext(int ID );  //  open file
	virtual bool FindPrevOut(CBlock* pCar );   // open file
	virtual CPinOut* HelperFindPrevOut(int ID);// open file
	void Serialize(CArchive& ar);
	//-------------------------------------------------

	//---------------------------------------------Delete
	virtual void OpenBlockNext();
	virtual void OpenBlockPrev();
	virtual ~CBOperator(); 
	//---------------------------------------------------
};
////////////////////////////////////////////////////////////
//						         	C B S T A R T
////////////////////////////////////////////////////////////
class CBStart : public CBOperator
{
DECLARE_SERIAL( CBStart )
public:
	CBStart():CBOperator() { m_Text= "Start" ;};
	CBStart(CPoint point):CBOperator(point) { m_Text= "Start" ;};
	CBStart(CRect rect):CBOperator(rect)   
	{ m_Text= "Start",m_Track.m_nStyle = NULL;};
	//
	virtual void DrawBlock(CDC* pDC);
	virtual void DrawPin(CDC* pDC);
	virtual CPinIn*  IsCloseToPinIn (CPoint point,CBlock* &pBlock);
	virtual void EnterProperties(){   ;};
	virtual void Operat(VarList& pVars,CWnd* pCWnd){ ;};
	void Serialize(CArchive& ar);
};
////////////////////////////////////////////////////////////
//						         C B O P E R A T I O N
////////////////////////////////////////////////////////////
class CBOperaction : public CBOperator
{
DECLARE_SERIAL( CBOperaction )
public:
//	VNumStr m_NameDect;
	VNumStr m_Source1 ;
	VNumStr m_Source2 ;
	CString m_Oper    ;

public:
	CBOperaction():CBOperator ()                  { ;};
	CBOperaction(CPoint point): CBOperator(point) 
	{ m_Source1 = "" ; m_Source2 ="" ; m_Oper = ""  ;};
	CBOperaction(CRect rect):CBOperator(rect)     { ;};
	virtual void DrawBlock(CDC* pDC) ;
	virtual void EnterProperties()   ;
	virtual void Operat(VarList& pVars,CWnd* pCWnd);
	void Serialize(CArchive& ar);
};
////////////////////////////////////////////////////////////
//						         	    C B E N D
////////////////////////////////////////////////////////////
class CBEnd : public CBOperator
{
DECLARE_SERIAL( CBEnd )
public:
	CBEnd():CBOperator ()                  { m_Text= "End" ;};
	CBEnd(CPoint point): CBOperator(point) { m_Text= "End" ;};
	CBEnd(CRect rect):CBOperator(rect)     { m_Text= "End",m_Track.m_nStyle = NULL ;};
	virtual void DrawBlock(CDC* pDC);
	virtual void DrawPin(CDC* pDC);
	virtual CPinOut* IsCloseToPinOut(CPoint point,CBlock* &pBlock);
	virtual void EnterProperties(){   ;}
	virtual CBlock* Next() { return ( NULL ) ;};
	virtual void Operat(VarList& pVars,CWnd* pCWnd){ ;};

	void Serialize(CArchive& ar);

};
////////////////////////////////////////////////////////////
//    						         	C B N O D E
////////////////////////////////////////////////////////////
class CBNode : public CBOperator
{
DECLARE_SERIAL( CBNode )
private:
	int  nCauntPinInClosed ;
	bool bFlagSetClosed    ;
public:
	CPinIn  m_PinInL;
	CPinIn  m_PinInR;
public:
	CBNode():CBOperator (){nCauntPinInClosed = 0,bFlagSetClosed= false ;};
	CBNode(CPoint point);
	CBNode(CRect rect)  :CBOperator (rect)  
	{nCauntPinInClosed = 0 ,bFlagSetClosed = false ;};
   
	virtual void DrawBlock(CDC* pDC);
	virtual void DrawPin(CDC* pDC)  ;
	virtual void SetPins(CRect rect);
	virtual CPinIn*  IsCloseToPinIn (CPoint point,CBlock* &pBlock);	
	virtual void EnterProperties(){  ;};
	virtual void  DrawLines(CDC* pDC);
	virtual void Operat(VarList& pVars,CWnd* pCWnd){ ;};
	//----------------------------------
	virtual bool IsClosePinInToLine() ;// Track
	virtual void ReSetLine();
	//----------------------------------
	virtual void OpenBlockNext();     //
	virtual ~CBNode();

	virtual bool SavePinInID (CBlock* pCar);// helper save file
	virtual CBlock* HelperFindNext(int ID );// helper open file
	virtual bool FindPrevOut(CBlock* pCar );// helper open file
	void Serialize(CArchive& ar);

};
////////////////////////////////////////////////////////////
//						         			C B I F
////////////////////////////////////////////////////////////
class CBIf: public CBOperator
{
DECLARE_SERIAL( CBIf )
private:
	bool Result ;
	bool  bFlag ;//for Serialize --> FindNext(
	int   nTmp  ;//for Serialize --> FindNext(
public:
	VNumStr m_Source1;
	VNumStr m_Source2;
	CString m_BoolOper; //<,<=,>,>=,==,!=,! ;

public:
	CPinOut m_PinOutNo;  //  L
	CPinOut m_PinOutYes; //  R
public:
	CBIf():CBOperator ()                  {bFlag = false;};
	CBIf(CPoint point):CBOperator (point) {bFlag = false;};
	CBIf(CRect rect):CBOperator (rect)    {bFlag = false;};

	virtual void DrawBlock(CDC* pDC);
	virtual void DrawPin(CDC* pDC);
	virtual void ReSetLine();
	virtual void SetPins(CRect rect);
	virtual CPinOut* IsCloseToPinOut(CPoint point,CBlock* &pBlock);
	virtual void EnterProperties();
	virtual void Operat(VarList& pVars,CWnd* pCWnd);

	virtual CBlock* Next(){ if (Result) 
								return(m_PinOutYes.pNext);
							else 
								return (m_PinOutNo.pNext) ;};
	
	virtual CPinOut* IsClosePinOutToLine() ;

	virtual void SavePinOutID(int nID); // helper save file
	virtual int HelperSavePinInID(CPinOut* pPrev);// helper save file
	virtual bool FindNext(CBlock* pCar);// helper open file
	virtual CPinOut* HelperFindPrevOut(int ID);// helper open file
	
	void Serialize(CArchive& ar);
	
	virtual ~CBIf();
};

////////////////////////////////////////////////////////////////
//									C  B L O C K  L I S T
////////////////////////////////////////////////////////////////
class CBlockList : public CObList
{
DECLARE_SERIAL( CBlockList )

public:
	CBlock* m_pOldBlock ;
	CBlock* m_pCurBlock ;
	bool m_IsInitStepByStep ;
public:
	CBlockList()
	{m_pOldBlock = m_pCurBlock = NULL ,m_IsInitStepByStep= false;};

	void AddBlock(CBlock* pS);
	void DeleteBlock(CPoint point);
	void SetRectTrackerStyle(CWnd* pWnd, CPoint point) ; 
	void OnDraw(CDC* pDC);
	
	CBlock*  IsPointIn(CPoint point);
	CPinIn*  IsCloseToPinIn (CPoint point,CBlock* &pBlock);
	CPinOut* IsCloseToPinOut(CPoint point,CBlock* &pBlock);
	CBlock*  IsTracingBlock(CWnd* pWnd ,CPoint  point,CClientDC* p_dc);
	CPinOut* IsClosePinOutToLine(CPoint point);

	void Start() ;
	void Operate(VarList& pVars,CWnd* pCWnd);
	void StepByStep(VarList& pVars,CWnd* pCWnd );
	
	virtual ~CBlockList();
	void Serialize(CArchive& ar);
};
////////////////////////////////////////////////////////////
//
////////////////////////////////////////////////////////////

#endif // !defined(AFX_BLOCK_H__21AF6319_33E4_11D5_9D8E_E39C785C8D41__INCLUDED_)
