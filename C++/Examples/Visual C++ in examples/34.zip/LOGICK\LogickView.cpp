//
//
//                                          LogickView.cpp : 
//                   implementation of the CLogickView class
//                                  CLogickView::CScrollView
//
#include "stdafx.h"
#include "Logick.h"
#include  "Block.h"
#include "LogickDoc.h"
#include "LogickView.h"
#include "MainFrm.h"
#include "SourseView.h"
#include "TimeDlg.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CLogickView
IMPLEMENT_DYNCREATE(CLogickView, CScrollView)// MFC Generator

BEGIN_MESSAGE_MAP(CLogickView, CScrollView)
	//{{AFX_MSG_MAP(CLogickView)
	ON_WM_LBUTTONDOWN()
	ON_WM_MOUSEMOVE()
	ON_WM_LBUTTONUP()
	ON_WM_SETCURSOR()
	ON_WM_RBUTTONDOWN()
	ON_COMMAND(ID_OPEN_PROPERTI, OnOpenProperti)
	ON_COMMAND(ID_NEW_SELECT, OnNewSelect)
	ON_COMMAND(ID_NEW_OPERATION, OnNewOperation)
	ON_COMMAND(ID_NEW_OPERATOR, OnNewOperator)
	ON_COMMAND(ID_NEW_IF, OnNewIf)
	ON_COMMAND(ID_NEW_IFELSE, OnNewIfelse)
	ON_COMMAND(ID_NEW_NODE, OnNewNode)
	ON_COMMAND(ID_NEW_NETLINE, OnNewNetline)
	ON_COMMAND(ID_NEW_FOR, OnNewFor)
	ON_COMMAND(ID_NEW_WHILE, OnNewWhile)
	ON_COMMAND(ID_NEW_DOWHILE, OnNewDowhile)
	ON_COMMAND(ID_NEW_SWITCH, OnNewSwitch)
	ON_COMMAND(ID_BLOC_DELETE, OnBlocDelete)
	ON_WM_LBUTTONDBLCLK()
	ON_COMMAND(ID_SOURS_VIEWER, OnSoursViewer)
	ON_WM_TIMER()
	ON_COMMAND(ID_RUN, OnRun)
	ON_COMMAND(ID_STOP, OnStopRun)
	ON_COMMAND(ID_SET_TIME, OnSetTime)
	ON_COMMAND(ID_STEP_BY, OnStepBy)
	ON_UPDATE_COMMAND_UI(ID_RUN, OnUpdateRun)
	ON_UPDATE_COMMAND_UI(ID_STOP, OnUpdateStop)
	ON_UPDATE_COMMAND_UI(ID_STEP_BY, OnUpdateStepBy)
	//}}AFX_MSG_MAP
	// Standard printing commands
	ON_COMMAND(ID_FILE_PRINT, CScrollView::OnFilePrint)
	ON_COMMAND(ID_FILE_PRINT_DIRECT, CScrollView::OnFilePrint)
	ON_COMMAND(ID_FILE_PRINT_PREVIEW, CScrollView::OnFilePrintPreview)
END_MESSAGE_MAP()
/////////////////////////////////////////////////////////////////////////////

// CLogickView construction/destruction
CLogickView::CLogickView()
{
	m_IsDragingNetLine = false ;
	m_bRectDraging     = false ;
	m_bRunTimeFlaf     = false ;
	m_nTime            = 500   ;    // set  time RUN (msec)
}
CLogickView::~CLogickView()
{
}
BOOL CLogickView::PreCreateWindow(CREATESTRUCT& cs)
{
	return CScrollView::PreCreateWindow(cs);

}
/////////////////////////////////////////////////////////////////////////////
//                                                       CLogickView::OnDraw
void CLogickView::OnDraw(CDC* pDC)
{
	CLogickDoc* pDoc = GetDocument();
	ASSERT_VALID(pDoc);
	pDoc->m_BlockList.OnDraw(pDC);

}
/////////////////////////////////////////////////////////////////////////////
//                                                      CLogickView printing

BOOL CLogickView::OnPreparePrinting(CPrintInfo* pInfo)
{
	return DoPreparePrinting(pInfo);
}
void CLogickView::OnBeginPrinting(CDC* /*pDC*/, CPrintInfo* /*pInfo*/)
{

}
void CLogickView::OnEndPrinting(CDC* /*pDC*/, CPrintInfo* /*pInfo*/)
{

}
/////////////////////////////////////////////////////////////////////////////
// CLogickView diagnostics
#ifdef _DEBUG
void CLogickView::AssertValid() const
{
	CScrollView::AssertValid();
}
void CLogickView::Dump(CDumpContext& dc) const
{
	CScrollView::Dump(dc);
}
CLogickDoc* CLogickView::GetDocument() // non-debug version is inline
{
	ASSERT(m_pDocument->IsKindOf(RUNTIME_CLASS(CLogickDoc)));
	return (CLogickDoc*)m_pDocument;
}
#endif //_DEBUG




////////////////////////////////////////////////////////////////
///////////////////////////////////       //     SCENARIY     //
////////////////////////////////////////////////////////////////
void CLogickView::OnLButtonDown(UINT nFlags, CPoint point)
{

	CLogickDoc* pDoc = GetDocument();    
	ASSERT_VALID(pDoc);

	CDC* pDC;
	pDC = GetDC();
//									       	Device coordinates	                     
	CClientDC  dc(this);
	OnPrepareDC(&dc)   ;	
	bool bFlagTracking = false ;	        								
/////////////////////////////////////////////////////////////////
	pDoc->m_BlockList.SetRectTrackerStyle( this, point );
///////////////////////////////////////////////////////////////// 
	if(pDoc->m_BlockList.IsTracingBlock(this, point, &dc )) 
		bFlagTracking = true ;                               
/////////////////////////////////////////////////////////////////    
	CBlock* pBlockIsPointIn = pDoc->m_BlockList.IsPointIn(point) ;
	switch(((CMainFrame*) AfxGetMainWnd()) ->m_SelectTools )
	{
		case ID_NEW_SELECT : 
		{
		if(!(pBlockIsPointIn) && !(bFlagTracking)) 
			{
				SetCapture();             
				RECT Rect ;
				GetClientRect (&Rect);
				ClientToScreen(&Rect);
				::ClipCursor  (&Rect);

				m_RectFocus.left   = point.x ;
			    m_RectFocus.right  = point.x;
				m_RectFocus.top    = point.y;
				m_RectFocus.bottom = point.y;
				m_bRectDraging = true ;
			}
		break;
		}		
		case ID_NEW_OPERATION:
		{
		if(!(pBlockIsPointIn)  && !(bFlagTracking)) 
			{	
				CBlock* pB = new CBOperaction(point);
				pDoc->m_BlockList.AddBlock(pB);
				 pB->Draw (pDC);
				//---------------------------------DPtoLP()
				pB->m_LogRect = pB->m_Track.m_rect;
				dc.DPtoLP( pB->m_LogRect );
				//-----------------------------------
				OnNewSelect();  
				
			}
			break;
		}
		case ID_NEW_OPERATOR:
		{
		if(!(pBlockIsPointIn)  && !(bFlagTracking)) 
			{	
				CBlock* pB = new CBOperator(point);
				pDoc->m_BlockList.AddBlock(pB);
				pB->Draw (pDC);
				//---------------------------------DPtoLP()
				pB->m_LogRect = pB->m_Track.m_rect;
				dc.DPtoLP( pB->m_LogRect );
				//-----------------------------------	
				
				OnNewSelect();   
			}
			break;
		}
		case ID_NEW_IF :
		{
		if(!(pBlockIsPointIn) && !(bFlagTracking)) 
			{	
				CBlock* pB = new CBIf(point); 
				pDoc->m_BlockList.AddBlock(pB);  
				pB->Draw (pDC);
				//---------------------------------DPtoLP()
				pB->m_LogRect = pB->m_Track.m_rect;
				dc.DPtoLP( pB->m_LogRect );
				//-----------------------------------
				OnNewSelect();   
			}
			break;
		}
		case ID_NEW_NODE :
		{
		if(!(pBlockIsPointIn)&& !(bFlagTracking)) 
			{	
				CBlock* pB = new CBNode(point); 
				pDoc->m_BlockList.AddBlock(pB);  
				pB->Draw (pDC);
				//---------------------------------DPtoLP()
				pB->m_LogRect = pB->m_Track.m_rect;
				dc.DPtoLP( pB->m_LogRect );
				//-----------------------------------
				OnNewSelect();
			}
			break;
		}
		case ID_NEW_IFELSE :
		{
		if(!(pBlockIsPointIn) && !(bFlagTracking)) 
			{	

				CBlock* pIf = new CBIf(point);//      IF
				pDoc->m_BlockList.AddBlock(pIf);
				pIf->Draw (pDC);

				//---------------------------------DPtoLP()
				pIf->m_LogRect = pIf->m_Track.m_rect;
				dc.DPtoLP( pIf->m_LogRect );
				//-----------------------------------

				CPoint Tmp = point;         //       YES
				Tmp.x += 65 ;Tmp.y += 50 ;
				CBlock* pYes = new CBOperaction(Tmp);
				pDoc->m_BlockList.AddBlock(pYes);
				pYes->Draw(pDC);

				//---------------------------------DPtoLP()
				pYes->m_LogRect = pYes->m_Track.m_rect;
				dc.DPtoLP( pYes->m_LogRect );
				//-----------------------------------

				Tmp = point;              //         NO
				Tmp.x -= 65 ;Tmp.y += 50 ;
				CBlock* pNo = new CBOperaction(Tmp);
				pDoc->m_BlockList.AddBlock(pNo);
				pNo->Draw(pDC);

				//---------------------------------DPtoLP()
				pNo->m_LogRect = pNo->m_Track.m_rect;
				dc.DPtoLP( pNo->m_LogRect );
				//-----------------------------------
				OnNewSelect();
			}
			break;
		}
		case ID_NEW_FOR  ://-------------------------------------------------
		{
		if(!(pDoc->m_BlockList.IsPointIn(point)) && !(bFlagTracking)) 
			{
				CPoint Tmp = point;           // for(#,,){;}
				Tmp.y -= 90 ;
				CBlock* pIthul = new CBOperator(Tmp);
				pDoc->m_BlockList.AddBlock(pIthul);
				pIthul->Draw(pDC);
				//---------------------------------DPtoLP()
				pIthul->m_LogRect = pIthul->m_Track.m_rect;
				dc.DPtoLP( pIthul->m_LogRect );
				//-----------------------------------

				Tmp = point;           // N O D E 
				Tmp.y -= 45 ;
				CBlock* pNode = new CBNode(Tmp);
				pDoc->m_BlockList.AddBlock(pNode);
				pNode->Draw(pDC);
				//---------------------------------DPtoLP()
				pNode->m_LogRect = pNode->m_Track.m_rect;
				dc.DPtoLP( pNode->m_LogRect );
				//-----------------------------------

	            CBlock* pIf = new CBIf(point);// FOR(,#,){;}
				pDoc->m_BlockList.AddBlock(pIf);
				pIf->Draw (pDC);
				//---------------------------------DPtoLP()
				pIf->m_LogRect = pIf->m_Track.m_rect;
				dc.DPtoLP( pIf->m_LogRect );
				//-----------------------------------
			
				Tmp = point;      // for(,,#){}
				Tmp.x += 65 ;Tmp.y += 30 ;
				CBlock* pCidum = new CBOperaction(Tmp);
				pDoc->m_BlockList.AddBlock(pCidum);
				pCidum->Draw(pDC);
				//---------------------------------DPtoLP()
				pCidum->m_LogRect = pCidum->m_Track.m_rect;
				dc.DPtoLP( pCidum->m_LogRect );
				//-----------------------------------

				Tmp = point;           // for(,,){###;} 
				Tmp.x += 65 ;Tmp.y += 75 ;
				CBlock* pGuf = new CBOperaction(Tmp);
				pDoc->m_BlockList.AddBlock(pGuf);
				pGuf->Draw(pDC);
				//---------------------------------DPtoLP()
				pGuf->m_LogRect = pGuf->m_Track.m_rect;
				dc.DPtoLP( pGuf->m_LogRect );
				//-----------------------------------



			OnNewSelect();	
			}
			break;
		}
	
		case ID_NEW_WHILE  ://-------------------------------------------------
		{
		if(!(pDoc->m_BlockList.IsPointIn(point)) && !(bFlagTracking)) 
		{                             //  i= 0    ;
		CPoint Tmp = point;           //  while(){;}
				Tmp.y -= 90 ;
				CBlock* pIthul = new CBOperator(Tmp);
				pDoc->m_BlockList.AddBlock(pIthul);
				pIthul->Draw(pDC);
				//---------------------------------DPtoLP()
				pIthul->m_LogRect = pIthul->m_Track.m_rect;
				dc.DPtoLP( pIthul->m_LogRect );
				//-----------------------------------

				Tmp = point;           // N O D E 
				Tmp.y -= 45 ;
				CBlock* pNode = new CBNode(Tmp);
				pDoc->m_BlockList.AddBlock(pNode);
				pNode->Draw(pDC);
				//---------------------------------DPtoLP()
				pNode->m_LogRect = pNode->m_Track.m_rect;
				dc.DPtoLP( pNode->m_LogRect );
				//-----------------------------------

	            CBlock* pIf = new CBIf(point);// while(#){;}
				pDoc->m_BlockList.AddBlock(pIf);
				pIf->Draw (pDC);
				//---------------------------------DPtoLP()
				pIf->m_LogRect = pIf->m_Track.m_rect;
				dc.DPtoLP( pIf->m_LogRect );
				//-----------------------------------
			
				Tmp = point;      // while(){i++}
				Tmp.x += 65 ;Tmp.y += 30 ;
				CBlock* pCidum = new CBOperaction(Tmp);
				pDoc->m_BlockList.AddBlock(pCidum);
				pCidum->Draw(pDC);
				//---------------------------------DPtoLP()
				pCidum->m_LogRect = pCidum->m_Track.m_rect;
				dc.DPtoLP( pCidum->m_LogRect );
				//-----------------------------------

				Tmp = point;           // while(){###;} 
				Tmp.x += 65 ;Tmp.y += 75 ;
				CBlock* pGuf = new CBOperaction(Tmp);
				pDoc->m_BlockList.AddBlock(pGuf);
				pGuf->Draw(pDC);
				//---------------------------------DPtoLP()
				pGuf->m_LogRect = pGuf->m_Track.m_rect;
				dc.DPtoLP( pGuf->m_LogRect );
				//-----------------------------------

			OnNewSelect();	
			}
			break;
		}

		case ID_NEW_DOWHILE ://-------------------------------------------------
		{
		if(!(pDoc->m_BlockList.IsPointIn(point)) && !(bFlagTracking)) 
			{
				CPoint Tmp = point;           //  while(){;}
				Tmp.y -= 90 ;
				CBlock* pIthul = new CBOperator(Tmp);
				pDoc->m_BlockList.AddBlock(pIthul);
				pIthul->Draw(pDC);
				//---------------------------------DPtoLP()
				pIthul->m_LogRect = pIthul->m_Track.m_rect;
				dc.DPtoLP( pIthul->m_LogRect );
				//-----------------------------------

				Tmp = point;           // N O D E 
				Tmp.y -= 45 ;
				CBlock* pNode = new CBNode(Tmp);
				pDoc->m_BlockList.AddBlock(pNode);
				pNode->Draw(pDC);
				//---------------------------------DPtoLP()
				pNode->m_LogRect = pNode->m_Track.m_rect;
				dc.DPtoLP( pNode->m_LogRect );
				//-----------------------------------

	            CBlock* pO= new CBOperaction(point);// do{#;} while()
				pDoc->m_BlockList.AddBlock(pO);
				pO->Draw (pDC);
				//---------------------------------DPtoLP()
				pO->m_LogRect = pO->m_Track.m_rect;
				dc.DPtoLP( pO->m_LogRect );
				//-----------------------------------
			
				Tmp = point;      // do{;} while(#)
				Tmp.y += 45;
				CBlock* pIf= new CBIf(Tmp);
				pDoc->m_BlockList.AddBlock(pIf);
				pIf->Draw(pDC);
				//---------------------------------DPtoLP()
				pIf->m_LogRect = pIf->m_Track.m_rect;
				dc.DPtoLP( pIf->m_LogRect );
				//-----------------------------------

				Tmp = point;       // do{#++;} while()
				Tmp.x += 65 ;Tmp.y += 75 ;
				CBlock* pGuf = new CBOperaction(Tmp);
				pDoc->m_BlockList.AddBlock(pGuf);
				pGuf->Draw(pDC);
				//---------------------------------DPtoLP()
				pGuf->m_LogRect = pGuf->m_Track.m_rect;
				dc.DPtoLP( pGuf->m_LogRect );
				//-----------------------------------
	
			OnNewSelect();	
			}
			break;
		}
		case ID_NEW_SWITCH ://-------------------------------------------------
		{
		if(!(pDoc->m_BlockList.IsPointIn(point)) && !(bFlagTracking)) 
			{

			OnNewSelect();	
			}
			break;
		}
		case ID_NEW_NETLINE ://-------------------------------------------------
		{
		dc.DPtoLP(&point);   //-----Logical Coordinates

		//m_pBlockActivSetLine <---- Save *p for reset first pin to coordinates logi	  
		m_pOut = pDoc->m_BlockList.IsCloseToPinOut(point,m_pBlockActivSetLine) ;
		if ( m_pOut  && !(bFlagTracking) && !(pBlockIsPointIn) )
			{
				SetCapture();             
			    RECT Rect   ;
				GetClientRect (&Rect); //
		    	ClientToScreen(&Rect);
				::ClipCursor  (&Rect);

				if( !(m_pOut->m_IsClose ))
				{
					m_IsDragingNetLine = true ;
					dc.LPtoDP(&point);    // set first pin( Devase Coordinades)
					m_pOut->m_p = point ; // ---   ---    ---  ---   ---    ---   
					m_pOut->m_Line.AddPin (m_pOut); 
				}
				else
					dc.LPtoDP(&point); // return point to Devace coordinates
								
			//	Invalidate(false);
			}

		break;
		}
	}                               
//	pDoc->SetModifiedFlag();           //          End switch     //
	CScrollView::OnLButtonDown(nFlags, point);
}
//////////////////////////////////////////////////////////////////////
void CLogickView::OnMouseMove(UINT nFlags, CPoint point) 
{
	CDC* pDC;      // -----------------------------Device Coordinates
	pDC = GetDC();	
	if(m_IsDragingNetLine) // if draging lines	
	{
		CPin* pCurentPin = new CPin(point.x ,point.y );
		m_pOut->m_Line.DrawTMP(pDC,pCurentPin);	// heide,set pin,show.... 
	}
	//-------------------------------------------------------------------
	if(m_bRectDraging)
	{
		DrawRectFocus(pDC,point);
	}
	CScrollView::OnMouseMove(nFlags, point);
}
///////////////////////////////////////////////////////////////

///////////////////////////////////////////////////////////////
void CLogickView::OnLButtonUp(UINT nFlags, CPoint point) 
{
	CLogickDoc* pDoc = GetDocument();
	ASSERT_VALID(pDoc);
	CDC* pDC;
	pDC = GetDC();
	CBlock* pBlock;
	CClientDC  dc(this);
	OnPrepareDC(&dc) ; 	 

	if(m_IsDragingNetLine)
	{		
		dc.DPtoLP(&point);      //-----Logical Coordinates
	
		CPinIn* pPinIn = pDoc->m_BlockList.IsCloseToPinIn(point,pBlock) ;
		if(  pPinIn && !( pPinIn->m_IsClose) )		
		{	
		    dc.LPtoDP(&point) ; //-----Devace Coordinates
			m_pOut->m_Line.Hide(pDC)         ;
			m_pOut->m_Line.Draw(pDC)         ;
		//----------------------------- Save Logical Coordinates
			//        transform  first   pin
			m_pBlockActivSetLine->SetPins(m_pBlockActivSetLine->m_LogRect);
			//        transform  second  pin
			dc.DPtoLP(&point)       ;
			CPin* pCurentPin = new CPin(point.x ,point.y );
			m_pOut->m_Line.SetPin(pCurentPin); 
		//-------------------------------Close CPin-----
			pPinIn->m_IsClose = true     ;
		    pPinIn->m_pPrevOut  = m_pOut ; 
			m_pOut->m_IsClose = true     ;
			m_pOut->pNext = pBlock       ; 
		//----------------------------------------------
		}
		else
		{
			m_pOut->m_Line.Hide(pDC);	 		
			m_pOut->m_Line.RemoveAll(); 
			// transform  first   pin to Logical Coordinates 
			m_pBlockActivSetLine->SetPins(m_pBlockActivSetLine->m_LogRect);
			//----------------------------------------------------
			dc.LPtoDP(&point) ;//return point to Devace coordinates
		}
	m_IsDragingNetLine = false;	  
	}

	if(m_bRectDraging )
	{
		HideRectFocus(pDC);
		m_RectFocus.NormalizeRect();
		m_bRectDraging = false ;
	}
	::ReleaseCapture();
	::ClipCursor (NULL);



	CScrollView::OnLButtonUp(nFlags, point);
}
/////////////////////////////////////////////////////////////////////
BOOL CLogickView::OnSetCursor(CWnd* pWnd, UINT nHitTest, UINT message)
{
	

	CLogickDoc* pDoc = GetDocument();
	if (pWnd == this)
	{
		POSITION pos = pDoc->m_BlockList.GetHeadPosition();
		while (pos)
		{
			CBlock* pBlock = (CBlock*)pDoc->m_BlockList.GetNext(pos);
			if (pBlock->m_Track.SetCursor(this, nHitTest))
				return TRUE;
		}
	}
	return CScrollView::OnSetCursor(pWnd, nHitTest, message);
}

/////////////////////////////////////////////////////////////////////
void CLogickView::OnRButtonDown(UINT nFlags, CPoint point) 
{
	CLogickDoc* pDoc = GetDocument();
	ASSERT_VALID(pDoc) ;
	CClientDC  dc(this);
	OnPrepareDC(&dc)   ; 

		dc.DPtoLP(&point); //  Line - ( Coordinatot Logi )

		CPinOut* pPinOut ; //        D E L E T E   L I N E :
		if(pPinOut =  pDoc->m_BlockList.IsClosePinOutToLine(point) )
		{
			pPinOut->m_IsClose = false ;
			pPinOut->pNext->OpenBlockNext()   ; 
			Invalidate();
			return    ;
		}
		dc.LPtoDP(&point); // Shop to  Devaice coortinatot 
		if(pDoc->m_BlockList.IsPointIn(point))
		{
			m_ContextMenuPoint = point;
			CMenu menu ;
			ClientToScreen(&point);
			menu.LoadMenu(IDR_MENU2); 
			menu.GetSubMenu(0)->TrackPopupMenu(TPM_LEFTALIGN | TPM_RIGHTBUTTON,
											point.x, point.y, this);
	
		}
		else
		{
			CMenu menu ;
			ClientToScreen(&point);
			menu.LoadMenu(IDR_MENU1); 
			menu.GetSubMenu(0)->TrackPopupMenu(TPM_LEFTALIGN | TPM_RIGHTBUTTON,
											point.x, point.y, this);
		}

	CScrollView::OnRButtonDown(nFlags, point);
}
/////////////////////////////////////////////////////////////////////
void CLogickView::OnOpenProperti() 
{
	CLogickDoc* pDoc = GetDocument();
	ASSERT_VALID(pDoc);
	CBlock* pBlock = pDoc->m_BlockList.IsPointIn(m_ContextMenuPoint);
	if(pBlock)
	{
		CRect rSave = pBlock->m_Track.m_rect ;
		pBlock->EnterProperties();
	//	InvalidateRect(rSave);
		Invalidate(false);
	}
		
}
///////////////////////////////////////////////////////////////////
void CLogickView::OnBlocDelete() 
{

	CLogickDoc* pDoc = GetDocument();
	ASSERT_VALID(pDoc);
	bool flag = false ;

	 if(! m_bRunTimeFlaf ) // !!! Not Access  Rune Time
	 {

	CBlock* pBlock = pDoc->m_BlockList.IsPointIn(m_ContextMenuPoint);
	CRect rectSave ;
	pBlock->m_Track.GetTrueRect(&rectSave);
		rectSave.left   -= 24;
		rectSave.right  += 24;
		rectSave.top    -= 10;
		rectSave.bottom += 10;	
	if(pBlock->IsClosePinInToLine() || pBlock->IsClosePinOutToLine())
		flag = true; // if lines Invalidate() FUL

	pDoc->m_BlockList.DeleteBlock(m_ContextMenuPoint);//DELETE

     if(flag)
		Invalidate(); //  yes lines
	 else
		 InvalidateRect(rectSave); // no lines
	 }
}
//-----------------------------------------------------------------
////////////////////////////////////////////////////////////////////
//                                                //   IRD_MENU1  //
////////////////////////////////////////////////////////////////////
void CLogickView::OnNewSelect()               
{
	((CMainFrame*) AfxGetMainWnd()) ->m_SelectTools = ID_NEW_SELECT;	
}
void CLogickView::OnNewOperation()
{
	((CMainFrame*) AfxGetMainWnd()) ->m_SelectTools =  ID_NEW_OPERATION;	
}
void CLogickView::OnNewOperator() 
{
	((CMainFrame*) AfxGetMainWnd()) ->m_SelectTools =  ID_NEW_OPERATOR;	
}
void CLogickView::OnNewIf() 
{
	((CMainFrame*) AfxGetMainWnd()) ->m_SelectTools =  ID_NEW_IF;	
}
void CLogickView::OnNewIfelse() 
{
	((CMainFrame*) AfxGetMainWnd()) ->m_SelectTools =  ID_NEW_IFELSE;		
}
void CLogickView::OnNewNode() 
{
	((CMainFrame*) AfxGetMainWnd()) ->m_SelectTools =  ID_NEW_NODE;	
}
void CLogickView::OnNewNetline() 
{
	((CMainFrame*) AfxGetMainWnd()) ->m_SelectTools =  ID_NEW_NETLINE;	
}
void CLogickView::OnNewFor() 
{
	((CMainFrame*) AfxGetMainWnd()) ->m_SelectTools =  ID_NEW_FOR;		
}
void CLogickView::OnNewWhile() 
{
	((CMainFrame*) AfxGetMainWnd()) ->m_SelectTools =  ID_NEW_WHILE;	
}
void CLogickView::OnNewDowhile() 
{
	((CMainFrame*) AfxGetMainWnd()) ->m_SelectTools =  ID_NEW_DOWHILE;	
}
void CLogickView::OnNewSwitch() 
{
	((CMainFrame*) AfxGetMainWnd()) ->m_SelectTools =  ID_NEW_SWITCH;	
}
//-----------------------------------------------------------------
///////////////////////////////////////////////////////////////////
void CLogickView::DrawRectFocus(CDC* pDC , CPoint point)
{
	CPen Pen(PS_DOT,1,RGB(0,0,0,));
	CPen* oldPen = pDC->SelectObject(&Pen);
	pDC->SetBkMode(TRANSPARENT);
	pDC->SetROP2(R2_NOT);
	//----------------------------------------------
	pDC->MoveTo(m_RectFocus.left, m_RectFocus.top);
	pDC->LineTo(m_RectFocus.right,m_RectFocus.top);
	pDC->LineTo(m_RectFocus.right,m_RectFocus.bottom);
	pDC->LineTo(m_RectFocus.left, m_RectFocus.bottom);
	pDC->LineTo(m_RectFocus.left, m_RectFocus.top);

	m_RectFocus.right = point.x ;
	m_RectFocus.bottom= point.y;

	pDC->MoveTo(m_RectFocus.left,m_RectFocus.top);
	pDC->LineTo(m_RectFocus.right,m_RectFocus.top);
	pDC->LineTo(m_RectFocus.right,m_RectFocus.bottom);
	pDC->LineTo(m_RectFocus.left, m_RectFocus.bottom);
	pDC->LineTo(m_RectFocus.left, m_RectFocus.top);
	//----------------------------------------------
	pDC->SetROP2(R2_COPYPEN);
	pDC->SelectObject(oldPen);
}
//--------------------------------------------------
void CLogickView::HideRectFocus(CDC* pDC)
{
	CPen Pen(PS_DOT,1,RGB(0,0,0,));
	CPen* oldPen = pDC->SelectObject(&Pen);
	pDC->SetBkMode(TRANSPARENT);
	pDC->SetROP2(R2_NOT);
	//----------------------------------------------
	pDC->MoveTo(m_RectFocus.left, m_RectFocus.top);
	pDC->LineTo(m_RectFocus.right,m_RectFocus.top);
	pDC->LineTo(m_RectFocus.right,m_RectFocus.bottom);
	pDC->LineTo(m_RectFocus.left, m_RectFocus.bottom);
	pDC->LineTo(m_RectFocus.left, m_RectFocus.top);
	//----------------------------------------------
	pDC->SetROP2(R2_COPYPEN);
	pDC->SelectObject(oldPen);
}
///////////////////////////////////////////////////////////////////
void CLogickView::OnLButtonDblClk(UINT nFlags, CPoint point) 
{
	CLogickDoc* pDoc = GetDocument();
	ASSERT_VALID(pDoc);

	CBlock* pBlock = pDoc->m_BlockList.IsPointIn(point);
	if(pBlock)
	{
		CRect rSave = pBlock->m_Track.m_rect ;
		pBlock->EnterProperties();
		InvalidateRect(rSave);
//		Invalidate();
	}
	CScrollView::OnLButtonDblClk(nFlags, point);
}
///////////////////////////////////////////////////////////////////
void CLogickView::OnSoursViewer() 
{
	// TODO: Add your command handler code here	
}
///////////////////////////////////////////////////////////////////
void CLogickView::OnTimer(UINT nIDEvent) 
{
	CLogickDoc* pDoc = GetDocument();
	ASSERT_VALID(pDoc);

	pDoc->UpdateAllViews( NULL ) ;
	

	if( pDoc->m_BlockList.m_pCurBlock )
	{
		pDoc->m_BlockList.Operate(pDoc->m_Vars,this); 

		CScrollView::OnTimer(nIDEvent); 
	}
	else
	{
		if(pDoc->m_BlockList.m_pOldBlock)
			pDoc->m_BlockList.m_pOldBlock ->InOperMode = false ;
		KillTimer(1);
		CRect r = pDoc->m_BlockList.m_pOldBlock->m_Track.m_rect ;
		InvalidateRect(&r);
		m_bRunTimeFlaf = false  ;
//		OnStopRun() ;
	}

}

void CLogickView::OnRun()  // Start : Run
{
	CLogickDoc* pDoc = GetDocument();
	ASSERT_VALID(pDoc)        ;	
	pDoc->m_BlockList.Start() ; 	
	SetTimer ( 1,m_nTime,NULL);
	pDoc->m_Vars.RemoveAll()  ;
	m_bRunTimeFlaf = true     ;
}

void CLogickView::OnStopRun() 
{
	CLogickDoc* pDoc = GetDocument();
	ASSERT_VALID(pDoc);	
	
	KillTimer(1);
	if( pDoc->m_BlockList.m_pCurBlock )
	{
		pDoc->m_BlockList.m_pCurBlock->InOperMode = false;
		CRect r = pDoc->m_BlockList.m_pCurBlock->m_Track.m_rect;  
		InvalidateRect(r);
	}
	if( pDoc->m_BlockList.m_pOldBlock )  
	{
		pDoc->m_BlockList.m_pOldBlock->InOperMode = false;
		CRect r = pDoc->m_BlockList.m_pOldBlock->m_Track.m_rect;  
		InvalidateRect(r);
	}

	
	pDoc->m_BlockList.m_pCurBlock = NULL;
	pDoc->m_Vars.RemoveAll();
	m_bRunTimeFlaf = false    ;
	pDoc->m_BlockList.m_IsInitStepByStep = false ;
 
}
void CLogickView::OnSetTime() 
{
	CTimeDlg Dlg ;
	if(Dlg.DoModal()==IDOK)
	{
		m_nTime = Dlg.m_nTime ;
	}
}
void CLogickView::OnStepBy() 
{
	CLogickDoc* pDoc = GetDocument();
	if(!pDoc->m_BlockList.m_IsInitStepByStep)
		pDoc->m_Vars.RemoveAll();

	pDoc->m_BlockList.StepByStep(pDoc->m_Vars ,this); 
	pDoc->UpdateAllViews( NULL ) ;
}

void CLogickView::OnUpdate(CView* pSender, LPARAM lHint, CObject* pHint) 
{
	return ;	
}

///////////////////////////////////////////////////////////////////
void CLogickView::OnInitialUpdate() 
{
	CSize sizeTotal(10000,20000) ;
	SetScrollSizes(MM_TEXT,sizeTotal);
	CScrollView::OnInitialUpdate();
}
void CLogickView::OnPrepareDC(CDC* pDC, CPrintInfo* pInfo) 
{
//	pDC->SetMapMode(MM_HIMETRIC);	
	pDC->SetMapMode(MM_TEXT);
	CScrollView::OnPrepareDC(pDC, pInfo);
}
///////////////////////////////////////////////////////////////////


void CLogickView::OnUpdateRun(CCmdUI* pCmdUI) 
{
	pCmdUI->SetCheck ( m_bRunTimeFlaf== true ? 1:0 );

	CLogickDoc* pDoc = GetDocument();
	bool bTmp = pDoc->m_BlockList.m_IsInitStepByStep ; 
	pCmdUI->Enable( bTmp == true ? 0:1 );
}

void CLogickView::OnUpdateStop(CCmdUI* pCmdUI) 
{
	CLogickDoc* pDoc = GetDocument();
	if( m_bRunTimeFlaf || pDoc->m_BlockList.m_IsInitStepByStep )
		pCmdUI->Enable(1);
	else
		pCmdUI->Enable(0);

}

void CLogickView::OnUpdateStepBy(CCmdUI* pCmdUI) 
{
	pCmdUI->Enable( m_bRunTimeFlaf== true ? 0:1 );

}
