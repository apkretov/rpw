// JBlock.h: interface for the JBlock class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_JBLOCK_H__AA532986_CCC8_11D5_9D8F_E6C2F6DD145F__INCLUDED_)
#define AFX_JBLOCK_H__AA532986_CCC8_11D5_9D8F_E6C2F6DD145F__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#include "Block.h"

class JBlock : public CBlock  
{
public:
	JBlock();

	virtual ~JBlock();

};

#endif // !defined(AFX_JBLOCK_H__AA532986_CCC8_11D5_9D8F_E6C2F6DD145F__INCLUDED_)
