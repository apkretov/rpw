//////////////////////////////////////////////////////////////////////
// Block.cpp: implementation of the CBlock class.
//
//////////////////////////////////////////////////////////////////////

#include "stdafx.h"
#include "Logick.h"
#include "Block.h"
#include "InputDlg.h"
#include "OperationDlg.h"
#include "IiDlg.h"
#include "ErrorDlg.h"


#ifdef _DEBUG
#undef THIS_FILE
	static char THIS_FILE[]=__FILE__;
#define new DEBUG_NEW
#endif
////////////////////////////////////////////////////////////////////
//                   							S E R I A L I Z E	
////////////////////////////////////////////////////////////////////
IMPLEMENT_SERIAL( CBlock     , CObject    , 1 )
//---------------------------------------------
IMPLEMENT_SERIAL( CBOperator , CBlock     , 1 )
IMPLEMENT_SERIAL( CBStart    , CBOperator , 1 )
IMPLEMENT_SERIAL( CBEnd      , CBOperator , 1 )
IMPLEMENT_SERIAL(CBOperaction, CBOperator , 1 )
IMPLEMENT_SERIAL(    CBIf    , CBOperator , 1 )
IMPLEMENT_SERIAL(    CBNode  , CBOperator , 1 )
//---------------------------------------------
IMPLEMENT_SERIAL( CBlockList , CObList    , 1 )
////////////////////////////////////////////////////////////////////

void CBlock::Serialize(CArchive &ar)
{
	CObject::Serialize(ar); 

	if (ar.IsStoring()) // F I F O 
	{
		ar << (DWORD)bk_color << (DWORD)Gamma[8] << (DWORD)oper_color;
		ar << m_Track.m_rect  << m_LogRect << InOperMode << m_Text ; 
		ar << n_ID  ;
	}
	else
	{
		ar >> (DWORD)bk_color >> (DWORD)Gamma[8] >> (DWORD)oper_color;	
		ar >> m_Track.m_rect  >> m_LogRect >> InOperMode >> m_Text ; 
		ar >> n_ID ;
	}
}
// - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - 
void CBOperator::Serialize(CArchive& ar)
{
	CBlock::Serialize (ar);// Always call base class Serialize

	m_PinIn.Serialize (ar);
	m_PinOut.Serialize(ar);

	if (ar.IsStoring()) // F I F O 
	{
		ar << m_Name << m_Value ;
	}
	else
	{
		ar >> m_Name >> m_Value ;
	}	
	
}
// - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - 
void CBStart::Serialize(CArchive& ar)
{
	CBOperator::Serialize (ar);// Always call base class Serialize
}
// - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - 
void CBEnd::Serialize(CArchive& ar)
{
	CBOperator::Serialize (ar);
}
// - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - 
void CBOperaction::Serialize(CArchive& ar)
{
	CBOperator::Serialize (ar);
	if (ar.IsStoring()) 
	{
		ar << m_Source1 << m_Source2 << m_Oper ;
	}
	else
	{
		ar >> m_Source1 >> m_Source2 >> m_Oper ;
	}
}
// - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - 
void CBIf::Serialize(CArchive& ar)
{
	CBOperator::Serialize (ar);
	
	if (ar.IsStoring()) 
	{
		ar << m_Source1 << m_Source2 << m_BoolOper;
	}
	else
	{
		ar >> m_Source1 >> m_Source2 >> m_BoolOper;
	}
	m_PinOutYes.Serialize (ar);
	m_PinOutNo.Serialize (ar);
}
// - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - 
void CBNode::Serialize(CArchive& ar)
{
	CBOperator::Serialize (ar);
	m_PinInL.Serialize (ar);
	m_PinInR.Serialize (ar);
}
// - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - 
void CBlockList::Serialize(CArchive& ar) 
{
	if (ar.IsStoring())           //    S A V E   //		 
	{															//			  ________
		//--------------- CBlock::n_ID ==                       //			 |   _  1 |
		POSITION pos = GetHeadPosition();                       //           |__|1|___| 
		int CountID = 0   ;										//		        |_|
		while (pos)												//                   \ 
		{														//                    | 
			CBlock* pTmp = (CBlock*)GetNext(pos); // pos++		//	                 /
			pTmp->n_ID  = (++CountID)  ;                        //               _ /
		    //---------- CBlock::m_PinOut.n_IDpin ==	        //     CPinIn   |1|       1.3. n_IDpin = 1
			pTmp->SavePinOutID(CountID);		            	//          ____|_|____ 
		}   	   											    //   CBlock|         3 |  1.1. n_ID    = 3
																//         |___________| 
		//----------- CBlock::m_PinIn.n_IDpin ==                //              |3|       1.2. n_IDpin = 3
		pos = GetHeadPosition();                                //     CPinOut  |_| 
		while(pos)                                              //               |
		{                                                       //               | 
			 CBlock* pTmp = (CBlock*)GetNext(pos);              //               |
                                                                //               _
			 if( pTmp->IsClosePinInToLine() )                   //              |3|      2.1. pNext      = & 3 ( CBlock )
			 {                                                  //          ____|_|____  2.2. m_pPrevPin = & 1 ( CPinOut)
				POSITION pos2 = GetHeadPosition();              //         |        2  |
				while(pos2)                                     //         |___________|
				{                                               //              |2|
					CBlock* pCar = (CBlock*)GetNext(pos2);      //              |_| 
					if(  pTmp->SavePinInID(pCar) )
						break ;// m_PinIn.n_IDpin = ID                                                      		                                        		}                                                  
				}
			 }
		}
		
		CObList::Serialize(ar);		 

//---------------------------------------------------------------------
	}
	else //                                                 O P E N
	{

	  CObList::Serialize(ar);

		//--------------------------------------------CBlock::pNext
		POSITION pos = GetHeadPosition(); 
		while (pos)  
		{   
			CBlock* pTmp = (CBlock*)GetNext(pos); // pos++
			if( pTmp->IsClosePinOutToLine() )
			{
				POSITION posT = GetHeadPosition();
				while (posT)
				{
					CBlock* pCar = (CBlock*)GetNext(posT);
					if( pTmp->FindNext(pCar) )
						break ;
				}
			}
		}  
		// -------------------------------------m_PinIn.m_pPrevOut 
		 pos = GetHeadPosition(); 
		 while (pos) 
		 {
			CBlock* pTmp = (CBlock*)GetNext(pos);
			if( pTmp->IsClosePinInToLine() )  
			{
				 
				POSITION pos2 = GetHeadPosition(); 
				while(pos2)
				{
					CBlock*  pCar = (CBlock*)GetNext(pos2);
					if( pTmp->FindPrevOut( pCar ) )
						break ;	
				}
			}
		} 
		// ----------------------------------------------
	}  
}
////////////////////////////////////////////////////////////////////
//                   		E N D			S E R I A L I Z E
	
////////////////////////////////////////////////////////////////////


//										 implementation   :
////////////////////////////////////////////////////////////////////
//									            	C B L O C K
////////////////////////////////////////////////////////////////////
COLORREF CBlock::Gamma[8]={ RGB(255, 255, 255) ,  // 0 White 
							RGB(0  ,   0,   0) ,  // 1 Black
							RGB(  0, 240, 100) ,  // 2 Green
							RGB(255,   0,   0) ,  // 3 Red
							RGB(50 , 150, 250) ,  // 4 Blue
							RGB(0  ,   0, 255) ,  // 5
							RGB(0  ,   0,   0) ,  // 6 
						//	RGB(117 , 83, 251) 
							RGB(255, 0, 255)}; // 7 OperColor
//////////////////////////////////////////////////////////////////// 
/*=================================================================
 Function      |    CBlock::CBlock()                                                      
 Description:  |    Construction                   
 Parametrs     |    void
 ReturnValue   |    void    
 Remarks       |    Construction for Serialize
===================================================================*/
CBlock::CBlock() // Construction                       
{

	m_Track.m_sizeMin.cx = 110;
	m_Track.m_sizeMin.cy = 24 ;                   
	m_Track.m_rect.SetRectEmpty();              
	m_Track.m_nStyle = CRectTracker::resizeInside;

	m_LogRect = m_Track.m_rect; 	
	m_Text = "";	
	bk_color =  Gamma[0];
	oper_color= Gamma[7];

	InOperMode = false ;
	n_ID = 0 ;
}
/*=================================================================
 Function      |    CBlock::CBlock(CPoint point)                                                      
 Description:  |    Construction                   
 Parametrs     |    CPoint
 ReturnValue   |    void    
 Remarks       |   
===================================================================*/
CBlock::CBlock(CPoint point) //   Construction
{
	m_Text = "";
	InOperMode = false ;
	n_ID = 0 ;
	bk_color = Gamma[0];
	oper_color= Gamma[7];

	m_Track.m_sizeMin.cx = 110;
	m_Track.m_sizeMin.cy = 24 ; 
	m_Track.m_nStyle = CRectTracker::resizeInside      ;

	//--------------------------------------------------
	m_LogRect.left = point.x - m_Track.m_sizeMin.cx / 2 ;
	m_LogRect.right= point.x + m_Track.m_sizeMin.cx / 2 ;
	m_LogRect.top  = point.y - m_Track.m_sizeMin.cy / 2 ;
	m_LogRect.bottom=point.y + m_Track.m_sizeMin.cy / 2 ;
	CRect rect = m_LogRect ;
}
/*=================================================================
 Function      |    CBlock::CBlock(CRect rect)                                                      
 Description:  |    Construction                   
 Parametrs     |    CPoint
 ReturnValue   |    void    
 Remarks       |   
===================================================================*/
CBlock::CBlock(CRect rect)  //    Construction
{
	m_Track.m_sizeMin.cx = 110;
	m_Track.m_sizeMin.cy = 24 ;
	m_Track.m_nStyle = CRectTracker::resizeInside;
	m_Track.m_rect = rect;
	m_LogRect = m_Track.m_rect;

	m_Text = "";
	bk_color = Gamma[0] ;
	oper_color= Gamma[7];
	InOperMode = false  ;
	

	n_ID = 0 ;
}
/*=================================================================
 Function      |    Draw                                                
 Description:  |                       
 Parametrs     |    CDC* pDC
 ReturnValue   |    void    
 Remarks       |    1 implementation for "Logick"
===================================================================*/
void CBlock::Draw(CDC* pDC) // Draw
{
	//------------------------------------------------
	DrawBlock(pDC);             // Logical Coordinates
	DrawPin(pDC)  ;
	DrawTXT(pDC)  ;
	DrawLines(pDC);
	//------------------------------------------------
	m_Track.m_rect =  m_LogRect ; 
	pDC->LPtoDP(&m_Track.m_rect); // Device Coordinates
	m_Track.Draw(pDC)           ;
	//-------------------------------------------------

}
/*=================================================================
 Function      |    DrawTXT                                                    
 Description:  |    draw text                   
 Parametrs     |    CDC* pDC
 ReturnValue   |    void    
 Remarks       |   1 implementation for "Logick"
===================================================================*/
void CBlock::DrawTXT(CDC* pDC) //  DrawTXT
{
	pDC->SetBkMode(TRANSPARENT);
	CSize c = pDC->GetTextExtent(m_Text);
	pDC->SetTextColor(Gamma[5]);
	pDC->TextOut((m_LogRect.right + m_LogRect.left) / 2 - c.cx / 2, 
				 (m_LogRect.top   + m_LogRect.bottom) / 2 - c.cy / 2,
				  m_Text);
	if(c.cx > m_Track.m_rect.Size().cx  )
	{
		int t = c.cx - m_Track.m_rect.Size().cx ;
		m_LogRect.left  -=  (t/2)+7 ; 
		m_LogRect.right +=  (t/2)+7 ;
	}
}


////////////////////////////////////////////////////////////////////
//		                                   		      OPERATOP
////////////////////////////////////////////////////////////////////

/*=================================================================
 Function      |    DrawBlock                                                   
 Description:  |                       
 Parametrs     |    CDC* pDC
 ReturnValue   |    void    
 Remarks       |    if(InOperMode) color = oper_color    <<== CBrush
			   |              else color = bk_color
===================================================================*/
void CBOperator::DrawBlock(CDC* pDC)
{	
	CPen MyPen(PS_SOLID, 1 ,Gamma[1]);
	CPen* oldPen = pDC->SelectObject(&MyPen);

	COLORREF color ; 
	if(InOperMode)
		color = oper_color ;
	else
		color = bk_color ;

	CBrush b( color );
	CBrush* OldBr = pDC->SelectObject(&b);
	
	CPoint Tmp[4];
		Tmp[0] = CPoint(m_LogRect.left+10 , m_LogRect.top   );
		Tmp[1] = CPoint(m_LogRect.right   , m_LogRect.top   );
		Tmp[2] = CPoint(m_LogRect.right-10, m_LogRect.bottom);
		Tmp[3] = CPoint(m_LogRect.left    , m_LogRect.bottom);
	pDC->Polygon(Tmp, 4); 

	pDC->SelectObject(oldPen);
	pDC->SelectObject(OldBr); 
}
/*=================================================================
 Function      |    DrawPin                                                   
 Description:  |                       
 Parametrs     |    CDC* pDC
 ReturnValue   |    void    
 Remarks       |   
===================================================================*/
void CBOperator:: DrawPin(CDC* pDC)
{
	SetPins(m_LogRect);

	CBrush b( Gamma[2] );
	CBrush* oldBrus = pDC->SelectObject (&b);  	
	m_PinIn.Draw(pDC,&b);

	CBrush b1( Gamma[4] );
	pDC->SelectObject (&b1);  
	m_PinOut.Draw(pDC,&b1);
	
	pDC->SelectObject(oldBrus);
}
/*=================================================================
 Function      |    SetPins                                               
 Description:  |                       
 Parametrs     |    CRect rect
 ReturnValue   |    void    
 Remarks       |   
===================================================================*/
void CBOperator::SetPins(CRect rect)
{
	m_PinIn.m_p.x  = (rect.left + rect.right )/2 ; 
	m_PinIn.m_p.y  = rect.top - 2   ;
	m_PinOut.m_p.x = (rect.left + rect.right )/2 ; 
	m_PinOut.m_p.y = rect.bottom + 2 ; 
}
//--------------------------------------------------------------
CPinIn* CBOperator::IsCloseToPinIn(CPoint point,CBlock* &pBlock) 
{
	pBlock = NULL ;
	if(m_PinIn.IsCloseToPin(point))
	{
		pBlock = this ;
		return (&m_PinIn);
	}
	return NULL ;
}
//--------------------------------------------------------------
CPinOut* CBOperator::IsCloseToPinOut(CPoint point,CBlock* &pBlock) 
{
	pBlock = NULL ;
	if(m_PinOut.IsCloseToPin(point))
	{
		pBlock = this ;
		return (&m_PinOut);
	}
	return NULL ;
}
/*=================================================================
 Function      |    EnterProperties                                               
 Description:  |                       
 Parametrs     |    void
 ReturnValue   |    void    
 Remarks       |   
===================================================================*/
void CBOperator::EnterProperties()
{
	CInputDlg dlg;

	dlg.m_Name = m_Name ;
	dlg.m_Value= m_Value;

	if(dlg.DoModal() == IDOK)
	{
		if( dlg.m_Name == "" || dlg.m_Value == "" )
		{
			CErrorDlg Dlg ;
			Dlg.DoModal() ;
			return;
			 
		}
		m_Name = dlg.m_Name ;
		m_Value= dlg.m_Value;

		m_Text = dlg.m_Name + "=" + dlg.m_Value ; 
	}
}
/*=================================================================
 Function      |    DrawLines                                                  
 Description:  |                       
 Parametrs     |    CDC* pDC
 ReturnValue   |    void    
 Remarks       |   
===================================================================*/
void  CBOperator::DrawLines(CDC* pDC)
{ 
	if( m_PinOut.m_IsClose)
	{
		m_PinOut.m_Line.Draw(pDC);
	}
	if( m_PinIn.m_IsClose )
	{ 
		m_PinIn.m_pPrevOut->m_Line.Draw(pDC); 
	}
}
//--------------------------------------------------------------
void CBOperator:: Operat(VarList& pVars,CWnd* pCWnd)
{
	long Res ;
	VNumStr tmp;

	if( !m_Value.IsNumStr() ) // m_Value not "number"
	{
		Variable* pV =  pVars.FindName(m_Name);	
		if(pV)// if find m_Name
			Res = pV->m_lValue; 
		// else{}
	}
	else // m_Value "number"
		Res = m_Value.TransformStrToInt();

	Variable* X = new Variable ;
	X->m_stName = m_Name  ;  
	X->m_lValue = Res ;

	pVars.AddVariable(X); 

}
//--------------------------------------------------------------
bool CBOperator::IsClosePinInToLine()
{
	if(m_PinIn.m_IsClose )
		return true ;
	return false ;
}
//--------------------------------------------------------------
CPinOut* CBOperator::IsClosePinOutToLine()
{
	if(m_PinOut.m_IsClose)
		return &m_PinOut;

	return false ;
}
//--------------------------------------------------------------
void CBOperator::ReSetLine()
{
	if( m_PinIn.m_IsClose )
		m_PinIn.m_pPrevOut->m_Line.SetPin(&m_PinIn)  ;

	if( m_PinOut.m_IsClose)
	{
		//########################################################
		if(m_PinOut.m_p != ((CPin*)m_PinOut.m_Line.GetHead())->m_p)
		{
			m_PinOut.m_Line.RemoveHead() ;
			m_PinOut.m_Line.AddHead(&m_PinOut);  
		}
		//########################################################
	}

}	
//--------------------------------------------------------------
CBOperator::~CBOperator()// Virtual Destruction
{
	if( m_PinIn.m_IsClose )	                                                
		OpenBlockPrev();

	if( m_PinOut.m_IsClose )
	{
		m_PinOut.m_IsClose = false ;// MyFlag for Node
		((CBOperator*)m_PinOut.pNext)->OpenBlockNext() ;
	}
}
//-----------------------------------------------------------------
void CBOperator::OpenBlockNext()
{
	m_PinIn.KillerLinks();
}
//-------------------------------------------------------------------
void CBOperator::OpenBlockPrev()
{
	m_PinIn.KillerLinks();
}
//-------------------------------------------------------------------
void CBOperator::SavePinOutID(int nID) // helper  save file  
{
	m_PinOut.n_IDpin = nID ;
}
//-------------------------------------------------------------------
bool CBOperator::SavePinInID (CBlock* pCar)// helper  save file  
{ 
	int Tmp =  	pCar->HelperSavePinInID( m_PinIn.m_pPrevOut);
	if( Tmp )         
	{
		m_PinIn.n_IDpin = Tmp ;
		return ( true );
	}

	return (false);
}
int CBOperator::HelperSavePinInID(CPinOut* pPrev)
{
	if( &m_PinOut == pPrev )
		return ( m_PinOut.n_IDpin );
	else
		return 0 ;
}
bool CBOperator::FindNext(CBlock* pCar)
{
	int TmpID = m_PinOut.n_IDpin ; 

	CBlock* pBlock = pCar->HelperFindNext( TmpID )  ;
	if( pBlock )
	{ 
		m_PinOut.pNext = pBlock;
		return (true) ;
	}
	return (false) ;
}
CBlock* CBOperator:: HelperFindNext(int ID )
{
	if(m_PinIn.m_IsClose )
	{
		if(m_PinIn.n_IDpin == ID )
			return ( this ) ;
	}
	return NULL ;
}
bool CBOperator:: FindPrevOut(CBlock* pCar )
{
	if( m_PinIn.m_IsClose  )
	{
		CPinOut* pPin = pCar->HelperFindPrevOut( m_PinIn.n_IDpin ); 
		if( pPin)
		{
			m_PinIn.m_pPrevOut = pPin ;
			return ( true ) ;
		}
	}
	return ( false );
}
CPinOut* CBOperator::HelperFindPrevOut(int ID)
{
	if(m_PinOut.n_IDpin == ID )
		return (&m_PinOut);
	return NULL ;
}
//------------------------------------------------------------------
////////////////////////////////////////////////////////////////////
//											OPERATION
////////////////////////////////////////////////////////////////////

/*=================================================================
 Function      |    DrawBlock                                                   
 Description:  |                       
 Parametrs     |    CDC* pDC
 ReturnValue   |    void    
 Remarks       |    if(InOperMode) color = oper_color    <<== CBrush
			   |              else color = bk_color
===================================================================*/
void CBOperaction::DrawBlock(CDC* pDC) 
{	
	CPen MyPen(PS_SOLID, 1 ,Gamma[1]);
	CPen* oldPen = pDC->SelectObject(&MyPen);
	
	COLORREF color ; 
	if(InOperMode)
		color = oper_color ;
	else
		color = bk_color ;
	CBrush b(color);

	CBrush* OldBr = pDC->SelectObject(&b); 

	pDC->Rectangle(m_LogRect);

//	CRect r = m_Track.m_rect ;
//	r.DeflateRect(2,2);
///	r.DeflateRect(0,0,3,3);
//	pDC->Rectangle(r);

	pDC->SelectObject(oldPen);
	pDC->SelectObject (OldBr);
}
/*=================================================================
 Function      |    EnterProperties                                               
 Description:  |                       
 Parametrs     |    void
 ReturnValue   |    void    
 Remarks       |   
===================================================================*/
void  CBOperaction::EnterProperties()
{
	COperationDlg dlg ;
		dlg.m_Dest    = m_Name;
		dlg.m_Sourse1 = m_Source1 ;
		dlg.m_Sourse2 = m_Source2 ;
		dlg.m_Oper    = m_Oper;

	if(dlg.DoModal()== IDOK)
	{
		if( dlg.m_Dest == "" || dlg.m_Sourse1 =="" ) 
		{
			CErrorDlg Dlg ;
			Dlg.DoModal() ;
			return;
		}
		if( dlg.m_Oper=="" || dlg.m_Sourse2=="") 
		{
			m_Name    = dlg.m_Dest    ;
			m_Source1 = dlg.m_Sourse1 ;
			m_Source2 = ""            ;
		    m_Oper    = ""            ;
			m_Text = dlg.m_Dest +
			     "="            +
				 dlg.m_Sourse1  ;	
		}
		else
		{
			m_Name    = dlg.m_Dest    ;
			m_Source1 = dlg.m_Sourse1 ;
			m_Source2 = dlg.m_Sourse2 ;
			m_Oper    = dlg.m_Oper    ;

		m_Text = dlg.m_Dest    +
			     "="           +
				 dlg.m_Sourse1 +
				 dlg.m_Oper    +
				 dlg.m_Sourse2 ;
		}
	}
}
//--------------------------------------------------------------
void CBOperaction::Operat(VarList& pVars,CWnd* pCWnd)
{
	long src1 , src2 , Res;
	if( !( m_Source1.IsNumStr() )) // if not namber 
	{
		Variable* pV = pVars.FindName(m_Source1);
		if(pV)
		{
			src1 = pV->m_lValue ;
		}
	}
	else
		src1 = m_Source1.TransformStrToInt();
	
	if( !(m_Source2.IsNumStr())) // if not namber 
	{
		Variable* pV = pVars.FindName(m_Source2);
		if(pV)
		{
			src2 = pV->m_lValue ;
		}
	}
	else
		src2 = m_Source2.TransformStrToInt();

	if( m_Source2 == "" || m_Oper == "")
	{
		Res = src1 ;
		Variable* X = new Variable ;
		X->m_stName = m_Name       ;
		X->m_lValue = Res          ;
		pVars.AddVariable(X); 	
		return ;
	}

	if(m_Oper == '+')
		Res = src1 + src2 ;
	else if(m_Oper == '-')
		Res = src1 - src2 ;
	else if(m_Oper == '*')
		Res = src1 * src2 ;
	else if(m_Oper == '/')
		Res = src1 / src2 ;
	else if(m_Oper == '%')
		Res = src1 % src2 ;  
	else
		return ;

	Variable* X = new Variable ;
	X->m_stName = m_Name       ;
	X->m_lValue = Res          ;
	pVars.AddVariable(X); 	
}

////////////////////////////////////////////////////////////////////
 //                                                          START
/*=================================================================
 Function      |    DrawBlock                                                   
 Description:  |                       
 Parametrs     |    CDC* pDC
 ReturnValue   |    void    
 Remarks       |    if(InOperMode) color = oper_color    <<== CBrush
			   |              else color = bk_color
===================================================================*/
 void CBStart:: DrawBlock(CDC* pDC)
 {	
	CPen MyPen(PS_SOLID, 1 ,Gamma[1]);
	CPen* oldPen = pDC->SelectObject( &MyPen );

	COLORREF color ; 
	if(InOperMode)
		color = oper_color ;
	else
		color = bk_color ;
	CBrush b(color); 
	CBrush* OldBr = pDC->SelectObject(&b);

		pDC->Ellipse (&m_LogRect );

	CRect R ; 
	CSize Border ;
	Border.cx = 3 ; Border.cy = 3 ;

	R = m_LogRect ; 

	R.DeflateRect(0,0,2,3); 
		pDC->Ellipse (&R);


	pDC->SelectObject(oldPen);
	pDC->SelectObject (OldBr);
 }
/*=================================================================
 Function      |    DrawPin                                                   
 Description:  |                       
 Parametrs     |    CDC* pDC
 ReturnValue   |    void    
 Remarks       |   
===================================================================*/
void CBStart::DrawPin(CDC* pDC)
{
	SetPins(m_LogRect);
	CBrush b( Gamma[4] );
	CBrush* oldBrus = pDC->SelectObject (&b);   
	m_PinOut.Draw(pDC,&b); 
	pDC->SelectObject(oldBrus);
}
//--------------------------------------------------------------
CPinIn*  CBStart::IsCloseToPinIn (CPoint point,CBlock* &pBlock)
{
	return NULL;
}

//////////////////////////////////////////////////////////////////// 
//                                                  END
/*=================================================================
 Function      |    DrawBlock                                                   
 Description:  |                       
 Parametrs     |    CDC* pDC
 ReturnValue   |    void    
 Remarks       |    if(InOperMode) color = oper_color    <<== CBrush
			   |              else color = bk_color
===================================================================*/
void CBEnd::DrawBlock (CDC* pDC)
{
	CPen MyPen(PS_SOLID, 1 ,Gamma[1]);
	CPen* oldPen = pDC->SelectObject(&MyPen);

	COLORREF color ; 
	if(InOperMode)
		color = oper_color ;
	else
		color = bk_color ;
	CBrush b(color);
	CBrush* OldBr = pDC->SelectObject(&b); 

	pDC->Ellipse (m_LogRect);

	pDC->SelectObject(oldPen);
	pDC->SelectObject (OldBr);
}
//--------------------------------------------------------------
CPinOut* CBEnd::IsCloseToPinOut(CPoint point,CBlock* &pBlock) 
{
	return NULL ;
}
/*=================================================================
 Function      |    DrawPin                                                   
 Description:  |                       
 Parametrs     |    CDC* pDC
 ReturnValue   |    void    
 Remarks       |   
===================================================================*/
void CBEnd::DrawPin(CDC* pDC)
{
	SetPins(m_LogRect);
	CBrush b( Gamma[2] );
	CBrush* oldBrus = pDC->SelectObject (&b); 
	
	m_PinIn.Draw(pDC,&b); 

	pDC->SelectObject(oldBrus);
}
////////////////////////////////////////////////////////////////////
//														 NODE
////////////////////////////////////////////////////////////////////
CBNode::CBNode(CPoint point)                
{ 
	nCauntPinInClosed = 0 ;
	bFlagSetClosed    = false ;
	m_Track.m_sizeMin.cx = 24;
	m_Track.m_sizeMin.cy = 24 ;
	
	m_LogRect.left = point.x - m_Track.m_sizeMin.cx / 2 ;
	m_LogRect.right= point.x + m_Track.m_sizeMin.cx / 2;
	m_LogRect.top  = point.y - m_Track.m_sizeMin.cy / 2;
	m_LogRect.bottom=point.y + m_Track.m_sizeMin.cy / 2;
	m_Text = "";	
	m_Track.m_nStyle = CRectTracker::resizeInside;

} 
/*=================================================================
 Function      |    DrawBlock                                                   
 Description:  |                       
 Parametrs     |    CDC* pDC
 ReturnValue   |    void    
 Remarks       |    if(InOperMode) color = oper_color    <<== CBrush
			   |              else color = bk_color
===================================================================*/
void CBNode::DrawBlock(CDC* pDC)                
{
	CPen MyPen(PS_SOLID, 1 ,Gamma[1]);
	CPen* oldPen = pDC->SelectObject(&MyPen);

	COLORREF color ; 
	if(InOperMode)
		color = oper_color ;
	else
		color = bk_color ;
	CBrush b(color);
	CBrush* OldBr = pDC->SelectObject(&b); 

	pDC->Ellipse(&m_LogRect);
	pDC->SelectObject(oldPen);
	pDC->SelectObject (OldBr);
}
/*=================================================================
 Function      |    SetPins                                               
 Description:  |                       
 Parametrs     |    CRect rect
 ReturnValue   |    void    
 Remarks       |   
===================================================================*/
void CBNode::SetPins(CRect r)
{
	m_PinIn.m_p.x  = (r.left + r.right )/2 ;
	m_PinIn.m_p.y  = r.top;
	m_PinInR.m_p.x = r.right +3 ;
	m_PinInR.m_p.y =(r.top + r.bottom )/2+3;
	m_PinInL.m_p.x = r.left - 3;
	m_PinInL.m_p.y = (r.top + r.bottom )/2+3;
	m_PinOut.m_p.x = (r.left + r.right )/2 ;
	m_PinOut.m_p.y  = r.bottom ;

}
/*=================================================================
 Function      |    DrawPin                                                   
 Description:  |                       
 Parametrs     |    CDC* pDC
 ReturnValue   |    void    
 Remarks       |   
===================================================================*/
void CBNode::DrawPin(CDC* pDC)  
{
	SetPins(m_LogRect);

	CBrush b( Gamma[2] );
	CBrush* oldBrus = pDC->SelectObject (&b);
	
	m_PinIn.Draw  (pDC,&b);
	m_PinInL.Draw (pDC,&b);
	m_PinInR.Draw (pDC,&b);
   
	CBrush b1( Gamma[4] );
	pDC->SelectObject (&b1);  
	m_PinOut.Draw (pDC,&b1);
	
	pDC->SelectObject(oldBrus);
}
//--------------------------------------------------------------
CPinIn*  CBNode::IsCloseToPinIn (CPoint point,CBlock* &pBlock)
{
	pBlock = NULL ;
	if(m_PinIn.IsCloseToPin(point))
	{
		pBlock = this ;
		return (&m_PinIn);
	}
	if(m_PinInL.IsCloseToPin(point))
	{
		pBlock = this ;
		return (&m_PinInL);
	}
	if(m_PinInR.IsCloseToPin(point))
	{
		pBlock = this ;
		return (&m_PinInR);
	}
	return NULL ;
}
//--------------------------------------------------------------
bool CBNode::IsClosePinInToLine()
{
	if( m_PinIn.m_IsClose  )
		return true ;
	if( m_PinInL.m_IsClose )
		return true ;
    if( m_PinInR.m_IsClose )
		return true ;

	return false ;
}
//--------------------------------------------------------------
void CBNode::ReSetLine()
{
	if( m_PinIn.m_IsClose  )
		m_PinIn.m_pPrevOut->m_Line.SetPin(&m_PinIn)  ; 
	if( m_PinInL.m_IsClose )
		m_PinInL.m_pPrevOut->m_Line.SetPin(&m_PinInL) ;
    if( m_PinInR.m_IsClose )
		m_PinInR.m_pPrevOut->m_Line.SetPin(&m_PinInR) ;	

	if( m_PinOut.m_IsClose)
	{
		//########################################################
		if(m_PinOut.m_p != ((CPin*)m_PinOut.m_Line.GetHead())->m_p)
		{
			m_PinOut.m_Line.RemoveHead() ;
			m_PinOut.m_Line.AddHead(&m_PinOut);  
		}
		//########################################################
	}
}
//------------------------------------------------------
CBNode::~CBNode()// Virtual Destruction
{
	if(m_PinIn.m_IsClose)
		m_PinIn.KillerLinks();
	if(m_PinInL.m_IsClose)
		m_PinInL.KillerLinks();
	if(m_PinInR.m_IsClose)
		m_PinInR.KillerLinks();

	if(m_PinOut.m_IsClose )
	{
		m_PinOut.m_IsClose = false ; // MyFlag for CBNode
		((CBOperator*)m_PinOut.pNext)->OpenBlockNext();
	}


}
//--------------------------------------------------------------
void CBNode::OpenBlockNext()
{
	if(m_PinIn.m_IsClose  &&  !(m_PinIn.m_pPrevOut->m_IsClose ))
		m_PinIn.KillerLinks(); 
	if(m_PinInL.m_IsClose  && !(m_PinInL.m_pPrevOut->m_IsClose ))
		m_PinInL.KillerLinks();
	if(m_PinInR.m_IsClose  && !(m_PinInR.m_pPrevOut->m_IsClose ))
		m_PinInR.KillerLinks(); 

}
/*=================================================================
 Function      |    DrawLines                                                  
 Description:  |                       
 Parametrs     |    CDC* pDC
 ReturnValue   |    void    
 Remarks       |   
===================================================================*/
void  CBNode::DrawLines(CDC* pDC)
{ 
	if( m_PinOut.m_IsClose)
		m_PinOut.m_Line.Draw(pDC);
	if( m_PinIn.m_IsClose ) 
		m_PinIn.m_pPrevOut->m_Line.Draw(pDC); 
	if( m_PinInL.m_IsClose ) 
		m_PinInL.m_pPrevOut->m_Line.Draw(pDC); 
	if( m_PinInR.m_IsClose ) 
		m_PinInR.m_pPrevOut->m_Line.Draw(pDC);
}
//-------------------------------------------------------------------
bool CBNode::SavePinInID (CBlock* pCar)
{
	if(!bFlagSetClosed) // Set caunt for save PinInS ID
	{
		if(m_PinIn.m_IsClose )  nCauntPinInClosed += 1 ;
		if(m_PinInL.m_IsClose ) nCauntPinInClosed += 1 ;
		if(m_PinInR.m_IsClose ) nCauntPinInClosed += 1 ;

		bFlagSetClosed = true ;
	}
	//-------------------------
	int Tmp =  	pCar->HelperSavePinInID( m_PinIn.m_pPrevOut);
	if( Tmp )         
	{
		m_PinIn.n_IDpin = Tmp ;
		nCauntPinInClosed -=1 ;
	//	return ( true );
	}
	Tmp = pCar->HelperSavePinInID( m_PinInL.m_pPrevOut);
	if( Tmp )         
	{
		m_PinInL.n_IDpin = Tmp ;
		nCauntPinInClosed -=1 ;
	//	return ( true );
	}
	Tmp = pCar->HelperSavePinInID( m_PinInR.m_pPrevOut);
	if( Tmp )         
	{
		m_PinInR.n_IDpin = Tmp ;
		nCauntPinInClosed -=1 ;
	//	return ( true );
	}
	//-----------------------------
	  if(!nCauntPinInClosed)
		  return (true);
	  else
		return (false);
}
CBlock*  CBNode::HelperFindNext(int ID )
{
	if(m_PinIn.m_IsClose )
	{
		if(m_PinIn.n_IDpin == ID )
			return ( this ) ;
	}
	if(m_PinInL.m_IsClose )
	{
		if(m_PinInL.n_IDpin == ID )
			return ( this ) ;
	}
	if(m_PinInR.m_IsClose )
	{
		if(m_PinInR.n_IDpin == ID )
			return ( this ) ;
	}
	return NULL ;
}
bool CBNode::FindPrevOut(CBlock* pCar )
{
	if(!bFlagSetClosed) // Set caunt for  transform ID to pointer
	{
		if(m_PinIn.m_IsClose )  nCauntPinInClosed += 1 ;
		if(m_PinInL.m_IsClose ) nCauntPinInClosed += 1 ;
		if(m_PinInR.m_IsClose ) nCauntPinInClosed += 1 ;

		bFlagSetClosed = true ;
	}
	//------------------------------------------------------
	if( m_PinIn.m_IsClose  )
	{
		CPinOut* pPin = pCar->HelperFindPrevOut( m_PinIn.n_IDpin ); 
		if( pPin)
		{
			m_PinIn.m_pPrevOut = pPin ;
			nCauntPinInClosed -= 1 ;
		}
	}
	if( m_PinInL.m_IsClose  )
	{
		CPinOut* pPin = pCar->HelperFindPrevOut( m_PinInL.n_IDpin ); 
		if( pPin)
		{
			m_PinInL.m_pPrevOut = pPin ;
			nCauntPinInClosed -= 1 ;
		}
	}
	if( m_PinInR.m_IsClose  )
	{
		CPinOut* pPin = pCar->HelperFindPrevOut( m_PinInR.n_IDpin ); 
		if( pPin)
		{
			m_PinInR.m_pPrevOut = pPin ;
			nCauntPinInClosed -= 1 ;
		}
	}
	//------------------------------------------------
	if(	!nCauntPinInClosed)
		return (true);
	else
		return ( false );
}

///////////////////////////////////////////////////////////////////////
//                                                     IF   
///////////////////////////////////////////////////////////////////////

/*=================================================================
 Function      |    DrawBlock                                                   
 Description:  |                       
 Parametrs     |    CDC* pDC
 ReturnValue   |    void    
 Remarks       |    if(InOperMode) color = oper_color    <<== CBrush
			   |              else color = bk_color
===================================================================*/
void  CBIf::DrawBlock(CDC* pDC)                  
{


	CPen MyPen(PS_SOLID, 1 , Gamma[1]);
	CPen* oldPen = pDC->SelectObject(&MyPen);


	COLORREF color ; 
	if(InOperMode)
		color = oper_color ;
	else
		color = bk_color ;
	CBrush b(color);
	CBrush* OldBr = pDC->SelectObject(&b); 
  
	int X = m_LogRect.left + (m_LogRect.Width() / 2);
	int Y = m_LogRect.top  + (m_LogRect.Height() /2);

	CPoint Tmp[4];
	Tmp[0] = CPoint(m_LogRect.left,    Y);
	Tmp[1] = CPoint(X,     m_LogRect.top);
	Tmp[2] = CPoint(m_LogRect.right,   Y);
	Tmp[3] = CPoint(X,  m_LogRect.bottom);
	pDC->Polygon(Tmp, 4); 

	pDC->SelectObject(oldPen);
	pDC->SelectObject (OldBr);
}
/*=================================================================
 Function      |    SetPins                                               
 Description:  |                       
 Parametrs     |    CRect rect
 ReturnValue   |    void    
 Remarks       |   
===================================================================*/
void CBIf::SetPins(CRect r)
{
	m_PinIn.m_p.x  = (r.left + r.right )/2;
	m_PinIn.m_p.y  = r.top - 3;
	m_PinOutYes.m_p.x = r.right +10;
	m_PinOutYes.m_p.y =(r.top + r.bottom )/2-2;
	m_PinOutNo.m_p.x = r.left - 10;
	m_PinOutNo.m_p.y = (r.top + r.bottom )/2-2;	
}
//--------------------------------------------------------------
CPinOut* CBIf::IsCloseToPinOut(CPoint point,CBlock* &pBlock) 
{
	pBlock = NULL ;
	if(m_PinOutYes.IsCloseToPin(point))
	{
		pBlock = this ;
		return (&m_PinOutYes);
	}
	if(m_PinOutNo.IsCloseToPin (point))
	{
		pBlock = this ;
		return(&m_PinOutNo) ;
	}
	return NULL ;
}
/*=================================================================
 Function      |    DrawPin                                                   
 Description:  |                       
 Parametrs     |    CDC* pDC
 ReturnValue   |    void    
 Remarks       |   
===================================================================*/
void  CBIf::DrawPin(CDC* pDC)
{

	SetPins(m_LogRect);
	//--------------------------------
	CPoint p ;
	p.x  = m_LogRect.left - 20 ; p.y = m_LogRect.top - 5;
	pDC->SetTextColor(Gamma[1]);

	pDC->TextOut(p.x,p.y ,"no");
	p.x  = m_LogRect.right ; p.y = m_LogRect.top - 5;
	pDC->TextOut(p.x,p.y ,"yes");
//--------------------------------
	CBrush b(Gamma[2]);
	CBrush* oldBrus = pDC->SelectObject (&b);
	m_PinIn.Draw (pDC,&b);

	CBrush b1( Gamma[4] );
	pDC->SelectObject (&b1);  
	m_PinOutYes.Draw(pDC,&b1);
	m_PinOutNo.Draw(pDC,&b1);

	pDC->SelectObject(oldBrus);
}
/*=================================================================
 Function      |    EnterProperties                                               
 Description:  |                       
 Parametrs     |    void
 ReturnValue   |    void    
 Remarks       |   
===================================================================*/
void CBIf::EnterProperties()
{
	CIfDlg dlg;
	dlg.m_Sourse1 = m_Source1 ;
	dlg.m_Sourse2 = m_Source2 ;
	dlg.m_Oper  = m_BoolOper  ;

	if(dlg.DoModal()==IDOK)
	{
		if(dlg.m_Sourse1 == "" || dlg.m_Sourse2 == "" || dlg.m_Oper == "")
		{
			CErrorDlg Dlg ;
			Dlg.DoModal() ;
			return;
		}
		m_Source1 = dlg.m_Sourse1 ;
		m_Source2 = dlg.m_Sourse2 ;
		m_BoolOper= dlg.m_Oper    ;

		m_Text = dlg.m_Sourse1 + dlg.m_Oper + dlg.m_Sourse2 ; 
	}
}
//--------------------------------------------------------------
void CBIf::Operat(VarList& pVars,CWnd* pCWnd)
{
	long src1 , src2 ;
	if( !m_Source1.IsNumStr()) // m_Source1 not "number"
	{
		Variable* pV = pVars.FindName(m_Source1);
		if(pV) 
			src1 = pV->m_lValue ; 
		//else{}
	}
	else   // m_Source1 "number"
		src1 = m_Source1.TransformStrToInt();
	
	if( !m_Source2.IsNumStr())// m_Source2 not "number"
	{
		Variable* pV = pVars.FindName(m_Source2);
		if(pV)
			src2 = pV->m_lValue ; 
		//else{}
	}
	else// m_Source2  "number"
		src2 = m_Source2.TransformStrToInt();
	
	if(m_BoolOper == '>')
	{
		Result = (src1 > src2);
		return;
	}
	if(m_BoolOper == '<')
	{
		Result = (src1 < src2);
		return;
	}
	if(m_BoolOper == "==")
	{
		Result = (src1 == src2);
		return;
	}
	if(m_BoolOper == "!=")
	{
		Result = (src1 != src2);
		return;
	}
	if(m_BoolOper == ">=")
	{
		Result = (src1 >= src2);
		return;
	}
	if(m_BoolOper == "<=")
	{
		Result = (src1 <= src2);
		return;
	}

}
//--------------------------------------------------------------
CPinOut* CBIf::IsClosePinOutToLine() 
{
	if(m_PinOutYes.m_IsClose)
		return &m_PinOutYes ;
	if(m_PinOutNo.m_IsClose)
		return &m_PinOutNo ;

	return NULL;
}


CBIf::~CBIf() // Virtual Destruction
{
	if(m_PinIn.m_IsClose)
		OpenBlockPrev();

	if(m_PinOutYes.m_IsClose)
	{
		m_PinOutYes.m_IsClose = false ;// MyFlag for CBNode
		((CBIf*)m_PinOutYes.pNext)->OpenBlockNext() ;
	}
	if(m_PinOutNo.m_IsClose)
	{
		m_PinOutNo.m_IsClose = false ;// MyFlag for CBNode
		((CBIf*)m_PinOutNo.pNext)->OpenBlockNext() ;
	}
}
void CBIf::SavePinOutID(int nID)
{
	m_PinOutYes.n_IDpin = nID + 200  ;
	m_PinOutNo.n_IDpin  = nID + 300  ;
}
bool CBIf::FindNext(CBlock* pCar)
{
	
	if(	!bFlag ) nTmp += 0 ;
	{
		if(m_PinOutYes.m_IsClose) nTmp += 1 ;
		if(m_PinOutNo.m_IsClose ) nTmp += 1 ;
		bFlag = true ;
	}
	if(m_PinOutYes.m_IsClose)
	{
		CBlock* pBlock = pCar->HelperFindNext( m_PinOutYes.n_IDpin  );
		if( pBlock  )
		{ 
			m_PinOutYes.pNext = pBlock ;
			nTmp -= 1 ;
		}
	}
	
	if(m_PinOutNo.m_IsClose )
	{
		 CBlock* pBlock = pCar->HelperFindNext( m_PinOutNo.n_IDpin  );
		if( pBlock )
		{ 
			m_PinOutNo.pNext = pBlock ;
			nTmp -= 1 ;
		}
	}
	if( !nTmp )
		return ( true ) ;
	else
		return ( false ) ;
}
CPinOut* CBIf::HelperFindPrevOut(int ID)
{
	if( m_PinOutYes.m_IsClose && (m_PinOutYes.n_IDpin == ID) )
		return (&m_PinOutYes);
	if( m_PinOutNo.m_IsClose  && (m_PinOutNo.n_IDpin == ID) )
		return (&m_PinOutNo);
	return NULL ;
}
int CBIf::HelperSavePinInID(CPinOut* pPrev)
{
	if(m_PinOutYes.m_IsClose && (&m_PinOutYes == pPrev) )
		return ( m_PinOutYes.n_IDpin );
	if(m_PinOutNo.m_IsClose && (&m_PinOutNo == pPrev) )
		return ( m_PinOutNo.n_IDpin );
	return 0 ;	
}
void CBIf::ReSetLine()
{
	if( m_PinIn.m_IsClose )
		m_PinIn.m_pPrevOut->m_Line.SetPin(&m_PinIn)  ;

	if( m_PinOutYes.m_IsClose)
	{
		//########################################################
		if(m_PinOutYes.m_p != ((CPin*)m_PinOutYes.m_Line.GetHead())->m_p)
		{
			m_PinOutYes.m_Line.RemoveHead() ;
			m_PinOutYes.m_Line.AddHead(&m_PinOutYes);  
		}
		//########################################################
	}
	if( m_PinOutNo.m_IsClose)
	{
		//########################################################
		if(m_PinOutNo.m_p != ((CPin*)m_PinOutNo.m_Line.GetHead())->m_p)
		{
			m_PinOutNo.m_Line.RemoveHead() ;
			m_PinOutNo.m_Line.AddHead(&m_PinOutNo);  
		}
		//########################################################
	}

}	
//////////////////////////////////////////////////////////
//                                          CBlocLict   //
//////////////////////////////////////////////////////////
CBlockList::~CBlockList()
{
	POSITION pos1, pos2;
	CObject* pa;
	pos1 = GetHeadPosition();
	while (pos1)
	{
		pos2 = pos1;
		GetNext( pos1 ) ;
		pa = GetAt( pos2 ); // Save the old pointer for deletion.
        RemoveAt( pos2 );
        delete pa; // Deletion avoids memory leak.
	}

}
//-------------------------------------------------------------
void CBlockList::AddBlock(CBlock* pCBlock )
{ 
	AddTail(pCBlock) ;
}
//-------------------------------------------------------------
void CBlockList::OnDraw(CDC* pDC)
{
    POSITION pos = GetHeadPosition();
	while(pos)
	{
		 CObject* pObj  = GetNext(pos)  ; 
		( (CBlock*) pObj ) -> Draw (pDC);  
	}
}
//-------------------------------------------------------------
CPinIn*  CBlockList::IsCloseToPinIn (CPoint point,CBlock* &pBlock)
{
	POSITION pos = GetHeadPosition();
	while (pos)
	{
		CObject* pObj = GetNext(pos);
		CPinIn* p = ((CBlock*)pObj)->IsCloseToPinIn(point,pBlock);
		if (p)
		{
			return (p);
		}
	}
	return NULL;
}
//-------------------------------------------------------------
CPinOut* CBlockList::IsCloseToPinOut(CPoint point,CBlock* &pBlock)
{
	POSITION pos = GetHeadPosition();
	while (pos)
	{
		CObject* pObj = GetNext(pos);
		CPinOut* p = ((CBlock*)pObj)->IsCloseToPinOut(point,pBlock);
		if (p)
		{
			return (p);
		}
	}
	return NULL;
}
//-------------------------------------------------------------
CBlock* CBlockList::IsPointIn(CPoint point)
{
	POSITION pos = GetHeadPosition();
	while (pos)
	{
		CObject* pBase = GetNext(pos);
		CRect rect = ((CBlock*)pBase)->m_Track.m_rect;
		if (rect.PtInRect(point))
			return ((CBlock*)pBase);
	}
	return (0);
}
//-------------------------------------------------------------
//  for  OnLButtonDown
CBlock*  CBlockList::IsTracingBlock(CWnd* pWnd ,CPoint  point,CClientDC*  p_dc) 
{
	CRect rectOld  , rectCarr  ;

	POSITION pos = GetHeadPosition();

	while ( pos )
	{
		CObject* pObjeck = GetNext(pos); 	
		if( ((CBlock*)pObjeck)->m_Track.m_rect.PtInRect(point)  )
		{
			rectOld = ((CBlock*)pObjeck)->m_Track.m_rect ;
			rectOld.top    -= 10 ;
			rectOld.bottom += 10 ;//save m_rect old	
			rectOld.left   -= 24 ;	
			rectOld.right  += 24 ;
		}//-------------------------------------------------

		if(	((CBlock*)pObjeck)->m_Track.Track(pWnd,point) )        //    T R A C K
		{   			
 			((CBlock*)pObjeck)->m_LogRect = ((CBlock*)pObjeck)->m_Track.m_rect ; 
			// tarnsform Coordinates Devace to  Logical Coordinates
			p_dc->DPtoLP (((CBlock*)pObjeck)->m_LogRect);
				
		    ((CBlock*)pObjeck)->SetPins(((CBlock*)pObjeck)->m_LogRect );
			
			if( ((CBlock*)pObjeck)->IsClosePinInToLine() )//Close PinIn
			{
			 	((CBlock*)pObjeck)->ReSetLine();  // Set New Lines
				InvalidateRect(pWnd->m_hWnd,NULL,true);
				return ((CBlock*)pObjeck);
			}//-------------------------------------------------
			if(((CBlock*)pObjeck)->IsClosePinOutToLine())//Close PinOut
			{  			
				((CBlock*)pObjeck)->ReSetLine();
				InvalidateRect(pWnd->m_hWnd,NULL,true);
				return ((CBlock*)pObjeck);
			}//-------------------------------------------------
		     //  if no  lines
				rectCarr = ((CBlock*)pObjeck)->m_Track.m_rect ; 
				rectCarr.top    -= 10 ;
				rectCarr.bottom += 10 ;
				rectCarr.left   -= 24 ;
				rectCarr.right  += 24 ;	
				InvalidateRect(pWnd->m_hWnd,rectOld,true);   // hide rect old
				InvalidateRect(pWnd->m_hWnd,rectCarr,true);  // show rect new
		
		return ((CBlock*)pObjeck);
		}
	}
	return (0); // if !Track()
}
//---------------------------------------------------------------------
CPinOut* CBlockList::IsClosePinOutToLine(CPoint point)
{
	CBlock* pBlock  ;
	POSITION pos = GetHeadPosition();
	while (pos)
	{
		CObject* pObjeck = GetNext(pos);
		CPinOut* pinOut  = ((CBlock*)pObjeck)->IsClosePinOutToLine() ;
		if(((CBlock*)pObjeck)->IsCloseToPinOut(point,pBlock) && pinOut)		
		{
			return pinOut ;	
		}
	}
	return NULL;
}
//-------------------------------------------------------------
void CBlockList::DeleteBlock(CPoint point)
{
	POSITION pos1, pos2;
	CObject* pa;

   for( pos1 = GetHeadPosition() ; ( pos2 = pos1 ) != NULL ; )
   {
		CObject* pBase = GetNext(pos1);
		CRect rect = ((CBlock*)pBase)->m_Track.m_rect;
		if (rect.PtInRect(point))
		{
           pa = GetAt( pos2 );// Save the old pointer for deletion.
           RemoveAt( pos2 );
           delete pa;         // Deletion avoids memory leak.
        }
   }
}
//-------------------------------------------------------------
void CBlockList::Start()
{
	POSITION tmp= GetHeadPosition();
	m_pCurBlock =  (CBlock*)GetNext(tmp);
	m_pCurBlock->InOperMode = true ;
//	m_pOldBlock = m_pCurBlock;

}
//-------------------------------------------------------------
void  CBlockList::Operate(VarList& pVars,CWnd* pCWnd)
{
	CRect cur , old;

		if(	m_pCurBlock )               
		{
			cur = m_pCurBlock->m_Track.m_rect ;      // ReDrow ()
			InvalidateRect(pCWnd->m_hWnd,&cur,true); // Current Block 
		}
		if(	m_pOldBlock	)
		{
			old = m_pOldBlock->m_Track.m_rect ;		//	ReDrow () 
			InvalidateRect(pCWnd->m_hWnd,&old,true);//	Old Block 
		}
		
	if (m_pCurBlock)
	{
		m_pCurBlock->InOperMode = true; // replace
		if(m_pOldBlock)
			m_pOldBlock->InOperMode = false;// Oper Mode flag

		m_pOldBlock = m_pCurBlock;         // save old
		m_pCurBlock->Operat(pVars , pCWnd);// operation  
		
	}
		 
		if( m_pCurBlock->Next() )     // set next
				 m_pCurBlock = m_pCurBlock->Next();		
			 else	
			 {
				 m_pCurBlock = NULL ;

			 }
	
}
void CBlockList::StepByStep(VarList& pVars,CWnd* pCWnd )
{
	CRect cur , old;

	 
	if(!m_IsInitStepByStep)// first step
	{	
		POSITION tmp = GetHeadPosition();
		m_pCurBlock  =  (CBlock*)GetNext(tmp);		
		m_IsInitStepByStep = true;	
	}//----------------------------------------

	if(m_pCurBlock)//run step by step
	{
		if (m_pCurBlock)
		{
			m_pCurBlock->InOperMode = true;    
			m_pCurBlock->Operat(pVars , pCWnd);
			cur = m_pCurBlock->m_Track.m_rect ;      // ReDrow ()
			InvalidateRect(pCWnd->m_hWnd,&cur,true); // Current Block 
		}

		if(m_pOldBlock)
		{
			m_pOldBlock->InOperMode = false;        // Oper Mode flag
			old = m_pOldBlock->m_Track.m_rect ;		//	ReDrow () 
			InvalidateRect(pCWnd->m_hWnd,&old,true);//	Old Block 
		}

		m_pOldBlock = m_pCurBlock;   
		if( m_pCurBlock->Next() )     // set next
				 m_pCurBlock = m_pCurBlock->Next();		
			 else			 
				 m_pCurBlock = NULL ;
	}//------------------------------------------
	
	else //finish step by step
	{
		if(m_pOldBlock)
		{
		m_pOldBlock->InOperMode = false;        // Oper Mode flag
		old = m_pOldBlock->m_Track.m_rect ;		//	ReDrow () 
		InvalidateRect(pCWnd->m_hWnd,&old,true);//	Old Block 
		m_pOldBlock = NULL ;
		}
		m_IsInitStepByStep = false ;
	}
	 			
}
//----------------------------------------------------------


//  for  OnLButtonDown
/////////////////////////////////////////////////////////////////
//                                       If OnFocus CBlock     //
/////////////////////////////////////////////////////////////////	
void CBlockList::SetRectTrackerStyle(CWnd* pWnd, CPoint point) 
{
	if( CBlock* pBlock = IsPointIn(point) )
	{	
		POSITION pos = GetHeadPosition();  
		while (pos)  
		{                  
			CBlock* pTmp = (CBlock*)GetNext(pos);
			if (pTmp->m_Track.m_nStyle == CRectTracker::resizeInside) 
			{ 
			    pTmp->m_Track.m_nStyle = NULL ;  // Old
				pWnd->InvalidateRect(pTmp->m_Track.m_rect) ;
			}
		}   	                                 // Curr
		pBlock->m_Track.m_nStyle = CRectTracker::resizeInside;
		pWnd->InvalidateRect(pBlock->m_Track.m_rect) ;
	}	
	                ///////////////////////////////////////////
	else			//              If NotOnFocus CBlock     //
	{			    ///////////////////////////////////////////  					                                        	             
		POSITION pos = GetHeadPosition();  
		while (pos)      
		{
			CBlock* pTmp = (CBlock*)GetNext(pos);
			if (pTmp->m_Track.m_nStyle == CRectTracker::resizeInside )
			{
			    pTmp->m_Track.m_nStyle = NULL ;
				pWnd->InvalidateRect(pTmp->m_Track.m_rect); 
			}
		}
	}  
 }