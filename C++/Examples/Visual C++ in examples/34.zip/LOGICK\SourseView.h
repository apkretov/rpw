#if !defined(AFX_SOURSEVIEW_H__A91E3461_40CD_11D5_9D8E_E78EE5D6AE5C__INCLUDED_)
#define AFX_SOURSEVIEW_H__A91E3461_40CD_11D5_9D8E_E78EE5D6AE5C__INCLUDED_

#include "LogickDoc.h"
#include "stdafx.h"

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// SourseView.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// CSourceView view

class CSourceView : public CScrollView
{
protected:
	CSourceView();           // protected constructor used by dynamic creation
	DECLARE_DYNCREATE(CSourceView)

// Attributes
public:
	CLogickDoc* GetDocument();
// Operations
public:
	CHeaderCtrl  m_Horz ;
	int m_Offset[2];

    int szText[2] ;
// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CSourceView)
	protected:
	virtual void OnDraw(CDC* pDC);      // overridden to draw this view
	virtual void OnInitialUpdate();     // first time after construct
	virtual void OnUpdate(CView* pSender, LPARAM lHint, CObject* pHint);
	virtual BOOL OnNotify(WPARAM wParam, LPARAM lParam, LRESULT* pResult);
	//}}AFX_VIRTUAL

// Implementation
protected:
	virtual ~CSourceView();
#ifdef _DEBUG
	virtual void AssertValid() const;
	virtual void Dump(CDumpContext& dc) const;
#endif

	// Generated message map functions
	//{{AFX_MSG(CSourceView)
	afx_msg void OnTimer(UINT nIDEvent);
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_SOURSEVIEW_H__A91E3461_40CD_11D5_9D8E_E78EE5D6AE5C__INCLUDED_)
