// LogickDoc.h : interface of the CLogickDoc class
//
/////////////////////////////////////////////////////////////////////////////

#if !defined(AFX_LOGICKDOC_H__A0A8616D_32FA_11D5_9D8E_BE3D01A9D579__INCLUDED_)
#define AFX_LOGICKDOC_H__A0A8616D_32FA_11D5_9D8E_BE3D01A9D579__INCLUDED_

#include "Block.h"
#include "NumStr.h"

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000


class CLogickDoc : public CDocument
{
protected: // create from serialization only
	CLogickDoc();
	DECLARE_DYNCREATE(CLogickDoc)

// Attributes
public:


	CBlockList m_BlockList ;
	VarList    m_Vars      ;
	int  m_nTimer          ;
	BOOL m_bTimerIsSet     ;

// Operations
public:

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CLogickDoc)
	public:
	virtual BOOL OnNewDocument();
	virtual void Serialize(CArchive& ar);
	virtual void DeleteContents();
	//}}AFX_VIRTUAL

// Implementation
public:
	virtual ~CLogickDoc();
#ifdef _DEBUG
	virtual void AssertValid() const;
	virtual void Dump(CDumpContext& dc) const;
#endif

protected:

// Generated message map functions
protected:
	//{{AFX_MSG(CLogickDoc)
		// NOTE - the ClassWizard will add and remove member functions here.
		//    DO NOT EDIT what you see in these blocks of generated code !
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_LOGICKDOC_H__A0A8616D_32FA_11D5_9D8E_BE3D01A9D579__INCLUDED_)
