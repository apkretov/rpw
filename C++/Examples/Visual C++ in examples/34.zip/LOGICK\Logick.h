// Logick.h : main header file for the LOGICK application
//

#if !defined(AFX_LOGICK_H__A0A86165_32FA_11D5_9D8E_BE3D01A9D579__INCLUDED_)
#define AFX_LOGICK_H__A0A86165_32FA_11D5_9D8E_BE3D01A9D579__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#ifndef __AFXWIN_H__
	#error include 'stdafx.h' before including this file for PCH
#endif

#include "resource.h"       // main symbols

/////////////////////////////////////////////////////////////////////////////
// CLogickApp:
// See Logick.cpp for the implementation of this class
//

class CLogickApp : public CWinApp
{
public:
	CLogickApp();

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CLogickApp)
	public:
	virtual BOOL InitInstance();
	//}}AFX_VIRTUAL

// Implementation
	//{{AFX_MSG(CLogickApp)
	afx_msg void OnAppAbout();
		// NOTE - the ClassWizard will add and remove member functions here.
		//    DO NOT EDIT what you see in these blocks of generated code !
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};


/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_LOGICK_H__A0A86165_32FA_11D5_9D8E_BE3D01A9D579__INCLUDED_)
