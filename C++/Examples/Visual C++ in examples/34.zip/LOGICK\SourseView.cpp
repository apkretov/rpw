// SourseView.cpp : implementation file
//

#include "stdafx.h"
#include "logick.h"
#include "SourseView.h"



#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CSourceView

IMPLEMENT_DYNCREATE(CSourceView, CScrollView)

CSourceView::CSourceView()
{
}

CSourceView::~CSourceView()
{
}


BEGIN_MESSAGE_MAP(CSourceView, CScrollView)
	//{{AFX_MSG_MAP(CSourceView)
	ON_WM_TIMER()
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CSourceView drawing

void CSourceView::OnInitialUpdate()
{

	CSize sizeTotal;
	// TODO: calculate the total size of this view

//----------------------------------------------------
	CRect rect;
	 	
	GetClientRect(&rect);
    rect.bottom = 20;
   rect.right = rect.left + 180;
 // rect.DeflateRect(5, 5);

	m_Horz.Create(HDS_BUTTONS | HDS_HORZ | CCS_TOP | HDS_HOTTRACK |
    WS_CHILD | WS_VISIBLE, rect, this, 1000);

  int nWidth = (rect.Width() / 2);

	TCHAR szText1[10] = {"Name"};
	HD_ITEM item0 = { HDI_TEXT | HDI_WIDTH, nWidth, szText1, NULL, 1 };
	m_Horz.InsertItem(1, &item0);
	m_Offset[0] = nWidth ;

	TCHAR szText2[10] = {"Value"};
	HD_ITEM item1 = { HDI_TEXT | HDI_WIDTH, nWidth, szText2, NULL, 1 };
	m_Horz.InsertItem(2, &item1);
	m_Offset[0] = nWidth ;

    m_Horz.SetHotDivider(0);
//	m_Horz.SetHotDivider(1);
//	m_Horz.SetHotDivider(2);
//----------------------------------------------------
	sizeTotal.cx = sizeTotal.cy = 200;
	SetScrollSizes(MM_TEXT, sizeTotal);

	CScrollView::OnInitialUpdate();
}

void CSourceView::OnDraw(CDC* pDC)
{

	if(IsIconic()) {}
	else
	{
		CRect rect ;
		GetClientRect(rect);
		rect.bottom += 20 ;
		int nOffSet = 0 ;
		for(int i = 0; i < 2  ;i++)
		{
				nOffSet += m_Offset[i] ; 
				pDC->MoveTo(nOffSet ,20);
			    pDC->LineTo(nOffSet ,rect.bottom);
		}
	}
//
	
	CLogickDoc* pDoc = GetDocument();
	pDoc->m_Vars.Draw(pDC);  

}

/////////////////////////////////////////////////////////////////////////////
// CSourceView diagnostics

#ifdef _DEBUG
void CSourceView::AssertValid() const
{
	CScrollView::AssertValid();
}

void CSourceView::Dump(CDumpContext& dc) const
{
	CScrollView::Dump(dc);
}
//CLogickDoc* CSourceView::GetDocument() // non-debug version is inline
//{
//	ASSERT(m_pDocument->IsKindOf(RUNTIME_CLASS(CLogickDoc)));
//	return (CLogickDoc*)m_pDocument;
//}
#endif //_DEBUG

/////////////////////////////////////////////////////////////////////////////
// CSourceView message handlers

CLogickDoc* CSourceView::GetDocument() // non-debug version is inline
{
	ASSERT(m_pDocument->IsKindOf(RUNTIME_CLASS(CLogickDoc)));
	return (CLogickDoc*)m_pDocument;
}

void CSourceView::OnTimer(UINT nIDEvent) 
{
	Invalidate();	
	CScrollView::OnTimer(nIDEvent);
}

void CSourceView::OnUpdate(CView* pSender, LPARAM lHint, CObject* pHint) 
{
/*	CRect rect; 	
	GetClientRect(&rect);
    rect.bottom = 20;
	m_Horz.RedrawWindow();  */
	Invalidate();
}

BOOL CSourceView::OnNotify(WPARAM wParam, LPARAM lParam, LRESULT* pResult) 
{
	NMHDR *nmhdr = (NMHDR *)lParam ;    //        &;-)
	if(nmhdr->hwndFrom == m_Horz.m_hWnd)
	{
		if(nmhdr->code == HDN_ENDTRACK)
		{
			HD_NOTIFY *phdn = (HD_NOTIFY *)lParam;
			m_Offset[phdn->iItem]=phdn->pitem->cxy;
			Invalidate();
		}
	}
	
	return CScrollView::OnNotify(wParam, lParam, pResult);
}

