//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by Logick.rc
//
#define IDD_ABOUTBOX                    100
#define IDR_MAINFRAME                   128
#define IDR_LOGICKTYPE                  129
#define IDR_MENU1                       131
#define IDD_DIAL_INPUT                  132
#define IDI_ICON1                       133
#define IDR_TOOLSBAR                    136
#define IDR_MENU2                       138
#define IDD_DIAL_OPERATION              139
#define IDD_DIAL_IF                     140
#define IDD_DIALVIEW                    149
#define IDD_DIAL_ERROR                  150
#define IDB_SPLASH                      160
#define IDB_BITMAP1                     165
#define IDB_BITMAP2                     166
#define IDB_BITMAP3                     167
#define IDD_DIALOG1                     168
#define IDC_EDIT1                       1000
#define IDC_COMBO1                      1001
#define IDC_EDIT4                       1001
#define IDC_EDIT2                       1002
#define IDC_COMBO2                      1007
#define ID_NEW_SELECT                   32780
#define ID_NEW_NODE                     32781
#define ID_NEW_NETLINE                  32782
#define ID_NEW_OPERATOR                 32783
#define ID_NEW_OPERATION                32784
#define ID_NEW_IF                       32785
#define ID_NEW_IFELSE                   32786
#define ID_NEW_FOR                      32787
#define ID_NEW_WHILE                    32788
#define ID_NEW_DOWHILE                  32789
#define ID_NEW_SWITCH                   32790
#define ID_NEW_TEXT                     32791
#define ID_TOOLS                        32792
#define ID_OPEN_PROPERTI                32793
#define ID_BLOC_DELETE                  32794
#define ID_SOURS_VIEWER                 32795
#define ID_RUN                          32796
#define ID_STOP                         32797
#define ID_SET_TIME                     32799
#define ID_STEP_BY                      32800

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_3D_CONTROLS                     1
#define _APS_NEXT_RESOURCE_VALUE        169
#define _APS_NEXT_COMMAND_VALUE         32801
#define _APS_NEXT_CONTROL_VALUE         1013
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
