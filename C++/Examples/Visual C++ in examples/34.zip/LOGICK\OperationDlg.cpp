// OperationDlg.cpp : implementation file
//

#include "stdafx.h"
#include "logick.h"
#include "OperationDlg.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// COperationDlg dialog


COperationDlg::COperationDlg(CWnd* pParent /*=NULL*/)
	: CDialog(COperationDlg::IDD, pParent)
{
	//{{AFX_DATA_INIT(COperationDlg)
	m_Oper = _T("");
	m_Dest = _T("");
	m_Sourse2 = _T("");
	m_Sourse1 = _T("");
	//}}AFX_DATA_INIT
}


void COperationDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(COperationDlg)
	DDX_CBString(pDX, IDC_COMBO2, m_Oper);
	DDX_Text(pDX, IDC_EDIT1, m_Dest);
	DDX_Text(pDX, IDC_EDIT2, m_Sourse2);
	DDX_Text(pDX, IDC_EDIT4, m_Sourse1);
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(COperationDlg, CDialog)
	//{{AFX_MSG_MAP(COperationDlg)
		// NOTE: the ClassWizard will add message map macros here
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// COperationDlg message handlers
