// list.cpp : Defines the entry point for the console application.
//
//this is an example of using bidirectional lists and operator overloading
//(x)1999 bAmBi [CPG]


#include "stdafx.h"
#include "stdio.h"
#include "string.h"
#include "malloc.h"

class Node
{
public:
   Node *PreviousNode,*NextNode;
   char *Data;

   Node(char *source)
   {
      Data = (char *)malloc( strlen( source )+1 );
      strcpy( Data, source );
      NextNode = NULL;
   }

   ~Node()
   {
      free( Data );
   }
};

class List
{
public:
   Node *Nodes;

   List()
   {
      Nodes = NULL;
   }

   ~List()
   {
      Node *temp;
      while( !Nodes )
      {
	 temp = Nodes;
	 Nodes = temp->NextNode;
	 delete temp;
      }
   }

   void Add(char *source)
   {
      Node *temp;
      temp = new Node( source );
      temp->NextNode = Nodes;
      if ( Nodes ) Nodes->PreviousNode = temp;
      Nodes = temp;
   }

   char*& operator[]( int iIndex )
   {
      Node *temp = Nodes;
      int i = 0;
      while( temp->NextNode ) temp = temp->NextNode;
      while( i < iIndex )
      {
	 if( temp ) temp = temp->PreviousNode;
	 i++;
      }
      return temp->Data;
   }
};


void main()
{
List *test;

   test = new List;

   test->Add( "string1" );
   test->Add( "string2" );
   test->Add( "string3" );

   (*test)[0] = "this is replacement of string1";

   for( int i = 0;i < 3;i++ ) printf( "%s\n", (*test)[i] );

   delete test;
}
