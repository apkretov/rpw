// this tiny code snapshot was written by bAmBi [CPG] just
// for demonstration. it shows how to create tooltips
// using Win32 API only.

#include "windows.h"
#include "commctrl.h"

#pragma comment(lib,"Comctl32.lib")

HANDLE hInstance;
TOOLINFO tool;

BOOL CALLBACK Main_WndProc( HWND,UINT,WPARAM,LPARAM );
void CreateTooltips( HWND );

void main()
{
   WNDCLASSEX wndclass;
   HWND hWnd;
   MSG msg;
   
   wndclass.cbSize = sizeof( wndclass );
   wndclass.style = CS_HREDRAW | CS_VREDRAW;
   wndclass.lpfnWndProc = (WNDPROC)Main_WndProc;
   wndclass.cbClsExtra = 0;
   wndclass.cbWndExtra = 0;
   wndclass.hInstance = hInstance = GetModuleHandle( 0 );
   wndclass.hIcon = wndclass.hIconSm = LoadIcon( 0,IDI_APPLICATION );
   wndclass.hCursor = LoadCursor( NULL, IDC_ARROW );
   wndclass.hbrBackground = (HBRUSH)GetStockObject( WHITE_BRUSH );
   wndclass.lpszMenuName = 0;
   wndclass.lpszClassName = "test.class";
   
   RegisterClassEx( &wndclass );
   
   hWnd = CreateWindow( "test.class","Tooltips demo by bAmBi [CPG]",WS_OVERLAPPEDWINDOW,2,2,300,200,0,0,hInstance,0 );

   ShowWindow( hWnd,SW_NORMAL );
   UpdateWindow( hWnd );

   while( GetMessage( &msg,0,0,0 ) )
   {
      TranslateMessage( &msg );
      DispatchMessage( &msg );
   }

   ExitProcess( msg.wParam );
}

BOOL CALLBACK Main_WndProc( HWND hWnd,UINT uMsg,WPARAM wParam,LPARAM lParam )
{
   HDC hDC;
   PAINTSTRUCT ps;
   static int flag = 1;
   
   switch( uMsg )
   {
      case WM_CREATE :
         CreateTooltips( hWnd );
         return 0;
      case WM_PAINT :
         hDC = BeginPaint( hWnd,&ps );

	 SelectObject( hDC,CreateSolidBrush( 0xff0000 ) );
	 Rectangle( hDC,20,20,80,80 ); // area for first tooltip

         SelectObject( hDC,CreateSolidBrush( 0x00ff00 ) );
         Rectangle( hDC,120,30,240,90 ); // area for second tooltip

	 SelectObject( hDC,CreateSolidBrush( 0x0000ff ) );
         Rectangle( hDC,60,100,220,160 ); // area for third tooltip
	 
         EndPaint( hWnd,&ps );
         return 0;
      case WM_DESTROY :
	 PostQuitMessage( 0 );
	 return 0;
   }
   return DefWindowProc( hWnd,uMsg,wParam,lParam );
}

void CreateTooltips( HWND hwndParent )
{
   HWND hTooltipControl;
   INITCOMMONCONTROLSEX ii;
   
   InitCommonControls();
   hTooltipControl = CreateWindowEx( 0,"tooltips_class32","",TTS_ALWAYSTIP | TTS_NOPREFIX,0,0,0,0,hwndParent,0,hInstance,0 );
   
   SendMessage( hTooltipControl,TTM_SETDELAYTIME,TTDT_INITIAL,1000 );
   SendMessage( hTooltipControl,TTM_SETDELAYTIME,TTDT_AUTOPOP,3000 );
   SendMessage( hTooltipControl,TTM_SETDELAYTIME,TTDT_RESHOW,1000 );
   
   tool.cbSize = sizeof( tool );
   tool.uFlags = TTF_CENTERTIP | TTF_SUBCLASS;
   tool.hwnd = hwndParent;
   tool.uId = 1;
   tool.rect.top = 20;
   tool.rect.bottom = 80;
   tool.rect.left = 20;
   tool.rect.right = 80;
   tool.hinst = 0;
   tool.lpszText = "Tooltip #1: Blue square";
   SendMessage( hTooltipControl,TTM_ADDTOOL,0,(LPARAM)&tool ); // create first tooltip

   tool.uId = 2;
   tool.rect.top = 30;
   tool.rect.bottom = 90;
   tool.rect.left = 120;
   tool.rect.right = 240;
   tool.lpszText = "Tooltip #2: Green rectangle";
   SendMessage( hTooltipControl,TTM_ADDTOOL,0,(LPARAM)&tool ); // create second tooltip

   tool.uId = 3;
   tool.rect.top = 100;
   tool.rect.bottom = 160;
   tool.rect.left = 60;
   tool.rect.right = 220;
   tool.lpszText = "Tooltip #3: Red rectangle";
   SendMessage( hTooltipControl,TTM_ADDTOOL,0,(LPARAM)&tool ); // create thid tootip
}
