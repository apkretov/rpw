// OSFtpDlg.h : header file
//

#if !defined(AFX_OSFTPDLG_H__531D1366_A255_11D2_BFBE_444553540001__INCLUDED_)
#define AFX_OSFTPDLG_H__531D1366_A255_11D2_BFBE_444553540001__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

/////////////////////////////////////////////////////////////////////////////
// COSFtpDlg dialog

class COSFtpDlg : public CDialog
{
// Construction
public:
	~COSFtpDlg();
	COSFtpDlg(CWnd* pParent = NULL);	// standard constructor

// Dialog Data
	//{{AFX_DATA(COSFtpDlg)
	enum { IDD = IDD_OSFTP_DIALOG };
	CListCtrl	m_cFileList;
	CListBox	m_cDirList;
	CString	m_sConSrv;
	CString	m_sStatusBar;
	CString	m_sDirNowText;
	int		m_iAnonorPrompt;
	//}}AFX_DATA

	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(COSFtpDlg)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);	// DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:
	HICON m_hIcon;

	// Generated message map functions
	//{{AFX_MSG(COSFtpDlg)
	virtual BOOL OnInitDialog();
	afx_msg void OnSysCommand(UINT nID, LPARAM lParam);
	afx_msg void OnPaint();
	afx_msg HCURSOR OnQueryDragIcon();
	virtual void OnOK();
	afx_msg void OnConnectBtn();
	afx_msg void OnDblclkDirList();
	afx_msg void OnAddDir();
	afx_msg void OnDelDir();
	afx_msg void OnDblclkFileList(NMHDR* pNMHDR, LRESULT* pResult);
	afx_msg void OnDwnLdFile();
	afx_msg void OnUpLdFile();
	afx_msg void OnDelFile();
	afx_msg void OnRenFile();
	//}}AFX_MSG
	LRESULT OnDoFind(WPARAM, LPARAM);
	BOOL OnNeedToolTip(UINT, NMHDR*, LRESULT*);
	DECLARE_MESSAGE_MAP()
private:
	bool PutFile2();
	bool GetPutInfo(CString&);
	bool GetSelectedItem(CString&);
	// functions
	bool CreateInetSession();
	bool FillListCtrl(CFtpFileFind&, int);
	bool GetFile(LPCTSTR);
	bool GetFile2(LPCTSTR);
	bool GetFTPConnection();
	bool GetSaveInfo(CString& fileData, LPCTSTR saveName = NULL);
	void OnConnect();
	void OnDisconnect();
	bool SetupListCtrl();
	// Variables
	CString m_sPwd;
	CString m_sUsrName;
	CBitmap m_gAddDir, m_gDelDir, m_gRenFile, m_gDelFile, m_gDwnLdFile, m_gUpLdFile;
	CFtpConnection* m_pFtpCon;
	CInternetSession* m_pInetSession;
	bool m_bConnected;
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_OSFTPDLG_H__531D1366_A255_11D2_BFBE_444553540001__INCLUDED_)
