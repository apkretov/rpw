#if !defined(AFX_GETSTRINGDLG_H__2AE12C61_A7CD_11D2_BFBE_444553540001__INCLUDED_)
#define AFX_GETSTRINGDLG_H__2AE12C61_A7CD_11D2_BFBE_444553540001__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// GetStringDlg.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// CGetStringDlg dialog

class CGetStringDlg : public CDialog
{
	// Dialog Data
	//{{AFX_DATA(CGetStringDlg)
	enum { IDD = IDD_GetStringDlg };
	CString	m_sString;
	CString	m_sStaticText;
	CString	m_sPwd;
	//}}AFX_DATA
	boolean m_bGetPwd;
	CString m_sTitle;

// Construction
public:
	CGetStringDlg(UINT ID_Title, UINT ID_StaticText, CWnd* pParent = NULL, bool getPwd = false);
	LPCTSTR GetString(){return m_sString;}
	LPCTSTR GetPwdString(){return m_sPwd;}
	void SetString(LPCTSTR strText){m_sString = strText;}
	void SetPwdString(LPCTSTR strPwd){m_sPwd = strPwd;}

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CGetStringDlg)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:

	// Generated message map functions
	//{{AFX_MSG(CGetStringDlg)
	virtual BOOL OnInitDialog();
	virtual void OnOK();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_GETSTRINGDLG_H__2AE12C61_A7CD_11D2_BFBE_444553540001__INCLUDED_)
