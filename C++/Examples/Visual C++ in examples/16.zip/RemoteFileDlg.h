#if !defined(AFX_REMOTEFILEDLG_H__396D3622_AD3B_11D2_BFBE_444553540001__INCLUDED_)
#define AFX_REMOTEFILEDLG_H__396D3622_AD3B_11D2_BFBE_444553540001__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// RemoteFileDlg.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// CRemoteFileDlg dialog

class CRemoteFileDlg : public CDialog
{
// Construction
public:
	CRemoteFileDlg(CFile&, CInternetFile&, CWnd* pParent = NULL, bool getFile = true);   // standard constructor
	void SetBlockSize(DWORD size){if (size >= 1024) m_iBlockSize = size;}
	bool IsError(){return m_bError;}
	LPCTSTR GetErrorText(){return m_sErrorText;}
// Dialog Data
	//{{AFX_DATA(CRemoteFileDlg)
	enum { IDD = IDD_RemoteFileDlg };
	CProgressCtrl	m_cProgress;
	CString	m_sFileData;
	CString	m_sFileName;
	//}}AFX_DATA


// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CRemoteFileDlg)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:
	LRESULT GetFile(WPARAM, LPARAM);
	LRESULT PutFile(WPARAM, LPARAM);
	// Generated message map functions
	//{{AFX_MSG(CRemoteFileDlg)
	virtual void OnCancel();
	virtual void OnOK();
	virtual BOOL OnInitDialog();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
private:
	bool PumpMsgs();
	bool m_bTranInProgess;
	bool m_bContinue;
	bool m_bGetFile;
	bool m_bError;
	DWORD m_iBlockSize;
	DWORD m_iFileSize;
	DWORD m_iBytes;
	CString m_sFileDataFormat;
	CString m_sErrorText;
	CFile& m_cLocalFile;
	CInternetFile& m_cRemoteFile;
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_REMOTEFILEDLG_H__396D3622_AD3B_11D2_BFBE_444553540001__INCLUDED_)
