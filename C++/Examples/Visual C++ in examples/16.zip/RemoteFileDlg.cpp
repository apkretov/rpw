// RemoteFileDlg.cpp : implementation file
//

#include "stdafx.h"
#include "OSFtp.h"
#include "RemoteFileDlg.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

#define WMMSG_StartDwnLd WM_USER+2000
#define WMMSG_StartUpLd WM_USER+2001

/////////////////////////////////////////////////////////////////////////////
// CRemoteFileDlg dialog


CRemoteFileDlg::CRemoteFileDlg(CFile& local, CInternetFile& remote,
							   CWnd* pParent /*=NULL*/, bool getFile /*=true*/)
: m_cLocalFile(local), m_cRemoteFile(remote), 
  m_bGetFile(getFile), CDialog(CRemoteFileDlg::IDD, pParent)
{
	//{{AFX_DATA_INIT(CRemoteFileDlg)
	m_sFileData = _T("");
	m_sFileName = _T("");
	//}}AFX_DATA_INIT
	m_sErrorText = _T("");
	m_sFileDataFormat.LoadString((m_bGetFile)?IDS_FileRcvFormat:IDS_FilePutFormat);
	m_iFileSize = 0;
	m_iBytes = 0;
	m_iBlockSize = 2048;
	m_bError = false;
	m_bTranInProgess = false;
	m_bContinue = true;
}


void CRemoteFileDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CRemoteFileDlg)
	DDX_Control(pDX, IDC_PROGRESS1, m_cProgress);
	DDX_Text(pDX, IDC_RcvSntBytes, m_sFileData);
	DDX_Text(pDX, IDC_FileName, m_sFileName);
	//}}AFX_DATA_MAP
}

bool CRemoteFileDlg::PumpMsgs()
{
	MSG msg;

	// Any messages need to be handled
	while (::PeekMessage (&msg, NULL, 0, 0, PM_NOREMOVE)) 
	{
		TRACE("Pumping a message....\n");
		if (!AfxGetApp ()->PumpMessage ()) 
		{
			::PostQuitMessage (0);
			return false;
		}
	}
	return true;
}


BEGIN_MESSAGE_MAP(CRemoteFileDlg, CDialog)
	//{{AFX_MSG_MAP(CRemoteFileDlg)
	//}}AFX_MSG_MAP
	ON_MESSAGE(WMMSG_StartDwnLd, GetFile)
	ON_MESSAGE(WMMSG_StartUpLd, PutFile)
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CRemoteFileDlg message handlers

void CRemoteFileDlg::OnOK()
{
	// Do Nothing
}

void CRemoteFileDlg::OnCancel() 
{
	TRACE("Cancel btn pressed!!\n");
	// user pressed the cancel button, make sure the error flag is not set
	m_bError = false;
	m_bContinue = false;

	// if we are not in the middle of a transfer then end the dialog
	if (m_bTranInProgess == false)
		CDialog::OnCancel();
}

BOOL CRemoteFileDlg::OnInitDialog() 
{
	CDialog::OnInitDialog();
	
	// Getting or sending file?
	if (m_bGetFile)
	{
		// Get the size of the remote file
		m_iFileSize = m_cRemoteFile.GetLength();
		// Setup the text block
		m_sFileData.Format(m_sFileDataFormat, m_iBytes, m_iFileSize);
		// Set the upper range to the size of the file in KBs
		m_cProgress.SetRange32(0, m_iFileSize/1024);
		// Set the "step" rate of the progress control to 
		// the number of KB per block
		m_cProgress.SetStep((int)m_iBlockSize/1024);
		// Get the remote file name
		m_sFileName = m_cRemoteFile.GetFileName();
		
		// Set the dialogs title
		CString Title;
		Title.LoadString(IDS_RemoteFileDlgGetTitle);
		SetWindowText(Title);

		UpdateData(FALSE);

		PostMessage(WMMSG_StartDwnLd);
	}
	else
	{
		// Get the size of the Local file
		m_iFileSize = m_cLocalFile.GetLength();
		// Setup the text block
		m_sFileData.Format(m_sFileDataFormat, m_iBytes, m_iFileSize);
		// Set the upper range to the size of the file in KBs
		m_cProgress.SetRange32(0, m_iFileSize/1024);
		// Set the "step" rate of the progress control to 
		// the number of KB per block
		m_cProgress.SetStep((int)m_iBlockSize/1024);
		// Get the local file name
		m_sFileName = m_cLocalFile.GetFileName();
		
		// Set the dialogs title
		CString Title;
		Title.LoadString(IDS_RemoteFileDlgPutTitle);
		SetWindowText(Title);

		UpdateData(FALSE);

		PostMessage(WMMSG_StartUpLd);
	}

	return TRUE;  // return TRUE unless you set the focus to a control
	              // EXCEPTION: OCX Property Pages should return FALSE
}

LRESULT CRemoteFileDlg::GetFile(WPARAM, LPARAM)
{
	BYTE* Buf = NULL;
	try
	{
		Buf = new BYTE[m_iBlockSize+1];
		m_bTranInProgess = true;

		// Start reading from the remote file
		DWORD bytesRead = m_cRemoteFile.Read((LPVOID)Buf, m_iBlockSize);
		while (bytesRead > 0 && m_bContinue)
		{
			// Pump messages -> this lets the window be more responsive
			// However it slows the download down
			PumpMsgs();

			// add the number of bytes read to our total
			m_iBytes += bytesRead;
			// write to the local file
			m_cLocalFile.Write((LPVOID)Buf, bytesRead);

			// update the progress control and the text
			m_sFileData.Format(m_sFileDataFormat, m_iBytes, m_iFileSize);
			m_cProgress.StepIt();
			UpdateData(FALSE);

			// force a repaint of the window
			UpdateWindow();

			// Pump messages -> this lets the window be more responsive
			// However it slows the download down
			PumpMsgs();
			
			// read from the remote file
			bytesRead = m_cRemoteFile.Read((LPVOID)Buf, m_iBlockSize);
		}
	}
	catch(CException* e)
	{
		// Error Occurred, set the error flag, error text and abort
		TCHAR errTxt[513];
		e->GetErrorMessage(errTxt, 512);
		m_bError = true;
		m_sErrorText = errTxt;
		m_bTranInProgess = false;

		if (Buf != NULL)
		{
			delete [] Buf;
			Buf = NULL;
		}

		CDialog::OnCancel();
		return 1L;
	}
	
	m_bTranInProgess = false;
	if (Buf != NULL)
	{
		delete [] Buf;
		Buf = NULL;
	}
	
	// m_bContinue should only be set to false if the cancel button is pressed
	if (m_bContinue)
		CDialog::OnOK();
	else
		CDialog::OnCancel();

	return 0L;
}

LRESULT CRemoteFileDlg::PutFile(WPARAM, LPARAM)
{
	BYTE* Buf = NULL;
	try
	{
		Buf = new BYTE[m_iBlockSize+1];
		m_bTranInProgess = true;

		// Start reading from the Local file
		DWORD bytesRead = m_cLocalFile.Read((LPVOID)Buf, m_iBlockSize);

		while (bytesRead > 0 && m_bContinue)
		{
			// add the number of bytes read to our total
			m_iBytes += bytesRead;

			// write to the Remote file
			m_cRemoteFile.Write((LPVOID)Buf, bytesRead);

			// Pump messages -> this lets the window be more responsive
			// However it slows the upload down
			PumpMsgs();

			// update the progress control and the text
			m_sFileData.Format(m_sFileDataFormat, m_iBytes, m_iFileSize);
			m_cProgress.StepIt();
			UpdateData(FALSE);

			// force a repaint of the window
			UpdateWindow();

			// Pump messages -> this lets the window be more responsive
			// However it slows the download down
			PumpMsgs();
			
			// read from the Local file
			bytesRead = m_cLocalFile.Read((LPVOID)Buf, m_iBlockSize);
		}
	}
	catch(CException* e)
	{
		// Error Occurred, set the error flag, error text and abort
		TCHAR errTxt[513];
		e->GetErrorMessage(errTxt, 512);
		m_bError = true;
		m_sErrorText = errTxt;
		m_bTranInProgess = false;

		if (Buf != NULL)
		{
			delete [] Buf;
			Buf = NULL;
		}

		CDialog::OnCancel();
		return 1L;
	}
	
	m_bTranInProgess = false;
	if (Buf != NULL)
	{
		delete [] Buf;
		Buf = NULL;
	}
	
	// m_bContinue should only be set to false if the cancel button is pressed
	if (m_bContinue)
		CDialog::OnOK();
	else
		CDialog::OnCancel();

	return 0L;
}
