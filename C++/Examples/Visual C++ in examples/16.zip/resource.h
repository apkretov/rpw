//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by OSFtp.rc
//
#define IDM_ABOUTBOX                    0x0010
#define IDD_ABOUTBOX                    100
#define IDS_ABOUTBOX                    101
#define IDD_OSFTP_DIALOG                102
#define IDP_SOCKETS_INIT_FAILED         103
#define IDR_MAINFRAME                   128
#define IDB_Delete                      130
#define IDB_Add                         132
#define IDD_GetStringDlg                133
#define IDB_RenFile                     134
#define IDB_DelFile                     135
#define IDB_UpLdFile                    136
#define IDB_DwnLdFile                   137
#define IDD_RemoteFileDlg               138
#define IDS_Resolving_Name              300
#define IDS_Name_Rsv                    301
#define IDS_Connecting_Srv              302
#define IDS_Connected_Srv               303
#define IDS_Send_Rq                     304
#define IDS_Sent_Rq                     305
#define IDS_Rcv_Rsp                     306
#define IDS_Closing_Con                 307
#define IDS_Con_Closed                  308
#define IDS_Req_Complete                309
#define IDS_NoServerSpecified           310
#define IDS_FindingFiles                315
#define IDS_FindDone                    316
#define IDS_NotConnected                317
#define IDS_AlreadyConnected            318
#define IDS_Unknown                     320
#define IDS_MustEnterText               321
#define IDS_AddDir                      322
#define IDS_DelDir                      323
#define IDS_RenFile                     324
#define IDS_UpLdFile                    325
#define IDS_DwnLdFile                   326
#define IDS_DelFile                     327
#define IDS_FailedGetFile               328
#define IDS_GettingFile                 329
#define IDS_GotFile                     330
#define IDS_FileErr                     331
#define IDS_FileOpenFailed              332
#define IDS_PutingFile                  333
#define IDS_SentFile                    334
#define IDS_Column1                     350
#define IDS_Column2                     351
#define IDS_Column3                     352
#define IDS_DisConnectBtn               360
#define IDS_ConnectBtn                  361
#define IDS_AddDlgTitle                 370
#define IDS_AddDlgStaticText            371
#define IDS_LoginInfo                   372
#define IDS_UsrName                     373
#define IDS_RenFileTitle                374
#define IDS_RenFileStaticText           375
#define IDS_FailedCreateDir             380
#define IDS_FailedDeleteDir             381
#define IDS_FailedDeleteFile            382
#define IDS_RemoteFileDlgGetTitle       800
#define IDS_RemoteFileDlgPutTitle       801
#define IDS_FileRcvFormat               802
#define IDS_FilePutFormat               803
#define IDS_FileTransError              804
#define IDS_FailedSession               900
#define IDS_FailedConnect               901
#define IDS_SwictDirFailed              902
#define IDC_Con_Srv                     1000
#define IDC_Connect                     1001
#define IDC_DirList                     1002
#define IDC_FileList                    1003
#define IDC_StatusBar                   1004
#define IDC_DirNow                      1007
#define IDC_AddDir                      1008
#define IDC_DelDir                      1009
#define IDC_StatisText                  1009
#define IDC_InfoCtrl                    1010
#define IDC_RenFile                     1010
#define IDC_DelFile                     1011
#define IDC_PasswordCtrl                1011
#define IDC_DwnLdFile                   1012
#define IDC_UpLdFile                    1013
#define IDC_Anonymous                   1014
#define IDC_Prompt                      1015
#define IDC_PwdSTATIC                   1016
#define IDC_PROGRESS1                   1017
#define IDC_FileName                    1018
#define IDC_RcvSntBytes                 1019

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        139
#define _APS_NEXT_COMMAND_VALUE         32771
#define _APS_NEXT_CONTROL_VALUE         1021
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
