#ifndef __CDBGOUTPUT__
#define __CDBGOUTPUT__

#ifndef _FSTREAM_
#include <fstream>
using namespace std;
#endif

#ifndef _INC_TCHAR
#include <tchar.h>
#endif

// Define used to determine if class is imported or exported
#ifdef DBGOUTPUT_EXPORTS
#define Export_DBGOUTPUT __declspec(dllexport)
#else
#define Export_DBGOUTPUT __declspec(dllimport)
#endif // DBGOUTPUT_EXPORTS

// Crtical section class
class Export_DBGOUTPUT CCritSection
{
    CRITICAL_SECTION m_sSect;
public:
    CCritSection(){InitializeCriticalSection(&m_sSect);}
    operator LPCRITICAL_SECTION(){return &m_sSect;}
};

class Export_DBGOUTPUT CDbgOutput
{
private:
    // Syncronization objects
    static CCritSection m_cConOut;
    static CCritSection m_cDbgOut;
    HANDLE m_hFileMutex;
    // Varibles used to determine what kind of output to use
    bool m_bFile;       // File output
    bool m_bDebugger;   // Use DebugOutput
    bool m_bConsole;    // Output to a console window
    // Used for file output
	ofstream *m_cOutFile;
    // Used for console output
    HANDLE    m_hStdOut;
    // Used to store the title of the console window, only used
    // if we create the console
    TCHAR* m_szConTitle;
protected:
    // Output functions
	inline void DoConsoleOutput(const TCHAR*);
	inline void DoDebugOutput(const TCHAR*);
	inline void DoFileOutput(const TCHAR*);
public:
    // Default CTOR uses environment vars to determine use
    CDbgOutput(TCHAR* EnvVar = NULL, TCHAR* DbgFileEnvVar = NULL, TCHAR* ConsoleTitle = NULL);
    // Specialized CTOR
    CDbgOutput(bool file, TCHAR* outFile = NULL, bool debugger=false, bool console=false);
    // DTOR
    ~CDbgOutput();
    // See if fileout is setup
    bool CanDoFileOutput(){return m_bFile;}
    // See if debugger output is setup
    bool CanDoDebugOutput(){return m_bDebugger;}
    // see if Console output is setup
    bool CanDoConsoleOutput(){return m_bConsole;}
    // returns true if the class is setup to be used, false otherwise
    bool IsValid();
public:
    // Output functions
    void DoOutput(const TCHAR* output);
    CDbgOutput& operator <<(const TCHAR *output);
    CDbgOutput& operator <<(TCHAR output);
    CDbgOutput& operator <<(double val);
    CDbgOutput& operator <<(int val);
	CDbgOutput& operator <<(unsigned int val);
    CDbgOutput& operator <<(long val);
	CDbgOutput& operator <<(unsigned long val);
	void PrintCurTime();
};

#endif // __CDBGOUTPUT__