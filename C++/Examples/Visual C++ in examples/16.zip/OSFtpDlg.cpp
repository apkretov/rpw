// OSFtpDlg.cpp : implementation file
//

#include "stdafx.h"
#include "OSFtp.h"
#include "OSFtpDlg.h"
#include "GetStringDlg.h"
#include "RemoteFileDlg.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CAboutDlg dialog used for App About

class CAboutDlg : public CDialog
{
public:
	CAboutDlg();

// Dialog Data
	//{{AFX_DATA(CAboutDlg)
	enum { IDD = IDD_ABOUTBOX };
	//}}AFX_DATA

	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CAboutDlg)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:
	//{{AFX_MSG(CAboutDlg)
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

CAboutDlg::CAboutDlg() : CDialog(CAboutDlg::IDD)
{
	//{{AFX_DATA_INIT(CAboutDlg)
	//}}AFX_DATA_INIT
}

void CAboutDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CAboutDlg)
	//}}AFX_DATA_MAP
}

BEGIN_MESSAGE_MAP(CAboutDlg, CDialog)
	//{{AFX_MSG_MAP(CAboutDlg)
		// No message handlers
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// COSFtpDlg dialog

COSFtpDlg::COSFtpDlg(CWnd* pParent /*=NULL*/)
	: CDialog(COSFtpDlg::IDD, pParent)
{
	//{{AFX_DATA_INIT(COSFtpDlg)
	m_sConSrv = _T("");
	m_sStatusBar = _T("");
	m_sDirNowText = _T("");
	m_iAnonorPrompt = 0;
	//}}AFX_DATA_INIT
	// Note that LoadIcon does not require a subsequent DestroyIcon in Win32
	m_hIcon = AfxGetApp()->LoadIcon(IDR_MAINFRAME);
	m_sUsrName = _T("Anonymous");
	m_sPwd = _T("here@there.com");
	m_pInetSession = NULL;
	m_pFtpCon = NULL;
	m_bConnected = false;
	
	// Set the status bar variable to a default setting
	m_sStatusBar.LoadString(IDS_NotConnected);
	// Load the images we need
	m_gAddDir.LoadBitmap(IDB_Add);
	m_gDelDir.LoadBitmap(IDB_Delete);
	m_gRenFile.LoadBitmap(IDB_RenFile);
	m_gDelFile.LoadBitmap(IDB_DelFile);
	m_gDwnLdFile.LoadBitmap(IDB_DwnLdFile);
	m_gUpLdFile.LoadBitmap(IDB_UpLdFile);
}

COSFtpDlg::~COSFtpDlg()
{
	if (m_pFtpCon != NULL)
	{
		m_pFtpCon->Close();
		delete m_pFtpCon;
	}
	if (m_pInetSession != NULL)
	{
		m_pInetSession->Close();
		delete m_pInetSession;
	}
}

bool COSFtpDlg::GetSaveInfo(CString& fileData, LPCTSTR saveName /*= NULL */)
{
	// ask where we should put the downloaded file
	CFileDialog dlg(FALSE, NULL, saveName, OFN_HIDEREADONLY|OFN_OVERWRITEPROMPT|OFN_PATHMUSTEXIST,
					NULL, this);
	if (dlg.DoModal() == IDOK)
	{
		fileData = dlg.GetPathName();
		return true;
	}

	return false;
}


bool COSFtpDlg::GetPutInfo(CString& fileData)
{
	// What file are we uploading
	CFileDialog dlg(TRUE, NULL, NULL, OFN_FILEMUSTEXIST|OFN_HIDEREADONLY|
					OFN_PATHMUSTEXIST,_T("All Files (*.*)|*.*||"), this);
	if (dlg.DoModal() == IDOK)
	{
		fileData = dlg.GetPathName();
		return true;
	}

	return false;
}

bool COSFtpDlg::SetupListCtrl()
{
	//setup 3 columns
	LV_COLUMN Columns[3];
	
	CString Heading;
	TCHAR* Column1;
	TCHAR* Column2;
	TCHAR* Column3;
	// get column heading 1
	Heading.LoadString(IDS_Column1);
	// Get the column headings from the resource file
	Column1 = new TCHAR[Heading.GetLength()+1];
	lstrcpy(Column1,Heading);
	Heading.Empty();
	// get column heading 2
	Heading.LoadString(IDS_Column2);
	// Get the column headings from the resource file
	Column2 = new TCHAR[Heading.GetLength()+1];
	lstrcpy(Column2,Heading);
	Heading.Empty();
	// get column heading 3
	Heading.LoadString(IDS_Column3);
	Column3 = new TCHAR[Heading.GetLength()+1];
	lstrcpy(Column3,Heading);
	Heading.Empty();
	
	//First column 
	Columns[0].mask=LVCF_FMT|LVCF_WIDTH|LVCF_TEXT;
	Columns[0].fmt= LVCFMT_CENTER;
	Columns[0].pszText = Column1;
	Columns[0].cchTextMax=lstrlen(Column1);
	Columns[0].cx=110;

	//Second column
	Columns[1].mask=LVCF_FMT|LVCF_WIDTH|LVCF_TEXT;
	Columns[1].fmt= LVCFMT_LEFT;
	Columns[1].pszText = Column2;
	Columns[1].cchTextMax=lstrlen(Column2);
	Columns[1].cx=115;

	//Third Column
	Columns[2].mask=LVCF_FMT|LVCF_WIDTH|LVCF_TEXT;
	Columns[2].fmt= LVCFMT_LEFT;
	Columns[2].pszText = Column3;
	Columns[2].cchTextMax=lstrlen(Column3);
	Columns[2].cx=75;

	//insert columns into the list control
	int col1 = m_cFileList.InsertColumn(0,&Columns[0]);
	int col2 = m_cFileList.InsertColumn(1,&Columns[1]);
	int col3 = m_cFileList.InsertColumn(2,&Columns[2]);

	// free allocated memory
	delete [] Column1;
	delete [] Column2;
	delete [] Column3;

	// verify everything worked
	if (col1 == -1 || col2 == -1 || col3 == -1)
	{
		TRACE3(_T("Column insertion failed\n\tcol1 = %d, col2 = %d, col3=%d\n"), col1, col2, col3);
		return false;
	}

		return true;
}

bool COSFtpDlg::FillListCtrl(CFtpFileFind &fileFind, int index)
{
	// Local Vars
	int ActualItem; 
	DWORD size = 0;
	TCHAR* fileData = NULL;
	CString tmp;
	SYSTEMTIME sysTime;
	CTime timeStamp;

	// iterate the 3 columns of the list control
	for (int x=0; x<3; x++) 
	{
		// Structure used by List Control
		LV_ITEM Item;
		// Mask is always text
		Item.mask=LVIF_TEXT;
		// If this is the first column then set the item to be the
		// row we think it should be put, if it is a different column
		// then use the actual row index which is obtained after adding the row
		Item.iItem= (x == 0)?index:ActualItem;
		// Column we are working on
		Item.iSubItem = x;
		// decide what value to place in the column
		switch(x)
		{
		// Display filename
		case 0:
			tmp = fileFind.GetFileName();
			// Allocate a buffer to hold a copy of the string
			fileData = new TCHAR[tmp.GetLength()+1];
			// copy the string
			lstrcpy(fileData, tmp);
			// store the pointer for the listctrl to use
			Item.pszText= fileData;
			// tell the listctrl the length of the string
			Item.cchTextMax=lstrlen(fileData);
			break;
		// display file size
		case 1:
			// Get the size, devide by 1024 to get the KB
			size = fileFind.GetLength()/1024;
			// Make it look pretty
			fileData = new TCHAR[257];
			// Display KiloBytes, if the size is 0, display 1KB
			wsprintf(fileData,"%u KB", (size == 0)?1:size);
			// store the string pointer in the listctrl
			Item.pszText= fileData;
			// tell the listctrl the size of the string
			Item.cchTextMax=lstrlen(fileData);
			break;
		// display file date
		case 2:
			// get the last write time
			fileFind.GetLastWriteTime(timeStamp);
			// Translate that to a local system time
			timeStamp.GetAsSystemTime(sysTime);
			// put the local file time into the CTime object for formatting
			timeStamp = sysTime;
			// format the file time in a locale specific way
			tmp= timeStamp.Format("%x");
			// Copy the data into an allocated string
			fileData = new TCHAR[tmp.GetLength()+1];
			lstrcpy(fileData, tmp);
			// copy the string to the listctrl
			Item.pszText= fileData;
			// tell the listctrl how big the string is
			Item.cchTextMax=lstrlen(fileData);
			break;
		}

		// insert the item if needed, otherwise set the items value
		if (x == 0)
			// Get the actual row # the item was put into
			ActualItem = m_cFileList.InsertItem(&Item);
		else
			m_cFileList.SetItem(&Item);// Set the column data per above

		// release allocated data
		if (fileData != NULL)
		{
			delete [] fileData;
			fileData = NULL;
		}
	}
	return true;
}

bool COSFtpDlg::GetSelectedItem(CString& SelText)
{
	bool bFound = false;

	int Index = m_cFileList.GetTopIndex();
    int last_visible_index = Index + m_cFileList.GetCountPerPage();
    if (last_visible_index > m_cFileList.GetItemCount())
        last_visible_index = m_cFileList.GetItemCount();

    // Loop until number visible items has been reached.
    while (Index <= last_visible_index)
    {
		UINT nState = m_cFileList.GetItemState(Index, LVIS_SELECTED);

		if (nState)
		{
			//This is the selected item
			SelText = m_cFileList.GetItemText(Index, 0);
			bFound = true;
			break;
		}
	        // Get the next item in listview control.
        Index++;
    }
	return bFound;
}

bool COSFtpDlg::CreateInetSession()
{
	// Create an internet session if needed
	if (m_pInetSession == NULL)
	{
		CWaitCursor waitCur;
		try
		{
			// Use the defaults
			m_pInetSession = new CInternetSession(NULL, 1, INTERNET_OPEN_TYPE_PRECONFIG,NULL, NULL, 0);
			waitCur.Restore();
		}
		catch(CInternetException* e)
		{
			CString errString;
			TCHAR err[513];
			e->GetErrorMessage(err, 513);
			e->Delete();
			
			TRACE1(_T("An exception occurred while creating the session object\n\t%s"), err);
			
			errString.Format(IDS_FailedSession, err);
			AfxMessageBox(errString);
			waitCur.Restore();
			return false;
		}
	}
	return true;
}

bool COSFtpDlg::GetFTPConnection()
{
	// Do we have an Internet Session
	if (m_pInetSession == NULL)
		if (CreateInetSession() == false)
			return false;

	CWaitCursor waitCur;

	// Close active ftp connection, if needed
	if (m_pFtpCon != NULL)
	{
		// this should never happen, but....
		if (m_pFtpCon->GetServerName() == m_sConSrv)
		{
			CString msg;
			msg.Format(IDS_AlreadyConnected, (LPCTSTR)m_sConSrv);
			AfxMessageBox(msg);
			return true;
		}
		else
		{
			m_pFtpCon->Close();
			delete m_pFtpCon;
			m_pFtpCon = NULL;
		}
	}

	// Get an FTP connection from the Internet Session
	try
	{
		m_pFtpCon = m_pInetSession->GetFtpConnection(m_sConSrv, m_sUsrName, m_sPwd, INTERNET_DEFAULT_FTP_PORT);
		waitCur.Restore();
	}
	catch(CInternetException* e)
	{
		CString errString;
		TCHAR err[513];
		e->GetErrorMessage(err, 513);
		e->Delete();

		TRACE1(_T("An exception occurred while creating the FTP Connection object\n\t%s"), err);
		
		errString.Format(IDS_FailedConnect, err);
		AfxMessageBox(errString);
		waitCur.Restore();
		return false;
	}
	return true;
}

void COSFtpDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(COSFtpDlg)
	DDX_Control(pDX, IDC_FileList, m_cFileList);
	DDX_Control(pDX, IDC_DirList, m_cDirList);
	DDX_Text(pDX, IDC_Con_Srv, m_sConSrv);
	DDX_Text(pDX, IDC_StatusBar, m_sStatusBar);
	DDX_Text(pDX, IDC_DirNow, m_sDirNowText);
	DDX_Radio(pDX, IDC_Anonymous, m_iAnonorPrompt);
	//}}AFX_DATA_MAP
}

BEGIN_MESSAGE_MAP(COSFtpDlg, CDialog)
	//{{AFX_MSG_MAP(COSFtpDlg)
	ON_WM_SYSCOMMAND()
	ON_WM_PAINT()
	ON_WM_QUERYDRAGICON()
	ON_BN_CLICKED(IDC_Connect, OnConnectBtn)
	ON_LBN_DBLCLK(IDC_DirList, OnDblclkDirList)
	ON_BN_CLICKED(IDC_AddDir, OnAddDir)
	ON_BN_CLICKED(IDC_DelDir, OnDelDir)
	ON_NOTIFY(NM_DBLCLK, IDC_FileList, OnDblclkFileList)
	ON_BN_CLICKED(IDC_DwnLdFile, OnDwnLdFile)
	ON_BN_CLICKED(IDC_UpLdFile, OnUpLdFile)
	ON_BN_CLICKED(IDC_DelFile, OnDelFile)
	ON_MESSAGE(WM_DoFind, OnDoFind)
	ON_BN_CLICKED(IDC_RenFile, OnRenFile)
	//}}AFX_MSG_MAP
	ON_NOTIFY_EX( TTN_NEEDTEXT, 0, OnNeedToolTip )
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// COSFtpDlg message handlers

// We get this message so we can provide a tooltip window for the buttons on the dialog
BOOL COSFtpDlg::OnNeedToolTip(UINT id, NMHDR * pTTTStruct, LRESULT * pResult)
{
	TOOLTIPTEXT *pTTT = (TOOLTIPTEXT *)pTTTStruct;
	CString TipText;

	switch (::GetDlgCtrlID((HWND)pTTTStruct->idFrom))
	{
	case IDC_AddDir:
		TipText.LoadString(IDS_AddDir);
		lstrcpy(pTTT->szText,TipText);
        pTTT->hinst = NULL;
		return TRUE;
		break;
	case IDC_DelDir:
		TipText.LoadString(IDS_DelDir);
		lstrcpy(pTTT->szText,TipText);
        pTTT->hinst = NULL;
		return TRUE;
		break;
	case IDC_RenFile:
		TipText.LoadString(IDS_RenFile);
		lstrcpy(pTTT->szText,TipText);
        pTTT->hinst = NULL;
		return TRUE;
		break;
	case IDC_DelFile:
		TipText.LoadString(IDS_DelFile);
		lstrcpy(pTTT->szText,TipText);
        pTTT->hinst = NULL;
		return TRUE;
		break;
	case IDC_DwnLdFile:
		TipText.LoadString(IDS_DwnLdFile);
		lstrcpy(pTTT->szText,TipText);
        pTTT->hinst = NULL;
		return TRUE;
		break;
	case IDC_UpLdFile:
		TipText.LoadString(IDS_UpLdFile);
		lstrcpy(pTTT->szText,TipText);
        pTTT->hinst = NULL;
		return TRUE;
		break;

	}
	return FALSE;
}

BOOL COSFtpDlg::OnInitDialog()
{
	CDialog::OnInitDialog();
	EnableToolTips();

	// Set the images on the buttons
	CButton* btn = static_cast<CButton*>(GetDlgItem(IDC_AddDir));
	btn->SetBitmap(m_gAddDir);
	btn = static_cast<CButton*>(GetDlgItem(IDC_DelDir));
	btn->SetBitmap(m_gDelDir);
	btn = static_cast<CButton*>(GetDlgItem(IDC_RenFile));
	btn->SetBitmap(m_gRenFile);
	btn = static_cast<CButton*>(GetDlgItem(IDC_DelFile));
	btn->SetBitmap(m_gDelFile);
	btn = static_cast<CButton*>(GetDlgItem(IDC_DwnLdFile));
	btn->SetBitmap(m_gDwnLdFile);
	btn = static_cast<CButton*>(GetDlgItem(IDC_UpLdFile));
	btn->SetBitmap(m_gUpLdFile);

	// Add "About..." menu item to system menu.
	// IDM_ABOUTBOX must be in the system command range.
	ASSERT((IDM_ABOUTBOX & 0xFFF0) == IDM_ABOUTBOX);
	ASSERT(IDM_ABOUTBOX < 0xF000);

	CMenu* pSysMenu = GetSystemMenu(FALSE);
	if (pSysMenu != NULL)
	{
		CString strAboutMenu;
		strAboutMenu.LoadString(IDS_ABOUTBOX);
		if (!strAboutMenu.IsEmpty())
		{
			pSysMenu->AppendMenu(MF_SEPARATOR);
			pSysMenu->AppendMenu(MF_STRING, IDM_ABOUTBOX, strAboutMenu);
		}
	}

	// Set the icon for this dialog.  The framework does this automatically
	//  when the application's main window is not a dialog
	SetIcon(m_hIcon, TRUE);			// Set big icon
	SetIcon(m_hIcon, FALSE);		// Set small icon
	
	// Set the list control up
	SetupListCtrl();
	
	return TRUE;  // return TRUE  unless you set the focus to a control
}

void COSFtpDlg::OnSysCommand(UINT nID, LPARAM lParam)
{
	if ((nID & 0xFFF0) == IDM_ABOUTBOX)
	{
		CAboutDlg dlgAbout;
		dlgAbout.DoModal();
	}
	else
	{
		CDialog::OnSysCommand(nID, lParam);
	}
}

// If you add a minimize button to your dialog, you will need the code below
//  to draw the icon.  For MFC applications using the document/view model,
//  this is automatically done for you by the framework.

void COSFtpDlg::OnPaint() 
{
	if (IsIconic())
	{
		CPaintDC dc(this); // device context for painting

		SendMessage(WM_ICONERASEBKGND, (WPARAM) dc.GetSafeHdc(), 0);

		// Center icon in client rectangle
		int cxIcon = GetSystemMetrics(SM_CXICON);
		int cyIcon = GetSystemMetrics(SM_CYICON);
		CRect rect;
		GetClientRect(&rect);
		int x = (rect.Width() - cxIcon + 1) / 2;
		int y = (rect.Height() - cyIcon + 1) / 2;

		// Draw the icon
		dc.DrawIcon(x, y, m_hIcon);
	}
	else
	{
		CDialog::OnPaint();
	}
}

// The system calls this to obtain the cursor to display while the user drags
//  the minimized window.
HCURSOR COSFtpDlg::OnQueryDragIcon()
{
	return (HCURSOR) m_hIcon;
}

void COSFtpDlg::OnOK() 
{
	OnConnectBtn();
}

void COSFtpDlg::OnConnectBtn() 
{
	if (m_bConnected == false)
		OnConnect();
	else
		OnDisconnect();
}

void COSFtpDlg::OnConnect()
{
	CWaitCursor wait;
	UpdateData();

	// Make sure we have a server name
	if (m_sConSrv.IsEmpty() || m_sConSrv == " ")
	{
		AfxMessageBox(IDS_NoServerSpecified);
		return;
	}

	// Connect as Anonymous?
	if (m_iAnonorPrompt == 0)
	{
		// Connect anonymously
		m_sUsrName = _T("anonymous");
		m_sPwd = _T("here@there.com");
	}
	else
	{
		// Get user data
		CGetStringDlg dlg(IDS_LoginInfo, IDS_UsrName, this, true);
		dlg.SetString(m_sUsrName);
		dlg.SetPwdString(m_sPwd);

		if (dlg.DoModal() == IDOK)
		{
			m_sPwd = dlg.GetPwdString();
			m_sUsrName = dlg.GetString();
		}
		else
			return;
	}

	CButton* connectBtn = static_cast<CButton*>(GetDlgItem(IDC_Connect));
	CStatic* statusBar = static_cast<CStatic*>(GetDlgItem(IDC_StatusBar));
	// Set the status bar
	m_sStatusBar.Format(IDS_Connecting_Srv, (LPCTSTR)m_sConSrv);
	statusBar->SetWindowText(m_sStatusBar);
	statusBar->UpdateWindow();
	// Disable the connect button
	connectBtn->EnableWindow(FALSE);
	// Disable the Server edit box
	GetDlgItem(IDC_Con_Srv)->EnableWindow(FALSE);

	if (CreateInetSession() == false)
	{
		// Enable the connect button
		connectBtn->EnableWindow();
		// Enable the server edit box
		GetDlgItem(IDC_Con_Srv)->EnableWindow();
		// Update the status bar
		m_sStatusBar.Format(IDS_FailedSession, (LPCTSTR)m_sConSrv);
		statusBar->SetWindowText(m_sStatusBar);
		statusBar->UpdateWindow();
		return;
	}

	// disable the window to the user can't exit until getftpconnection returns
	EnableWindow(FALSE);
	wait.Restore();
	// connect to the server
	bool bResult = GetFTPConnection();
	// reenable the window
	EnableWindow();
	if (bResult == false)
	{
		// Enable the connect button
		connectBtn->EnableWindow();
		// Enable the server edit box
		GetDlgItem(IDC_Con_Srv)->EnableWindow();
		// Update the status bar
		m_sStatusBar.Format(IDS_FailedConnect, (LPCTSTR)m_sConSrv);
		statusBar->SetWindowText(m_sStatusBar);
		statusBar->UpdateWindow();
		return;
	}
	
	wait.Restore();	
	
	// Set the button text
	CString newText;
	newText.LoadString(IDS_DisConnectBtn); //IDS_ConnectBtn
	connectBtn->SetWindowText(newText);
	// Enable the connect button
	connectBtn->EnableWindow();

	m_bConnected = true;
	TRACE("Connected!\n");

	// Set the status bar
	m_sStatusBar.Format(IDS_Connected_Srv, (LPCTSTR)m_sConSrv);
	GetDlgItem(IDC_StatusBar)->SetWindowText(m_sStatusBar);
	GetDlgItem(IDC_StatusBar)->UpdateWindow();

	// Send a message to start the file find
	PostMessage(WM_DoFind);
}

void COSFtpDlg::OnDisconnect()
{
	// Close active ftp connection
	if (m_pFtpCon != NULL)
	{
		m_pFtpCon->Close();
		delete m_pFtpCon;
		m_pFtpCon = NULL;
	}
	
	m_bConnected = false;

	// Set the button text
	CString newText;
	newText.LoadString(IDS_ConnectBtn);
	GetDlgItem(IDC_Connect)->SetWindowText(newText);
	// Clear the current directory info
	m_sDirNowText = _T("");
	// Set the status bar
	m_sStatusBar.LoadString(IDS_NotConnected);

	// Clear the list box and list control
	m_cDirList.ResetContent();
	m_cFileList.DeleteAllItems();

	// Enable the server edit box
	GetDlgItem(IDC_Con_Srv)->EnableWindow();

	UpdateData(FALSE);
}

LRESULT COSFtpDlg::OnDoFind(WPARAM, LPARAM)
{
	// Search teh current directory for all files
	CWaitCursor waitCur;
	int index = 0;

	// Clear the list box and list control
	m_cDirList.ResetContent();
	m_cFileList.DeleteAllItems();
	
		// Set the status bar
	m_sStatusBar.LoadString(IDS_FindingFiles);
	GetDlgItem(IDC_StatusBar)->SetWindowText(m_sStatusBar);
	GetDlgItem(IDC_StatusBar)->UpdateWindow();
	
	waitCur.Restore();
	
	// Create a file find object
	CFtpFileFind FtpFileFind(m_pFtpCon);
      
	// Start the find process looking for all files
	BOOL Status= FtpFileFind.FindFile("*", INTERNET_FLAG_RAW_DATA);
 
	// Loop on all files 
	while (Status) 
	{
		// Must call FindNext before gathering file data
		Status = FtpFileFind.FindNextFile();
		
		// get the file name
		CString fileName = FtpFileFind.GetFileName();
		TRACE1("Filename - %s\n", (LPCTSTR)fileName);
		
		// is it a directory
		if (FtpFileFind.IsDirectory() == TRUE)
		{
			// Do not display the "." directory
			if (fileName != ".")
				m_cDirList.AddString(fileName);
		}
		else // Must be a file
		{
			FillListCtrl(FtpFileFind, index++);
		}
		waitCur.Restore();
	}
	// Get the current files directory because getCurrentDirectory below causes an exception
	m_sDirNowText = FtpFileFind.GetRoot();
	FtpFileFind.Close();

	// Display the current directory name
	//m_pFtpCon->GetCurrentDirectory(m_sCurrentDir); // caused a big boom??!!

	// Make sure the ListBox displays the ".." so we can get to the parent directory
	if (m_cDirList.FindStringExact(0,_T("..")) == LB_ERR)
		m_cDirList.AddString(_T(".."));
	
	// Update the status bar
	m_sStatusBar.LoadString(IDS_FindDone);
	// need this sleep so that m_sDirNowText is properly updated -> don't know why??
	Sleep(250);
	UpdateData(FALSE);
	return 0L;
}

void COSFtpDlg::OnDblclkDirList() 
{
	// user double clicked a directory so we need to iterate the files in it
	CWaitCursor waitCur;

	int curSel = m_cDirList.GetCurSel();
	CString curDir;

	m_cDirList.GetText(curSel, curDir);

	// if we can enter this directory send a message to start locating files
	if (m_pFtpCon->SetCurrentDirectory(curDir) == 1)
		// Send a message to start the file find
		PostMessage(WM_DoFind);
	else
	{
		// Couldn't enter directory - display error
		CString errText, displayMsg;
		errText = GetSystemErrorText(GetLastError());
		displayMsg.Format(IDS_SwictDirFailed, (LPCTSTR)errText);
		AfxMessageBox(displayMsg);
	}
}

void COSFtpDlg::OnAddDir() 
{
	if (!m_bConnected)
	{
		return;
	}
	
	// dialog to get the new directory name
	CGetStringDlg dlg(IDS_AddDlgTitle, IDS_AddDlgStaticText, this);

	// Display the dialog
	if (dlg.DoModal() == IDOK)
	{
		// User clicked OK
		CWaitCursor wait;
		// Try to create the directory
		if (m_pFtpCon->CreateDirectory(dlg.GetString()) == FALSE)
		{
			// Error - display error message
			DWORD errNum = GetLastError();
			CString errText(GetSystemErrorText(errNum));

			CString msg;
			msg.Format(IDS_FailedCreateDir, (LPCTSTR)errText);
			AfxMessageBox(msg,MB_OK|MB_ICONERROR);
		}
		else
		{
			// Directory created - add the directory name to the listbox
			m_cDirList.AddString(dlg.GetString());
		}
	}
}

void COSFtpDlg::OnDelDir() 
{
	if (!m_bConnected)
	{
		return;
	}
	
	CWaitCursor wait;
	CString Dir2Del;

	// Get the index of the currently selected item in the dir listbox
	int index = m_cDirList.GetCurSel();
	// verify something is selected, Very unlikely, but...
	if (index == LB_ERR)
	{
		TRACE(_T("Directory Listbox indicates nothing is selected - aborting the delete"));
		return;
	}

	// Get the text of the selected item
	m_cDirList.GetText(index, Dir2Del);

	// Try to remove the directory
	if (m_pFtpCon->RemoveDirectory(Dir2Del) == FALSE)
	{
		// Error - display error message
		DWORD errNum = GetLastError();
		CString errText(GetSystemErrorText(errNum));

		CString msg;
		msg.Format(IDS_FailedDeleteDir, (LPCTSTR)errText);
		AfxMessageBox(msg,MB_OK|MB_ICONERROR);
	}
	else
	{
		// Dir deleted - remove dir string from dir list box
		m_cDirList.DeleteString(index);
	}
}

void COSFtpDlg::OnDelFile() 
{
	// Make sure we are connected
	if (!m_bConnected)
	{
		return;
	}

	CWaitCursor wait;
	CString fileToDel;

	if (GetSelectedItem(fileToDel))
	{
		if (m_pFtpCon->Remove(fileToDel))
			PostMessage(WM_DoFind);
		else
		{
			// Error Deleting file
			DWORD errNum = GetLastError();
			CString errText(GetSystemErrorText(errNum));

			CString msg;
			msg.Format(IDS_FailedDeleteFile, (LPCTSTR)errText);
			AfxMessageBox(msg,MB_OK|MB_ICONERROR);
		}
	}
}

void COSFtpDlg::OnRenFile() 
{
	// Make sure we are connected
	if (!m_bConnected)
	{
		return;
	}

	CWaitCursor wait;
	CString fileToRen;

	if (GetSelectedItem(fileToRen))
	{
		// dialog to get the file name
		CGetStringDlg dlg(IDS_RenFileTitle, IDS_RenFileStaticText, this);

		// Display the dialog
		if (dlg.DoModal() == IDOK)
		{
			wait.Restore();

			if (m_pFtpCon->Rename(fileToRen, dlg.GetString()))
				PostMessage(WM_DoFind);
			else
			{
				// Error Deleting file
				DWORD errNum = GetLastError();
				CString errText(GetSystemErrorText(errNum));

				CString msg;
				msg.Format(IDS_FailedDeleteFile, (LPCTSTR)errText);
				AfxMessageBox(msg,MB_OK|MB_ICONERROR);
			}
		}
	}
}

void COSFtpDlg::OnDblclkFileList(NMHDR* pNMHDR, LRESULT* pResult) 
{
	// Make sure we are connected
	if (!m_bConnected)
	{
		return;
	}
	// determine what was double clicked
	UINT nFlags = LVHT_ONITEM;
	CPoint mousePos(::GetMessagePos());
	m_cFileList.ScreenToClient(&mousePos);
	int nItem = m_cFileList.HitTest(mousePos, &nFlags);

	if (nItem != -1)
	{
		// item selected
		GetFile2(m_cFileList.GetItemText(nItem, 0));
	}
	
	*pResult = 0;
}

void COSFtpDlg::OnDwnLdFile() 
{
	// Make sure we are connected
	if (!m_bConnected)
	{
		return;
	}

	CString fileToGet;
	
	// Determine Which file is selected
	if (GetSelectedItem(fileToGet))
		GetFile2(fileToGet);
}

void COSFtpDlg::OnUpLdFile() 
{

	// Make sure we are connected
	if (!m_bConnected)
		return;
	else
		PutFile2();
}

bool COSFtpDlg::GetFile(LPCTSTR fileName)
{
	// Obsolete - see GetFile2
	// I left this here to show the code
	CString PathInfo;
	if (GetSaveInfo(PathInfo, fileName))
	{
		// get the file
		CWaitCursor wait;
		m_sStatusBar.LoadString(IDS_GettingFile);
		GetDlgItem(IDC_StatusBar)->SetWindowText(m_sStatusBar);
		GetDlgItem(IDC_StatusBar)->UpdateWindow();
		UpdateWindow();

		// Get the file
		if (m_pFtpCon->GetFile(fileName, PathInfo, FALSE) == FALSE)
		{
			// get file failed
			DWORD errNum = GetLastError();
			CString msg;
			msg.Format(IDS_FailedGetFile, (LPCSTR)fileName, (LPCTSTR)GetSystemErrorText(errNum));
			AfxMessageBox(msg,MB_OK|MB_ICONERROR);
			return false;
		}
		
		m_sStatusBar.LoadString(IDS_GotFile);
		GetDlgItem(IDC_StatusBar)->SetWindowText(m_sStatusBar);
		GetDlgItem(IDC_StatusBar)->UpdateWindow();
		MessageBeep(MB_OK);
		return true;
	}
	return false;
}

bool COSFtpDlg::GetFile2(LPCTSTR fileName)
{
	CString PathInfo;

	// Update the "Status Bar"
	m_sStatusBar.LoadString(IDS_GettingFile);
	GetDlgItem(IDC_StatusBar)->SetWindowText(m_sStatusBar);

	// Display a wait cursor
	CWaitCursor wait;
	if (GetSaveInfo(PathInfo, fileName))
	{
		// User provided a place to store the file so lets get it
		CInternetFile* remoteFile = NULL;
		CFile* outFile = NULL;

		// force the window to repaint
		UpdateWindow();
		// restore the wait cursor
		wait.Restore();		
		try
		{
			// create the local file
			outFile = new CFile(PathInfo, CFile::modeCreate|CFile::modeWrite|CFile::shareDenyWrite);
			// get a "handle" to the remote file
			remoteFile = m_pFtpCon->OpenFile(fileName);

			// start retrieving the file, the CRemoteFileDlg lets us abort
			// the process if we want
			CRemoteFileDlg fileDlg(*outFile, *remoteFile, this);
			if(fileDlg.DoModal() == IDOK)
			{
				// update the "Status bar" indicating we got the file
				m_sStatusBar.LoadString(IDS_GotFile);
				GetDlgItem(IDC_StatusBar)->SetWindowText(m_sStatusBar);
				GetDlgItem(IDC_StatusBar)->UpdateWindow();
				MessageBeep(MB_OK);
			}
			else
			{
				// Was it canceled or did an error occur
				if (fileDlg.IsError())
				{
					// Error occurred - display message
					CString msg;
					msg.Format(IDS_FileTransError, fileDlg.GetErrorText);
					AfxMessageBox(msg);
				}
				else
					MessageBeep(MB_ICONEXCLAMATION);

				// update the "Statis bar" indicating teh file transfer was interrupted
				m_sStatusBar.LoadString(IDS_FileErr);
				GetDlgItem(IDC_StatusBar)->SetWindowText(m_sStatusBar);
				GetDlgItem(IDC_StatusBar)->UpdateWindow();
			}

			// delete the memory associated with the file
			if (remoteFile != NULL)
			{
				// Close the remote file
				remoteFile->Close();
				delete remoteFile;
				remoteFile = NULL;
			}

			// free allocated memory
			if (outFile != NULL)
			{
				// close the local file
				outFile->Close();
				delete outFile;
				outFile = NULL;
			}
		}
		catch(CException* e)
		{
			TCHAR errTxt[513];
			e->GetErrorMessage(errTxt, 512);
			e->Delete();
			CString msg;
			msg.Format(IDS_FileOpenFailed, errTxt);

			if (remoteFile != NULL)
			{
				// Close the remote file
				// call abort since this is an exception handler
				// and we don't care if an error occurs while closing it
				remoteFile->Abort();
				// free memory associated with it
				delete remoteFile;
				remoteFile = NULL;
			}
			if (outFile != NULL)
			{
				// close the local file.
				// call abort since this is an exception handler
				// and we don't care if an error occurs while closing it
				outFile->Abort();
				// Free allocated memory
				delete outFile;
				outFile = NULL;
			}
			return false;
		}
	}
	else
		// user pressed cancel when selecting a save directory
		return false;

	// If we get here stuff must have gone okay....
	return true;
}

bool COSFtpDlg::PutFile2()
{
	CString localFileName;

	// Update the "Status Bar"
	m_sStatusBar.LoadString(IDS_PutingFile);
	GetDlgItem(IDC_StatusBar)->SetWindowText(m_sStatusBar);

	// Display a wait cursor
	CWaitCursor wait;
	if (GetPutInfo(localFileName))
	{
		// User provided a file to upload the file so lets do it
		CInternetFile* remoteFile = NULL;
		CFile* inFile = NULL;

		// force the window to repaint
		UpdateWindow();
		// restore the wait cursor
		wait.Restore();		
		try
		{
			// Open the local file
			inFile = new CFile(localFileName, CFile::modeRead|CFile::shareDenyWrite);
			// Open the remote file using the same name as teh local file
			remoteFile = m_pFtpCon->OpenFile(inFile->GetFileName(), GENERIC_WRITE);

			// start sending the file, the CRemoteFileDlg lets us abort
			// the process if we want
			CRemoteFileDlg fileDlg(*inFile, *remoteFile, this, false);
			if(fileDlg.DoModal() == IDOK)
			{
				// update the "Status bar" indicating we got the file
				m_sStatusBar.LoadString(IDS_SentFile);
				GetDlgItem(IDC_StatusBar)->SetWindowText(m_sStatusBar);
				GetDlgItem(IDC_StatusBar)->UpdateWindow();
				MessageBeep(MB_OK);
			}
			else
			{
				// Was it canceled or did an error occur
				if (fileDlg.IsError())
				{
					// Error occurred - display message
					CString msg;
					msg.Format(IDS_FileTransError, fileDlg.GetErrorText);
					AfxMessageBox(msg);
				}
				else
					MessageBeep(MB_ICONEXCLAMATION);

				// update the "Statis bar" indicating the file transfer was interrupted
				m_sStatusBar.LoadString(IDS_FileErr);
				GetDlgItem(IDC_StatusBar)->SetWindowText(m_sStatusBar);
				GetDlgItem(IDC_StatusBar)->UpdateWindow();
			}

			// delete the memory associated with the file
			if (remoteFile != NULL)
			{
				// Close the remote file
				remoteFile->Close();
				delete remoteFile;
				remoteFile = NULL;
			}

			// free allocated memory
			if (inFile != NULL)
			{
				// close the local file
				inFile->Close();
				delete inFile;
				inFile = NULL;
			}
		}
		catch(CException* e)
		{
			TCHAR errTxt[513];
			e->GetErrorMessage(errTxt, 512);
			e->Delete();
			CString msg;
			msg.Format(IDS_FileOpenFailed, errTxt);
			AfxMessageBox(msg);

			if (remoteFile != NULL)
			{
				// Close the remote file
				// call abort since this is an exception handler
				// and we don't care if an error occurs while closing it
				remoteFile->Abort();
				// free memory associated with it
				delete remoteFile;
				remoteFile = NULL;
			}
			if (inFile != NULL)
			{
				// close the local file.
				// call abort since this is an exception handler
				// and we don't care if an error occurs while closing it
				inFile->Abort();
				// Free allocated memory
				delete inFile;
				inFile = NULL;
			}
			return false;
		}
	}
	else
		// user pressed cancel when selecting a save directory
		return false;

	// If we get here stuff must have gone okay....
	// update the file list
	PostMessage(WM_DoFind);
	return true;
}
