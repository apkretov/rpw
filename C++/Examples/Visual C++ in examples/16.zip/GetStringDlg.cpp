// GetStringDlg.cpp : implementation file
//

#include "stdafx.h"
#include "OSFtp.h"
#include "GetStringDlg.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CGetStringDlg dialog


CGetStringDlg::CGetStringDlg(UINT ID_Title, UINT ID_StaticText, 
							 CWnd* pParent /*=NULL*/, bool getPwd /* = false*/)
	: m_bGetPwd(getPwd), CDialog(CGetStringDlg::IDD, pParent)
{
	//{{AFX_DATA_INIT(CGetStringDlg)
	m_sStaticText = _T("");
	m_sTitle = _T("");
	m_sPwd = _T("");
	//}}AFX_DATA_INIT
	m_sTitle.LoadString(ID_Title);
	m_sStaticText.LoadString(ID_StaticText);
}


void CGetStringDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CGetStringDlg)
	DDX_Text(pDX, IDC_InfoCtrl, m_sString);
	DDX_Text(pDX, IDC_StatisText, m_sStaticText);
	DDX_Text(pDX, IDC_PasswordCtrl, m_sPwd);
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CGetStringDlg, CDialog)
	//{{AFX_MSG_MAP(CGetStringDlg)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CGetStringDlg message handlers

BOOL CGetStringDlg::OnInitDialog() 
{
	CDialog::OnInitDialog();

	// Enable the password controls if we need to
	if (m_bGetPwd)
	{
		GetDlgItem(IDC_PasswordCtrl)->ShowWindow(SW_SHOW);
		GetDlgItem(IDC_PwdSTATIC)->ShowWindow(SW_SHOW);
	}
	
	SetWindowText(m_sTitle);

	GetDlgItem(IDC_InfoCtrl)->SetFocus();

	return FALSE;  // return TRUE unless you set the focus to a control
}

void CGetStringDlg::OnOK() 
{
	UpdateData();
	
	if (!m_sString.IsEmpty())
		CDialog::OnOK();
	else
		AfxMessageBox(IDS_MustEnterText);
}
