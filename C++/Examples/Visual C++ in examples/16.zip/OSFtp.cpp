// OSFtp.cpp : Defines the class behaviors for the application.
//

#include "stdafx.h"
#include "OSFtp.h"
#include "OSFtpDlg.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// Global Functions
CString GetSystemErrorText(DWORD LastErr)
{
	// A system error occurred, lets display an error message
	// that explains the what happened
	LPVOID lpMsgBuf;

	// return value
	CString errMsg;

	// If this is an extended Error get the error info from the internet functions
	// otherwise get the normal system error
	if (LastErr == ERROR_INTERNET_EXTENDED_ERROR)
	{
		DWORD InetErr=0;
		DWORD stringSize=513;
		TCHAR InetErrText[513];
		if (InternetGetLastResponseInfo(&InetErr, InetErrText, &stringSize) == TRUE)
			errMsg = InetErrText;
		else
			errMsg.LoadString(IDS_Unknown);
	}
	else
	{
		// This function takes the return value from GetLastError and 
		// creates a human readable string which can be displayed via
		// a msgbox this is part of the WIN32 API
		DWORD result = FormatMessage(FORMAT_MESSAGE_ALLOCATE_BUFFER | \
			FORMAT_MESSAGE_FROM_SYSTEM | FORMAT_MESSAGE_FROM_HMODULE,
			GetModuleHandle("wininet.dll"), LastErr, MAKELANGID(LANG_NEUTRAL, SUBLANG_DEFAULT), // Default language
			(LPTSTR) &lpMsgBuf, 0, NULL);

		if (result != 0)
		{
			// Set a local CString to point at the string
			errMsg=((LPCTSTR)lpMsgBuf);
			// FormatMessage allocates a buffer which we must free
			LocalFree( lpMsgBuf );	
		}
		else
			errMsg = _T("");
	}

	return errMsg;
}

/////////////////////////////////////////////////////////////////////////////
// COSFtpApp

BEGIN_MESSAGE_MAP(COSFtpApp, CWinApp)
	//{{AFX_MSG_MAP(COSFtpApp)
		// NOTE - the ClassWizard will add and remove mapping macros here.
		//    DO NOT EDIT what you see in these blocks of generated code!
	//}}AFX_MSG
	ON_COMMAND(ID_HELP, CWinApp::OnHelp)
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// COSFtpApp construction

COSFtpApp::COSFtpApp()
{
	// TODO: add construction code here,
	// Place all significant initialization in InitInstance
}

/////////////////////////////////////////////////////////////////////////////
// The one and only COSFtpApp object

COSFtpApp theApp;

/////////////////////////////////////////////////////////////////////////////
// COSFtpApp initialization

BOOL COSFtpApp::InitInstance()
{
	// Standard initialization
	// If you are not using these features and wish to reduce the size
	//  of your final executable, you should remove from the following
	//  the specific initialization routines you do not need.

#ifdef _AFXDLL
	Enable3dControls();			// Call this when using MFC in a shared DLL
#else
	Enable3dControlsStatic();	// Call this when linking to MFC statically
#endif

	COSFtpDlg dlg;
	m_pMainWnd = &dlg;
	int nResponse = dlg.DoModal();
	if (nResponse == IDOK)
	{
		// TODO: Place code here to handle when the dialog is
		//  dismissed with OK
	}
	else if (nResponse == IDCANCEL)
	{
		// TODO: Place code here to handle when the dialog is
		//  dismissed with Cancel
	}

	// Since the dialog has been closed, return FALSE so that we exit the
	//  application, rather than start the application's message pump.
	return FALSE;
}
