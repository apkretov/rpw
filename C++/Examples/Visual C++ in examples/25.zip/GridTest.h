// GridTest.h : main header file for the GRIDTEST application
//

#if !defined(AFX_GRIDTEST_H__264C0797_437C_11D2_8C55_000000000000__INCLUDED_)
#define AFX_GRIDTEST_H__264C0797_437C_11D2_8C55_000000000000__INCLUDED_

#if _MSC_VER >= 1000
#pragma once
#endif // _MSC_VER >= 1000

#ifndef __AFXWIN_H__
	#error include 'stdafx.h' before including this file for PCH
#endif

#include "resource.h"		// main symbols

/////////////////////////////////////////////////////////////////////////////
// CGridTestApp:
// See GridTest.cpp for the implementation of this class
//

class CGridTestApp : public CWinApp
{
public:
	CGridTestApp();

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CGridTestApp)
	public:
	virtual BOOL InitInstance();
	//}}AFX_VIRTUAL

// Implementation

	//{{AFX_MSG(CGridTestApp)
		// NOTE - the ClassWizard will add and remove member functions here.
		//    DO NOT EDIT what you see in these blocks of generated code !
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};


/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Developer Studio will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_GRIDTEST_H__264C0797_437C_11D2_8C55_000000000000__INCLUDED_)
