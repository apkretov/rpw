// CGridCtrl.cpp : implementation file
//

#include "stdafx.h"
#include "CGridCtrl.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif


/////////////////////////////////////////////////////////////////////////////
// CGridCtrl
IMPLEMENT_DYNCREATE(CGridCtrl, CWnd)

//***************************************************************************
// CONSTRUCTOR: CGridCtrl::CGridCtrl
//***************************************************************************
CGridCtrl::CGridCtrl()
{
    m_pToolTip = NULL;

    m_nNumColumns  = 0;
    m_nNumRows     = 0;
    m_nColHeadLen  = 0;
    m_nXTableStart = 0;
    m_nYTableStart = 0;
    m_nCharHeight  = 0;
    m_nColWidth    = 0;
    m_nTotalWidth  = 0;
    m_nTotalHeight = 0;
    m_nFontSize    = 12;
    m_strFontName  = _T("Arial");
}


//***************************************************************************
// DESTRUCTOR: CGridCtrl::~CGridCtrl
//***************************************************************************
CGridCtrl::~CGridCtrl()
{
    // Remove any grid data that has been created.
    for(int i=0; i<m_arGridData.GetSize(); i++)
    {
        delete m_arGridData.GetAt(i);
    }

    if (m_pToolTip)
    {
        delete (m_pToolTip);
        m_pToolTip = NULL;
    }
}


BEGIN_MESSAGE_MAP(CGridCtrl, CWnd)
	//{{AFX_MSG_MAP(CGridCtrl)
	ON_WM_PAINT()
	ON_WM_LBUTTONDOWN()
	ON_WM_VSCROLL()
	ON_WM_HSCROLL()
	ON_WM_MOUSEWHEEL()
	ON_WM_MOUSEMOVE()
	ON_WM_ENABLE()
	//}}AFX_MSG_MAP
	ON_NOTIFY_EX_RANGE(TTN_NEEDTEXT,0,0xFFFF,OnToolTipNotify)
END_MESSAGE_MAP()


//***************************************************************************
// METHOD: CGridCtrl::CreateDrawingFonts
//
//  This method creates the drawing fonts if they have not already been
//  created.
//***************************************************************************
void CGridCtrl::CreateDrawingFonts()
{
    // If the fonts have already been created, the is nothing to do!
    if(!m_fntPrint.m_hObject)
    {
        // Create new drawing font.
        m_fntPrint.CreateFont(-m_nFontSize, 0, 0, 0, 400, 
                              FALSE, FALSE, 0, 
                              ANSI_CHARSET, OUT_TT_PRECIS,
                              CLIP_TT_ALWAYS | CLIP_LH_ANGLES, 
                              DEFAULT_QUALITY, 
                              FF_MODERN | TMPF_TRUETYPE, 
                              m_strFontName);

        // Create new rotated font.
        m_fntRotate.CreateFont(-m_nFontSize + 2, 0, 450, 450, 200, 
                               FALSE, FALSE, 0, 
                               ANSI_CHARSET, OUT_TT_PRECIS,
                               CLIP_TT_ALWAYS | CLIP_LH_ANGLES, 
                               DEFAULT_QUALITY, 
                               FF_MODERN | TMPF_TRUETYPE,
                               m_strFontName);

        // Create new Windings font for the check marks.
        m_fntCheck.CreateFont(-m_nFontSize - 2, 0, 0, 0, 800, 
                              FALSE, FALSE, 0, 
                              DEFAULT_CHARSET, OUT_TT_PRECIS,
                              CLIP_TT_ALWAYS | CLIP_LH_ANGLES, 
                              DEFAULT_QUALITY, 
                              FF_MODERN | TMPF_TRUETYPE, 
                              _T("Wingdings") );
    }
} // end CreateDrawingFonts


//***************************************************************************
// METHOD: CGridCtrl::Initialize
//
//  Used to Initialize all of the drawing data used to draw the control.
//***************************************************************************
void CGridCtrl::Initialize()
{
    // Create the drawing fonts if needed.
    CreateDrawingFonts();

   	// Create a device context used to determine our grid dimensions.
    CPaintDC dc(this); // device context for painting
    CFont* pOldFont = dc.SelectObject(&m_fntPrint);
    
    // Get the metrics of our fonts.
    TEXTMETRIC tm;
    dc.GetTextMetrics(&tm);

    // Loop to determine how large our row header has to be.
    int nRowLength = 0;
    for(POSITION pos = m_listRows.GetHeadPosition(); 
        pos != NULL; 
        m_listRows.GetNext(pos))
	{
        CSize size = dc.GetTextExtent( m_listRows.GetAt(pos) );
        if(size.cx > nRowLength) nRowLength = size.cx;
    }

    // Loop to determine how large our column header has to be.
    dc.SelectObject(&m_fntRotate);
    int nColumnLength = 0;
    for(pos = m_listColumns.GetHeadPosition(); 
        pos != NULL; 
        m_listColumns.GetNext(pos))
	{
        CSize size = dc.GetTextExtent( m_listColumns.GetAt(pos) );
        if(size.cx > nColumnLength) nColumnLength = size.cx;
    }

    
    // Define drawing variables
    m_nNumColumns  = m_listColumns.GetCount();
    m_nNumRows     = m_listRows.GetCount();
    m_nColHeadLen  = nColumnLength + tm.tmAveCharWidth;
    m_nXTableStart = nRowLength + tm.tmAveCharWidth * 2;
    m_nYTableStart = m_nColHeadLen;  
    m_nCharHeight  = tm.tmHeight;
    m_nColWidth    = m_nCharHeight + 5;

    // Figure out the total height and width of the grid.
    m_nTotalWidth  = m_nXTableStart + (m_nColWidth * m_nNumColumns) + 
                     m_nColHeadLen + GetSystemMetrics(SM_CXVSCROLL);
    m_nTotalHeight = m_nYTableStart + (m_nColWidth * m_nNumRows) + 
                     GetSystemMetrics(SM_CYHSCROLL);

    // Set up the scroll bars using our drawing variables.
    SetupScrollBars();
    
    // Create the tooltips for this window.
    CreateTooltips();

    // Clean up the dc.
    dc.SelectObject(pOldFont);
}


//***************************************************************************
// METHOD: CGridCtrl::SetupScrollBars
//
//  This method determines the size of the scroll bars needed for the
//  control and displays them.
//***************************************************************************
void CGridCtrl::SetupScrollBars()
{
    // Get the bounding rect for the window.
    CRect rect;
    GetClientRect(rect);
    
    // Define a SCROLLINFO struct for setting up our horizontal scroll bar.
    SCROLLINFO si;
    si.cbSize = sizeof(SCROLLINFO);
    si.fMask = SIF_ALL;
    
    si.nMin = 0;
    si.nMax = m_nTotalWidth;
    si.nPage = rect.Width();
    si.nPos = 0;

    //
    // If the width of our grid is wider than the window, we need
    // a horizontal scroll bar.
    //
    if(rect.Width() < m_nTotalWidth)
    {
        EnableScrollBarCtrl(SB_HORZ);
    }
    else // No scroll bar is needed.
    {
        si.nMax = 0;
        m_nTotalWidth = rect.Width();
    }
    SetScrollInfo(SB_HORZ, &si);

    // Redefine our SCROLLINFO struct for setting up our vertical scroll bar.
    si.nMin = 0;
    si.nMax = m_nTotalHeight;
    si.nPage = rect.Height();
    si.nPos = 0;

    //
    // If the height of our grid is taller than the window, we need
    // a vertical scroll bar.
    //
    if(rect.Height() < m_nTotalHeight)
    {
        EnableScrollBarCtrl(SB_VERT);
    }
    else
    {
        si.nMax = 0;
        m_nTotalHeight = rect.Height();
    }
    SetScrollInfo(SB_VERT, &si);

} // end SetupScrollBars


//***************************************************************************
// METHOD: CGridCtrl::CreateTooltips
//
//  Creates the tool tip control if needed.
//***************************************************************************
void CGridCtrl::CreateTooltips()
{
    if (m_pToolTip == NULL)
    {
        //
        // Create the tooltip control and set the tool rectangle to be the
        // whole window rectangle.  This will cause the tooltip control to
        // request text whenever the mouse stops over the grid window.
        //
        CRect rect;
        GetClientRect(rect);
        
        // create a tooltip control
        m_pToolTip = new CToolTipCtrl;
        if(!m_pToolTip)
        {
            MessageBox(_T("Unable to allocate memory for ToolTips!"));
        }
        else
        {
            if( !m_pToolTip->Create(this, TTS_ALWAYSTIP) )
            {   
                MessageBox(_T("Unable to Create ToolTips for Grid!"));
            }
            else
            {
                m_pToolTip->AddTool(this, LPSTR_TEXTCALLBACK, rect, 1);
                m_pToolTip->Activate(TRUE);

                // Send message to extend the life of the tooltips.
                m_pToolTip->SendMessage(TTM_SETDELAYTIME,
                                        TTDT_AUTOPOP,
                                        30000);
                EnableToolTips(TRUE);
            }
        }
    }
} // end CreateTooltips


//***************************************************************************
// METHOD: CGridCtrl::CreateOutputBitmap
//
//  Creates the tool tip control if needed.
//***************************************************************************
void CGridCtrl::CreateOutputBitmap(CDC* pDC)
{
    CString    strTemp;

    //
    // First save the state of the device context
    // so that it can be restored later.
    //
    int nSavedDC = pDC->SaveDC();
    ASSERT(nSavedDC);
    
    // Get the windows drawing rectangle.
    CRect rect;
    GetClientRect(rect);

	//
    // Fill the entire window with the solid background color
    // of the system color based on if the window is enabled or
	// disabled.
    //
    COLORREF crWindow = IsWindowEnabled() ? GetSysColor(COLOR_WINDOW) :
										    GetSysColor(COLOR_3DFACE);
	CRect rectBitmap(0, 0, m_nTotalWidth, m_nTotalHeight);
    CBrush brush(crWindow);
	pDC->FillRect(rectBitmap, &brush);
    
    // Set up drawing modes for drawing in the column headers.
    CPen pen( PS_SOLID, 1, GetSysColor(COLOR_WINDOWTEXT) );
	pDC->SelectObject(&pen);
    pDC->SetTextColor( GetSysColor(COLOR_WINDOWTEXT) );
	pDC->SelectObject(&m_fntRotate);
    pDC->SetBkMode(TRANSPARENT);
    pDC->SetTextAlign(TA_LEFT | TA_BOTTOM);
    
    // Determine our drawing offsets based on the scroll positions.
    int nXOffset = -GetScrollPos(SB_HORZ);
    int nYOffset = -GetScrollPos(SB_VERT);
    
    //
    // We'll need to determine the first row and column that
    // will be visible in the grid.  This is where we'll start drawing.
    //
    int nStartRow;
    int nStartColumn;
    GetIndexPosOfCursor(CPoint(-m_nColHeadLen,0), nStartColumn, nStartRow);
    if(nStartColumn < 0) nStartColumn = 0;
    if(nStartRow < 0)    nStartRow = 0;

    //
    // We'll need to determine the last row and column that
    // will be visible in the grid.  This is where we'll stop drawing.
    //
    int nEndRow;
    int nEndColumn;
    GetIndexPosOfCursor(CPoint(rect.Width(),rect.Height()), nEndColumn, nEndRow);
    if(nEndColumn < 0) nEndColumn = m_nNumColumns - 1;
    if(nEndRow < 0) nEndRow = m_nNumRows - 1;
    
    // Print the lines at the top
    int nXPoint = nXOffset + m_nXTableStart;
    int nYPoint = nYOffset;
    

    // Only draw the column header if it is visible.
    if(m_nColHeadLen + nYOffset >= 0)
    {
        // Draw the Column Header Top Line
        pDC->MoveTo(nXPoint + m_nColHeadLen, nYPoint);  
        pDC->LineTo( nXPoint + (m_nColWidth * m_nNumColumns) + m_nColHeadLen,
                     nYPoint );
        nYPoint += m_nColHeadLen;

        nXPoint += (m_nColWidth * nStartColumn);

        // Draw the text in the Column Header
        for(int i=nStartColumn; i<=nEndColumn; i++)
        {
		    POSITION pos = m_listColumns.FindIndex(i);
            strTemp = m_listColumns.GetAt(pos);
    
            pDC->TextOut(nXPoint + m_nColWidth + 1, nYPoint, strTemp);
    
            pDC->MoveTo(nXPoint, nYPoint);
            pDC->LineTo( (nXPoint + m_nColHeadLen), (nYPoint - m_nColHeadLen) );
    
            nXPoint += m_nColWidth;
        }
    
        // Draw the Column Header Right Slanted Line
        pDC->MoveTo(nXPoint, nYPoint);
        pDC->LineTo( (nXPoint + m_nColHeadLen), (nYPoint - m_nColHeadLen) );
    }
    else
    {
        nYPoint += m_nColHeadLen;
    }

    
    // Set up drawing modes for drawing in the row headers.
    pDC->SelectObject(&m_fntPrint);
    pDC->SetTextAlign(TA_LEFT | TA_TOP);
    nXPoint = nXOffset + 5;
    nYPoint += (m_nCharHeight + 5) * nStartRow;
    
    // Only draw in the row names if it is visible.
    if(m_nXTableStart + nXOffset >= 0)
    {
        // Draw in the row names on the left.
        for(int i=nStartRow; i<=nEndRow; i++)
	    {
		    pDC->MoveTo(0, nYPoint);  
            pDC->LineTo(nXOffset + m_nXTableStart + (m_nColWidth * m_nNumColumns), nYPoint);
        
            nYPoint += 5;
        
            POSITION pos = m_listRows.FindIndex(i);
            strTemp = m_listRows.GetAt(pos);

            pDC->TextOut(nXPoint, nYPoint, strTemp);
	        nYPoint += m_nCharHeight;
        }
    }
    else
    {
        // Draw in the row lines.
        for(int i=nStartRow; i<=nEndRow; i++)
	    {
		    pDC->MoveTo(0, nYPoint);  
            pDC->LineTo(nXOffset + m_nXTableStart + (m_nColWidth * m_nNumColumns), nYPoint);
        
	        nYPoint += m_nCharHeight + 5;
        }
    }


    // Draw the Bottom line
    pDC->MoveTo(0, nYPoint);  
    pDC->LineTo(nXOffset + m_nXTableStart + (m_nColWidth * m_nNumColumns), nYPoint);
    
    // Draw the Column separator lines
    nXPoint = nXOffset + m_nXTableStart + (m_nColWidth * nStartColumn);
    for (int nCol = nStartColumn; nCol <= nEndColumn + 1; nCol++)
    {
	    pDC->MoveTo(nXPoint, nYPoint);  
        pDC->LineTo(nXPoint, nYOffset + m_nYTableStart);
        nXPoint += m_nColWidth;
    }
    
    // Draw the line on the left side of the row names
    pDC->MoveTo(0, nYPoint);  
    pDC->LineTo(0, nYOffset + m_nYTableStart);
    
    // Select font for putting the check marks in.
    pDC->SelectObject(&m_fntCheck);

    ASSERT(m_arGridData.GetSize() == m_nNumRows);
    
    // For each visible row in the grid...
    for(int nRow=nStartRow; nRow <= nEndRow; nRow++)
	{
        // Get it's array of data.
        CByteArray* pArray = (CByteArray*)m_arGridData.GetAt(nRow);
        ASSERT(pArray->GetSize() == m_nNumColumns);

        // for each visible column in the grid...
        for (int nCol = nStartColumn; nCol <= nEndColumn; nCol++)
	    {
            //
            // If the array item corresponding to this row and column
            // has other than NO_MARK, draw in the desired mark.
            //
            // NOTE: currently we only draw in check marks.
            //
            if (pArray->GetAt(nCol) != NO_MARK)
            {
                // Insert the mark in the proper place
                nXPoint = nXOffset + m_nXTableStart + m_nColWidth * nCol;
                nYPoint = nYOffset + m_nYTableStart + m_nColWidth * nRow;
   
                //
                // This is a Check Mark using a font called WINGDINGS.
                // WINGDINGS is a Windows font.
                //
                pDC->TextOut( nXPoint + 5,
                              nYPoint + 5,
                              _T("�") );
            } // End if  
    
        } // End For
 
    } // End For    

    // Restore the dc.
    pDC->RestoreDC(nSavedDC);
    
} // end CreateOutputBitmap


//***************************************************************************
// METHOD: CGridCtrl::OnPaint
//
//  Called whenever the control needs to be painted.
//***************************************************************************
void CGridCtrl::OnPaint() 
{
    CString    strTemp;

   	CPaintDC dc(this); // device context for painting

    // Get the windows drawing rectangle.
    CRect rect;
    GetClientRect(rect);

    CBitmap bmOutput;
    // Create the output bitmap for the memory dc.
    bmOutput.CreateCompatibleBitmap(&dc, rect.Width(), rect.Height()) ; //m_nTotalWidth, m_nTotalHeight);

    // Create a compatible memory context for drawing.
    CDC dcMem;
    dcMem.CreateCompatibleDC(&dc);
	
    // Select the bitmap into the memory dc.
    CBitmap* pOldBitmap = dcMem.SelectObject(&bmOutput);

    CreateOutputBitmap(&dcMem);

    // Finally BitBlt the grid to the screen! Whew!
    dc.BitBlt(0, 0, rect.Width(), rect.Height(), &dcMem,
              0, 0, SRCCOPY);//GetScrollPos(SB_HORZ), GetScrollPos(SB_VERT), SRCCOPY);

    // Clean up the memory dc.
    dcMem.SelectObject(pOldBitmap);

} // end OnPaint


//***************************************************************************
// METHOD: CGridCtrl::AddColumn
//
//  Adds a new column to the grid. Reinitializes the drawing parameters
//  if flag is set.
//***************************************************************************
void CGridCtrl::AddColumn(CString strColumn, BOOL bReInitialize)
{
    // Add the new column name to our list of columns.
    m_listColumns.AddTail(strColumn);

    //
    // Since a new column has been added, we will need to add
    // one new entry to each row's array of data.
    //
    for(int i=0; i<m_arGridData.GetSize(); i++)
    {
        // Get this row's Array of check data.
        CByteArray* pArray = (CByteArray*)m_arGridData.GetAt(i);
        // Add a NO_MARK value to the end.
        pArray->Add(NO_MARK);
    }
    
    //
    // If the window has been created and we want to reinitialize
    // the grid variables...
    //
    if(m_hWnd && bReInitialize)
    {
        Initialize();
        Invalidate(FALSE);
    }

} // end AddColumn


//***************************************************************************
// METHOD: CGridCtrl::AddRow
//
//  Adds a new row to the grid. Reinitializes the drawing parameters
//  if flag is set.
//***************************************************************************
void CGridCtrl::AddRow(CString strRow, BOOL bReInitialize)
{
    // Add the new row name to our list of rows.
    m_listRows.AddTail(strRow);
    
    //
    // Since we have created a new row, we will need to add an
    // array of bytes for displaying the entry.  One Byte for
    // each column in the grid.
    //
    CByteArray* pArray = new CByteArray;
    pArray->SetSize( m_listColumns.GetCount() );
    for(int i=0; i<pArray->GetSize(); i++)
    {
        pArray->SetAt(i, 0);
    }
    
    // Add the new array to the end of the grid data.
    m_arGridData.Add(pArray);
    
    //
    // If the window has been created and we want to reinitialize
    // the grid variables...
    //
    if(m_hWnd && bReInitialize)
    {
        Initialize();
        Invalidate(FALSE);
    }

} // AddRow


//***************************************************************************
// METHOD: CGridCtrl::RenameColumn
//
//  Renames the column at the given index to the given string.
//***************************************************************************
BOOL CGridCtrl::RenameColumn(int nIndex, CString strColumn)
{
    // Get the position of the passed index.
    POSITION pos = m_listColumns.FindIndex(nIndex);
    //
    // If we've gotten a valid position, rename the string
    // corresponding to the column and redraw the grid.
    //
    if(pos)
    {
        m_listColumns.SetAt(pos, strColumn);

        if(m_hWnd)
        {
            Initialize();
            Invalidate(FALSE);
        }
        return TRUE;
    }
    
    // if we got this far, there was an invalid index passed in.
    return FALSE;

} // end RenameColumn


//***************************************************************************
// METHOD: CGridCtrl::RenameColumn
//
//  Renames the column with the given name to the given string.
//***************************************************************************
BOOL CGridCtrl::RenameColumn(CString strOld, CString strNew)
{
    // Find the position of the column with the passed name.
    POSITION pos = m_listColumns.Find(strOld);
    //
    // If we've gotten a valid position, rename the string
    // corresponding to the column and redraw the grid.
    //
    if(pos)
    {
        m_listColumns.SetAt(pos, strNew);

        if(m_hWnd)
        {
            Initialize();
            Invalidate(FALSE);
        }
        return TRUE;
    }
    
    // if we got this far, there was an invalid name passed in.
    return FALSE;

} // end RenameColumn


//***************************************************************************
// METHOD: CGridCtrl::RenameRow
//
//  Renames the row at the given index to the given string.
//***************************************************************************
BOOL CGridCtrl::RenameRow(int nIndex, CString strRow)
{
    // Get the position of the passed index.
    POSITION pos = m_listRows.FindIndex(nIndex);
    //
    // If we've gotten a valid position, rename the string
    // corresponding to the row and redraw the grid.
    //
    if(pos)
    {
        m_listRows.SetAt(pos, strRow);

        if(m_hWnd)
        {
            Initialize();
            Invalidate(FALSE);
        }
        return TRUE;
    }

    // if we got this far, there was an invalid index passed in.
    return FALSE;

} // end RenameRow


//***************************************************************************
// METHOD: CGridCtrl::RenameRow
//
//  Renames the row with the given name to the given string.
//***************************************************************************
BOOL CGridCtrl::RenameRow(CString strOld, CString strNew)
{
    // Find the position of the row with the passed name.
    POSITION pos = m_listRows.Find(strOld);
    //
    // If we've gotten a valid position, rename the string
    // corresponding to the row and redraw the grid.
    //
    if(pos)
    {
        m_listRows.SetAt(pos, strNew);

        if(m_hWnd)
        {
            Initialize();
            Invalidate(FALSE);
        }
        return TRUE;
    }

    // if we got this far, there was an invalid name passed in.
    return FALSE;

} // end RenameRow


//***************************************************************************
// METHOD: CGridCtrl::DeleteColumn
//
//  Removes the column at the given index from the grid.
//***************************************************************************
BOOL CGridCtrl::DeleteColumn(int nIndex)
{
    // Get the position of the passed index.
    POSITION pos = m_listColumns.FindIndex(nIndex);

    // If we've gotten a valid position...
    if(pos)
    {
        // Remove the colmun name from the position.
        m_listColumns.RemoveAt(pos);

        //
        // For each row, we need to remove all of the grid data
        // corresponding to this column.
        //
        for(int i=0; i<m_arGridData.GetSize(); i++)
        {
            CByteArray* pArray = (CByteArray*)m_arGridData.GetAt(i);
            pArray->RemoveAt(nIndex);
        }

        // Initialize and redraw the grid if needed.
        if(m_hWnd)
        {
            Initialize();
            Invalidate(FALSE);
        }
        
        return TRUE; // return success.
    }

    // if we got this far, there was an invalid index passed in.
    return FALSE;

} // end DeleteColumn


//***************************************************************************
// METHOD: CGridCtrl::DeleteColumn
//
//  Removes the column with the given name from the grid.
//***************************************************************************
BOOL CGridCtrl::DeleteColumn(CString strColumn)
{
    // Find the position of the column with the passed name.
    POSITION pos = m_listColumns.Find(strColumn);

    // If we've gotten a valid position...
    if(pos)
    {
        // Loop to determine the index of the column.
        POSITION pos2 = pos;
        for(int nIndex = 0; pos2 != NULL; nIndex++)
        {
            m_listColumns.GetPrev(pos2);
        } 
        nIndex--;

        //
        // For each row, we need to remove all of the grid data
        // corresponding to this column.
        //
        for(int i=0; i<m_arGridData.GetSize(); i++)
        {
            CByteArray* pArray = (CByteArray*)m_arGridData.GetAt(i);
            pArray->RemoveAt(nIndex);
        }

        // Remove the colmun name from the position.
        m_listColumns.RemoveAt(pos);

        // Initialize and redraw the grid if needed.
        if(m_hWnd)
        {
            Initialize();
            Invalidate(FALSE);
        }

        return TRUE; // return success.
    }

    // if we got this far, there was an invalid name passed in.
    return FALSE;

} // end DeleteColumn


//***************************************************************************
// METHOD: CGridCtrl::DeleteRow
//
//  Removes the row at the given index from the grid.
//***************************************************************************
BOOL CGridCtrl::DeleteRow(int nIndex)
{
    // Get the position of the passed index.
    POSITION pos = m_listRows.FindIndex(nIndex);
    
    // If we've gotten a valid position...
    if(pos)
    {
        // Remove the row name from the position.
        m_listRows.RemoveAt(pos);

        // Delete the grid data array corresponding to this row.
        CByteArray* pArray = (CByteArray*)m_arGridData.GetAt(nIndex);
        m_arGridData.RemoveAt(nIndex);
        delete pArray;

        // Initialize and redraw the grid if needed.
        if(m_hWnd)
        {
            Initialize();
            Invalidate(FALSE);
        }

        return TRUE; // return success.
    }

    // if we got this far, there was an invalid index passed in.
    return FALSE;

} // end DeleteRow


//***************************************************************************
// METHOD: CGridCtrl::DeleteRow
//
//  Removes the row with the given name from the grid. 
//***************************************************************************
BOOL CGridCtrl::DeleteRow(CString strRow)
{
    // Find the position of the row with the passed name.
    POSITION pos = m_listRows.Find(strRow);

    // If we've gotten a valid position...
    if(pos)
    {
        // Loop to determine the index of the row.
        POSITION pos2 = pos;
        for(int nIndex = 0; pos2 != NULL; nIndex++)
        {
            m_listColumns.GetPrev(pos2);
        } 
        nIndex--;

        // Delete the grid data array corresponding to this row.
        CByteArray* pArray = (CByteArray*)m_arGridData.GetAt(nIndex);
        m_arGridData.RemoveAt(nIndex);
        delete pArray;

        // Remove the row name from the position.
        m_listRows.RemoveAt(pos);

        // Initialize and redraw the grid if needed.
        if(m_hWnd)
        {
            Initialize();
            Invalidate(FALSE);
        }

        return TRUE; // return success.
    }

    // if we got this far, there was an invalid index passed in.
    return FALSE;

} // end DeleteRow


//***************************************************************************
// METHOD: CGridCtrl::SetFontStyle
//
//  Sets a new font style for text in the grid.  Redraws the control.
//***************************************************************************
void CGridCtrl::SetFontStyle(CString strFont)
{
    // Set the member variable.
    m_strFontName = strFont;
    
    // Delete all of the drawing fonts so they will be recreated.
    m_fntPrint.DeleteObject();
    m_fntRotate.DeleteObject();
    m_fntCheck.DeleteObject();

    // Initialize and redraw the grid if needed.
    if(m_hWnd)
    {
        Initialize();
        Invalidate(FALSE);
    }
} // end SetFontStyle


//***************************************************************************
// METHOD: CGridCtrl::SetFontSize
//
//  Sets a new font size for text in the grid.  Redraws the control.
//***************************************************************************
void CGridCtrl::SetFontSize(int nHeight)
{
    // Set the member variable.
    m_nFontSize = nHeight;
    
    // Delete all of the drawing fonts so they will be recreated.
    m_fntPrint.DeleteObject();
    m_fntRotate.DeleteObject();
    m_fntCheck.DeleteObject();

    // Initialize and redraw the grid if needed.
    if(m_hWnd)
    {
        Initialize();
        Invalidate(FALSE);
    }
} // end SetFontSize


//***************************************************************************
// METHOD: CGridCtrl::ToggleCheck
//
//  Toggle the check mark on and off at the given column and row indexes.
//***************************************************************************
void CGridCtrl::ToggleCheck(int nColumn, int nRow)
{
    // If we have a valid row and column
    if( nColumn >= 0 && nColumn < m_nNumColumns &&
        nRow >= 0 && nRow < m_nNumRows )
    {
        // Get the GridData for the row.
        CByteArray* pArray = (CByteArray*)m_arGridData.GetAt(nRow);
        
        // If there is a check mark in the given column, turn it off.
        if( pArray->GetAt(nColumn) == CHECK_MARK )
        {
            pArray->SetAt(nColumn, NO_MARK);
        }
        else // Add a check mark
        {
            pArray->SetAt(nColumn, CHECK_MARK);
        }

        // Redraw the window if needed.
        if(m_hWnd) Invalidate(FALSE);
    }
} // end ToggleCheck


//***************************************************************************
// METHOD: CGridCtrl::IsChecked
//
//   Returns TRUE if the given column and row are checked. FALSE otherwise.
//***************************************************************************
BOOL CGridCtrl::IsChecked(int nColumn, int nRow)
{
    // If we have a valid row and column
    if( nColumn >= 0 && nColumn < m_nNumColumns &&
        nRow >= 0 && nRow < m_nNumRows )
    {
        // Get the GridData for the row.
        CByteArray* pArray = (CByteArray*)m_arGridData.GetAt(nRow);
        return( pArray->GetAt(nColumn) == CHECK_MARK );
    }
    
    return FALSE;

} // end IsChecked


//***************************************************************************
// METHOD: CGridCtrl::OnLButtonDown
//
//  Called when the left mouse button is pressed while on the control.
//  Determines what box tthe cursor is on and toggles a check mark on
//  or off of that box.
//***************************************************************************
void CGridCtrl::OnLButtonDown(UINT nFlags, CPoint point) 
{
    int nXIndex;
    int nYIndex;

    // Get the index positions of the cursor.
    GetIndexPosOfCursor(point, nXIndex, nYIndex);

    // Add or remove the check mark.
    ToggleCheck(nXIndex, nYIndex);

    CWnd::OnLButtonDown(nFlags, point);

} // end OnLButtonDown


//***************************************************************************
// METHOD: CGridCtrl::Serialize
//
//  Used to store or load a grid to/from a data file.
//***************************************************************************
void CGridCtrl::Serialize(CArchive& ar)
{
    if (ar.IsStoring())
    {
        // Store the font properties
        ar << m_strFontName;
        ar << m_nFontSize;

        // Store all of the row names.
        ar << m_listRows.GetCount();
        for(POSITION pos = m_listRows.GetHeadPosition(); 
            pos != NULL; 
            m_listRows.GetNext(pos))
	    {
            ar << m_listRows.GetAt(pos);
        }

        // Store all of the column names.
            ar << m_listColumns.GetCount();
        for(pos = m_listColumns.GetHeadPosition(); 
            pos != NULL; 
            m_listColumns.GetNext(pos))
	    {
            ar << m_listColumns.GetAt(pos);
        }

        // Store all of the grid data.
        ar << m_arGridData.GetSize();
        for(int nRow=0; nRow < m_arGridData.GetSize(); nRow++)
	    {
            CByteArray* pArray = (CByteArray*)m_arGridData.GetAt(nRow);
            ar << pArray->GetSize();
            for (int nCol = 0; nCol < pArray->GetSize(); nCol++)
	        {
                ar << pArray->GetAt(nCol);
            }
        }
    }
    else // Load the Data
    {
        // Clean up any data that may currently be loaded
        for(int i=0; i<m_arGridData.GetSize(); i++)
        {
            delete m_arGridData.GetAt(i);
        }
        m_arGridData.RemoveAll();
        m_listRows.RemoveAll();
        m_listColumns.RemoveAll();

        // Load the font properties
        ar >> m_strFontName;
        ar >> m_nFontSize;

        // Load all of the row names.
        int nNumRows;
        ar >> nNumRows;
        for(i=0; i<nNumRows; i++)
	    {
            CString str;
            ar >> str;
            m_listRows.AddTail(str);
        }

        // Load all of the column names.
        int nNumColumns;
        ar >> nNumColumns;
        for(i=0; i<nNumColumns; i++)
	    {
            CString str;
            ar >> str;
            m_listColumns.AddTail(str);
        }

        // Loadd all of the grid data.
        int nGridSize;
        ar >> nGridSize;
        m_arGridData.SetSize(nGridSize);
        for(int nRow=0; nRow < nGridSize; nRow++)
	    {
            int nArraySize;
            ar >> nArraySize;
            CByteArray* pArray = new CByteArray;
            pArray->SetSize(nArraySize);
            m_arGridData.SetAt(nRow, pArray);
            for (int nCol = 0; nCol < nArraySize; nCol++)
	        {
                BYTE byte;
                ar >> byte;
                pArray->SetAt(nCol, byte);
            }
        }

        // If needed reinitialize and redraw the grid
        if(m_hWnd)
        {
            Initialize();
            Invalidate(FALSE);
        }
    }
} // end Serialize


//***************************************************************************
// METHOD: CGridCtrl::PreTranslateMessage
//
//  Used to remove the tool tip if the mouse is moved.
//***************************************************************************
BOOL CGridCtrl::PreTranslateMessage(MSG* pMsg) 
{
    switch(pMsg->message)
    {
        case WM_LBUTTONDOWN:
        case WM_MOUSEMOVE:
        case WM_LBUTTONUP:
        case WM_MBUTTONDOWN:
        case WM_MBUTTONUP:
        case WM_RBUTTONDOWN:
        case WM_RBUTTONUP:

        if (m_pToolTip)
        {
            CPoint ptCurrentPos;

            //
            // offset the current position by the
            // amount the window is scrolled
            //
            ptCurrentPos.x = LOWORD(pMsg->lParam);
            ptCurrentPos.y = HIWORD(pMsg->lParam);
        
            //
            // If the cursor move off of the tool then deactivate the
            // tooltip so that the text disappears.  This allows us to 
            // move the mouse over different points on a tool and have
            // a different text message appear
            //
            if (m_rectSearch.PtInRect(ptCurrentPos) == FALSE)
            {
                m_pToolTip->Activate(FALSE);
            }

            // this will reactivate the tooltip
            m_pToolTip->Activate(TRUE);
            m_pToolTip->RelayEvent(pMsg);
        }
    }

    return CWnd::PreTranslateMessage(pMsg);

} // end PreTranslateMessage


//***************************************************************************
// METHOD: CGridCtrl::OnToolTipNotify
//***************************************************************************
BOOL CGridCtrl::OnToolTipNotify(UINT    id, 
                                NMHDR   *pNMH, 
                                LRESULT *pResult) 
{
    LPTOOLTIPTEXT lpttt; 

    lpttt = (LPTOOLTIPTEXT)pNMH; 

    // Set the text to empty
    lpttt->szText[0] = '\0';

    POINT  ptCurrentPos;

    GetCursorPos(&ptCurrentPos);
    ScreenToClient(&ptCurrentPos);

    //
    // The m_rectSearch member variable is used to determine
    // when the mouse has moved far enough to kill the tooltip.
    //
    m_rectSearch.SetRect(ptCurrentPos.x - 3,
                         ptCurrentPos.y - 3,
                         ptCurrentPos.x + 3,
                         ptCurrentPos.y + 3);

    // Format the Detail string.
    CString strDetails = GetDetailString(ptCurrentPos);

    // Display the Tooltip if necessary.
    if (!strDetails.IsEmpty())
    {
        strcpy(lpttt->szText, (LPCTSTR)strDetails); 
    }

    return FALSE;

} // end OnToolTipNotify


//***************************************************************************
// METHOD: CGridCtrl::GetDetailString
//
//  Gets the string to display on the tool tip.
//***************************************************************************
CString CGridCtrl::GetDetailString(CPoint pt)
{
    CString strDetails;

    int nXIndex;
    int nYIndex;

    // Get the indexes of the point.
    GetIndexPosOfCursor(pt, nXIndex, nYIndex);
    
    // If the tool tip is over the grid...
    if(nXIndex >= 0 && nYIndex >= 0)
    {
        // Create the text for display.
        POSITION pos1 = m_listColumns.FindIndex(nXIndex);
        POSITION pos2 = m_listRows.FindIndex(nYIndex);
        strDetails = m_listRows.GetAt(pos2) +
                     _T(" --- ") +
                     m_listColumns.GetAt(pos1);
    }
    
    return strDetails;

} // end GetDetailString



//***************************************************************************
// METHOD: CGridCtrl::GetIndexPosOfCursor
//
//  Determines what X and Y index the given point is over.
//***************************************************************************
void CGridCtrl::GetIndexPosOfCursor(CPoint point, int& nXIndex, int& nYIndex) 
{
    nXIndex = (point.x - m_nXTableStart + GetScrollPos(SB_HORZ)) / m_nColWidth;
    nYIndex = (point.y - m_nYTableStart + GetScrollPos(SB_VERT)) / m_nColWidth;

    if(nXIndex >= m_nNumColumns) nXIndex = -1;
    if(nYIndex >= m_nNumRows)    nYIndex = -1;

} // end GetIndexPosOfCursor


//***************************************************************************
// METHOD: CGridCtrl::OnVScroll
//
//  Called to scroll the grid vertically.
//***************************************************************************
void CGridCtrl::OnVScroll(UINT nSBCode, UINT nPos, CScrollBar* pScrollBar) 
{
    // Get the curent scroll position
    int nCurPos = GetScrollPos(SB_VERT);
    
    // Get the window's rectangle.
    CRect rect;
    GetClientRect(rect);

    // Scroll based on the code.
    switch (nSBCode)
    {
    case SB_LINEUP:
        SetScrollPos(SB_VERT, nCurPos - m_nColWidth);
        break;
    case SB_LINEDOWN:
        SetScrollPos(SB_VERT, nCurPos + m_nColWidth);
        break;
    case SB_PAGEUP:
        SetScrollPos(SB_VERT, nCurPos - rect.Height());
        break;
    case SB_PAGEDOWN:
        SetScrollPos(SB_VERT, nCurPos + rect.Height());
        break;
    case SB_THUMBPOSITION:
        SetScrollPos(SB_VERT, nPos);
        break;
    case SB_THUMBTRACK:
        SetScrollPos(SB_VERT, nPos);
        break;
    };

    // Redraw the grid
    Invalidate(FALSE);
	
    CWnd::OnVScroll(nSBCode, nPos, pScrollBar);

} // end OnVScroll


//***************************************************************************
// METHOD: CGridCtrl::OnHScroll
//
//  Called to scroll the grid horizontally.
//***************************************************************************
void CGridCtrl::OnHScroll(UINT nSBCode, UINT nPos, CScrollBar* pScrollBar) 
{
    // Get the curent scroll position
    int nCurPos = GetScrollPos(SB_HORZ);

    // Get the window's rectangle.
    CRect rect;
    GetClientRect(rect);
    
    // Scroll based on the code.
    switch (nSBCode)
    {
    case SB_LINELEFT:
        SetScrollPos(SB_HORZ, nCurPos - m_nColWidth);
        break;
    case SB_LINERIGHT:
        SetScrollPos(SB_HORZ, nCurPos + m_nColWidth);
        break;
    case SB_PAGELEFT:
        SetScrollPos(SB_HORZ, nCurPos - rect.Width());
        break;
    case SB_PAGERIGHT:
        SetScrollPos(SB_HORZ, nCurPos + rect.Width());
        break;
    case SB_THUMBPOSITION:
        SetScrollPos(SB_HORZ, nPos);
        break;
    case SB_THUMBTRACK:
        SetScrollPos(SB_HORZ, nPos);
        break;
    };

    // Redraw the grid
    Invalidate(FALSE);

    CWnd::OnHScroll(nSBCode, nPos, pScrollBar);

} // end OnHScroll


//***************************************************************************
// METHOD: CGridCtrl::OnMouseWheel
//
//  Called when the mouse wheel is moved.
//***************************************************************************
BOOL CGridCtrl::OnMouseWheel(UINT nFlags, short zDelta, CPoint pt) 
{
    //
    // If the CTRL button is being held,
    // Scroll horizontally.
    //
    if(nFlags == MK_CONTROL)
    {
        if(zDelta < 0) OnHScroll(SB_LINERIGHT, 0, NULL);
        else           OnHScroll(SB_LINELEFT, 0, NULL);
    }
    else // Scroll Vertically
    {
        if(zDelta < 0) OnVScroll(SB_LINEDOWN, 0, NULL);
        else           OnVScroll(SB_LINEUP, 0, NULL);
    }
	
    return CWnd::OnMouseWheel(nFlags, zDelta, pt);

} // end OnMouseWheel


//***************************************************************************
// METHOD: CGridCtrl::OnMouseMove
//
//  Called when the mouse is moved over the window.
//***************************************************************************
void CGridCtrl::OnMouseMove(UINT nFlags, CPoint point) 
{
    // Grab the input focus so that we see the tool tips.
    SetFocus();
	
	CWnd::OnMouseMove(nFlags, point);

} // end OnMouseMove


//***************************************************************************
// METHOD: CGridCtrl::OnEnable
//
//  Called when the window is enabled or disabled.
//***************************************************************************
void CGridCtrl::OnEnable(BOOL bEnable) 
{
    // Do the default thing
    CWnd::OnEnable(bEnable);
	
    // Redraw the window so that we see the changes.
    Invalidate(FALSE);	
}
