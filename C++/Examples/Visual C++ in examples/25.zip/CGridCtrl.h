#if !defined(AFX_GRIDCTRL_H__6D781977_F19A_11D1_89CB_444553540000__INCLUDED_)
#define AFX_GRIDCTRL_H__6D781977_F19A_11D1_89CB_444553540000__INCLUDED_

#if _MSC_VER >= 1000
#pragma once
#endif // _MSC_VER >= 1000
// CGridCtrl.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// CGridCtrl window

class CGridCtrl : public CWnd
{
// Construction
public:
	CGridCtrl();
    DECLARE_DYNCREATE(CGridCtrl)

// Attributes
protected:
    CStringList m_listColumns;  // List of Column names
    CStringList m_listRows;     // List of Row names
    CObArray    m_arGridData;   // Array of CByteArrays used as 2D grid data

	CToolTipCtrl* m_pToolTip;
	CRect         m_rectSearch; // Rectangle for monitoring ToolTips.

    int     m_nFontSize;        // Size of the drawing fonts.
    CString m_strFontName;      // Style of the drawing fonts.

    // Drawing Fonts
    CFont m_fntPrint;
    CFont m_fntRotate;
    CFont m_fntCheck;

    int     m_nNumColumns;  // Number of columns
    int     m_nNumRows;     // Number of rows
    int     m_nColHeadLen;  // Length of column header
    int     m_nXTableStart; // X coordinate to start drawing the grid
    int     m_nYTableStart; // Y coordinate to start drawing the grid
    int     m_nCharHeight;  // Height of m_fntPrint.
    int     m_nColWidth;    // Width of each column
    int     m_nTotalWidth;  // Total width of the entire grid
    int     m_nTotalHeight; // Total height of the entire grid

    enum GRID_MARKS
    {
        NO_MARK = 0,
        CHECK_MARK
    };


// Operations
public:

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CGridCtrl)
	public:
	virtual BOOL PreTranslateMessage(MSG* pMsg);
	//}}AFX_VIRTUAL

// Implementation
public:
	virtual ~CGridCtrl();

    virtual void Serialize(CArchive& ar);
    void Initialize();
    
    void AddColumn(CString strColumn, BOOL bReInitialize = TRUE);
    void AddRow(CString strRow, BOOL bReInitialize = TRUE);
    
    BOOL RenameColumn(int nIndex, CString strColumn);
    BOOL RenameColumn(CString strOld, CString strNew);
    BOOL RenameRow(int nIndex, CString strRow);
    BOOL RenameRow(CString strOld, CString strNew);
    
    BOOL DeleteColumn(int nIndex);
    BOOL DeleteColumn(CString strColumn);
    BOOL DeleteRow(int nIndex);
    BOOL DeleteRow(CString strRow);

    void ToggleCheck(int nXIndex, int nYIndex);
    BOOL IsChecked(int nColumn, int nRow);

    int GetNumColumns() { return m_nNumColumns; }
    int GetNumRows() { return m_nNumRows; }

    void SetFontStyle(CString strFont);
    void SetFontSize(int nHeight);
    int  GetFontSize() { return m_nFontSize; }
    CString GetFontStyle() { return m_strFontName; }

private:
    void GetIndexPosOfCursor(CPoint point, int& nXIndex, int& nYIndex);
    CString GetDetailString(CPoint pt);
    void CreateDrawingFonts();
    void SetupScrollBars();
    void CreateTooltips();
    void CreateOutputBitmap(CDC* pDC);

    // Generated message map functions
protected:
	//{{AFX_MSG(CGridCtrl)
	afx_msg void OnPaint();
	afx_msg void OnLButtonDown(UINT nFlags, CPoint point);
	afx_msg void OnVScroll(UINT nSBCode, UINT nPos, CScrollBar* pScrollBar);
	afx_msg void OnHScroll(UINT nSBCode, UINT nPos, CScrollBar* pScrollBar);
	afx_msg BOOL OnMouseWheel(UINT nFlags, short zDelta, CPoint pt);
	afx_msg void OnMouseMove(UINT nFlags, CPoint point);
	afx_msg void OnEnable(BOOL bEnable);
	//}}AFX_MSG
	afx_msg BOOL OnToolTipNotify(UINT id, NMHDR *pNMH, LRESULT *pResult); 
	DECLARE_MESSAGE_MAP()
};

/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Developer Studio will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_GRIDCTRL_H__6D781977_F19A_11D1_89CB_444553540000__INCLUDED_)
