// GridTestDlg.cpp : implementation file
//

#include "stdafx.h"
#include "GridTest.h"
#include "CGridCtrl.h"
#include "GridTestDlg.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CGridTestDlg dialog

CGridTestDlg::CGridTestDlg(CWnd* pParent /*=NULL*/)
	: CDialog(CGridTestDlg::IDD, pParent)
{
	//{{AFX_DATA_INIT(CGridTestDlg)
	m_strName = _T("");
	//}}AFX_DATA_INIT
	// Note that LoadIcon does not require a subsequent DestroyIcon in Win32
	m_hIcon = AfxGetApp()->LoadIcon(IDR_MAINFRAME);
}

void CGridTestDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CGridTestDlg)
	DDX_Control(pDX, IDC_GRID, m_wndGrid);
	DDX_Text(pDX, IDC_NAME, m_strName);
	DDV_MaxChars(pDX, m_strName, 25);
	//}}AFX_DATA_MAP
}

BEGIN_MESSAGE_MAP(CGridTestDlg, CDialog)
	//{{AFX_MSG_MAP(CGridTestDlg)
	ON_WM_PAINT()
	ON_WM_QUERYDRAGICON()
	ON_BN_CLICKED(IDC_FONT, OnFont)
	ON_BN_CLICKED(IDC_ADD_COLUMN, OnAddColumn)
	ON_BN_CLICKED(IDC_ADD_ROW, OnAddRow)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CGridTestDlg message handlers

BOOL CGridTestDlg::OnInitDialog()
{
    CDialog::OnInitDialog();

	// Set the icon for this dialog.  The framework does this automatically
	//  when the application's main window is not a dialog
	SetIcon(m_hIcon, TRUE);			// Set big icon
	SetIcon(m_hIcon, FALSE);		// Set small icon
	
	// Attempt to load the grid from a previously saved File.
    CFile fileArchive;
    if (fileArchive.Open("GridTest.dat", CFile::modeRead))
    {
	    CArchive archive(&fileArchive, CArchive::load);

	    // Serialize the window state object
	    m_wndGrid.Serialize(archive);

	    archive.Close();
	    fileArchive.Close();
    }
    else // The file did not exist.  Do the default thing.
    {
        // Add all of the rows.
        m_wndGrid.AddRow("Broncos", FALSE);
        m_wndGrid.AddRow("Packers", FALSE);
        m_wndGrid.AddRow("Dolphins", FALSE);
        m_wndGrid.AddRow("Niners", FALSE);
        m_wndGrid.AddRow("Cowboys", FALSE);
        m_wndGrid.AddRow("Jets", FALSE);
        m_wndGrid.AddRow("Redskins", FALSE);
        m_wndGrid.AddRow("Colts", FALSE);
        m_wndGrid.AddRow("Bucaneers", FALSE);
        m_wndGrid.AddRow("Chiefs", FALSE);
        m_wndGrid.AddRow("Raiders", FALSE);
    
        // Add all of the columns
        m_wndGrid.AddColumn("Broncos", FALSE);
        m_wndGrid.AddColumn("Packers", FALSE);
        m_wndGrid.AddColumn("Dolphins", FALSE);
        m_wndGrid.AddColumn("Niners", FALSE);
        m_wndGrid.AddColumn("Cowboys", FALSE);
        m_wndGrid.AddColumn("Jets", FALSE);
        m_wndGrid.AddColumn("Redskins", FALSE);
        m_wndGrid.AddColumn("Colts", FALSE);
        m_wndGrid.AddColumn("Bucaneers", FALSE);
        m_wndGrid.AddColumn("Chiefs", FALSE);
        m_wndGrid.AddColumn("Raiders", TRUE);

        //
        // NOTE: the final call to create the last column passes
        // a TRUE value to initialize the grid and prepare it for
        // drawing.
        //

        // Set the check marks passing in the row and column.
        m_wndGrid.ToggleCheck(0, 1);
        m_wndGrid.ToggleCheck(1, 0);
        m_wndGrid.ToggleCheck(2, 3);

/*************************************************
// Test grid with large ammounts of data...

        for(int i=0; i<1500; i++)
        {
            CString str;
            str.Format("Column %d", i+1);
            m_wndGrid.AddColumn(str, FALSE);
        }
        for(i=0; i<1500; i++)
        {
            CString str;
            str.Format("Row %d", i+1);
            m_wndGrid.AddRow(str, FALSE);
        }
        m_wndGrid.Initialize();
        for(i=0; i<1500; i++)
            for(int j=0; j<1500; j++)
                m_wndGrid.ToggleCheck(j,i);
***************************************************/
    }

	return TRUE;  // return TRUE  unless you set the focus to a control
}

// If you add a minimize button to your dialog, you will need the code below
//  to draw the icon.  For MFC applications using the document/view model,
//  this is automatically done for you by the framework.

void CGridTestDlg::OnPaint() 
{
	if (IsIconic())
	{
		CPaintDC dc(this); // device context for painting

		SendMessage(WM_ICONERASEBKGND, (WPARAM) dc.GetSafeHdc(), 0);

		// Center icon in client rectangle
		int cxIcon = GetSystemMetrics(SM_CXICON);
		int cyIcon = GetSystemMetrics(SM_CYICON);
		CRect rect;
		GetClientRect(&rect);
		int x = (rect.Width() - cxIcon + 1) / 2;
		int y = (rect.Height() - cyIcon + 1) / 2;

		// Draw the icon
		dc.DrawIcon(x, y, m_hIcon);
	}
	else
	{
		CDialog::OnPaint();
	}
}

// The system calls this to obtain the cursor to display while the user drags
//  the minimized window.
HCURSOR CGridTestDlg::OnQueryDragIcon()
{
	return (HCURSOR) m_hIcon;
}

void CGridTestDlg::OnOK() 
{
    // Create the archive and open the file
	CFile fileArchive;
	if (fileArchive.Open("GridTest.dat", 
                         CFile::modeCreate | CFile::modeWrite))
	{
		CArchive archive(&fileArchive, CArchive::store);

		// Serialize the window state object
		m_wndGrid.Serialize(archive);

		archive.Close();
		fileArchive.Close();
	}

    CDialog::OnOK();
}

void CGridTestDlg::OnFont() 
{
	//
    // Set up the LOGFONT Structure to pass to the 
    // constructor of the font dialog.
    //
    // Divide the height in the registry by the LogFont conversion factor.
    // The registry stores the height for a CHARFORMAT structure, not a
    // LOGFONT structure, so we must convert it.
    //
	LOGFONT lf;
    lf.lfHeight = m_wndGrid.GetFontSize();
    lf.lfWidth = 0;
    lf.lfEscapement = 0;
    lf.lfOrientation = 0;
    lf.lfCharSet = ANSI_CHARSET;
    lf.lfPitchAndFamily = DEFAULT_PITCH | FF_DONTCARE;
    lf.lfOutPrecision = OUT_DEFAULT_PRECIS;
    lf.lfClipPrecision = CLIP_DEFAULT_PRECIS;
    lf.lfQuality = DEFAULT_QUALITY;
    lf.lfWeight = 400;
    lf.lfItalic = FALSE;
    lf.lfUnderline = FALSE;
    lf.lfStrikeOut = FALSE;
    
    ASSERT(m_wndGrid.GetFontStyle().GetLength() < LF_FACESIZE);
	lstrcpynA(lf.lfFaceName, m_wndGrid.GetFontStyle(), LF_FACESIZE);
	    
    // create the font dialog
    CFontDialog dlg(&lf);
	// Set the CHOOSEFONT flags to set the dialog box capabilities
	dlg.m_cf.Flags = CF_ENABLEHOOK |
                     CF_INITTOLOGFONTSTRUCT |
                     CF_FORCEFONTEXIST | 
                     CF_SCREENFONTS;                

    if( dlg.DoModal() == IDOK )
    {
        m_wndGrid.SetFontStyle( dlg.GetFaceName() );
        m_wndGrid.SetFontSize( (int)(dlg.GetSize() / 10) );
    }
}

void CGridTestDlg::OnAddColumn() 
{
	UpdateData(TRUE);
    m_wndGrid.AddColumn(m_strName);
    m_strName = "";
    UpdateData(FALSE);
}

void CGridTestDlg::OnAddRow() 
{
	UpdateData(TRUE);
    m_wndGrid.AddRow(m_strName);
    m_strName = "";
    UpdateData(FALSE);
}
