// ComboGridCtrl.cpp: implementation of the CComboGridCtrl class.
//
// This is a demo of how to override CGridCtrl in order to offer
// other editing capabilities such as a drop down list
//
//////////////////////////////////////////////////////////////////////

#include "stdafx.h"
#include "ComboGridCtrl.h"
#include "InPlaceList.h"

#ifdef _DEBUG
#undef THIS_FILE
static char THIS_FILE[]=__FILE__;
#define new DEBUG_NEW
#endif

BEGIN_MESSAGE_MAP(CComboGridCtrl, CGridCtrl)
    //{{AFX_MSG_MAP(CComboGridCtrl)
    //}}AFX_MSG_MAP
END_MESSAGE_MAP()


//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

CComboGridCtrl::CComboGridCtrl()
{
}

CComboGridCtrl::~CComboGridCtrl()
{
}

//////////////////////////////////////////////////////////////////////
// Overrides
//////////////////////////////////////////////////////////////////////

void CComboGridCtrl::CreateInPlaceEditControl(CRect& rect, DWORD dwStyle, UINT nID,
                                              int nRow, int nCol,
                                              LPCTSTR szText, int nChar)
{
	CStringArray Items;
    Items.Add("Choice 1");
    Items.Add("Choice 2");
    Items.Add("Choice 3");
    Items.Add("Choice 4");
    Items.Add("Choice 5");

	// InPlaceList and auto-deletes itself
	new CInPlaceList(this, rect,
                     //CBS_DROPDOWNLIST,    // Uncomment for dropdown list style
                     CBS_DROPDOWN,          // Uncomment for dropdown style
                     //CBS_SIMPLE,          // Uncomment for simple style
                     nID,                   // ID of control being created
                     nRow, nCol, 
                     Items, szText, nChar);
}
