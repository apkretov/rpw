// ObjDlg.cpp : implementation file
//

#include "stdafx.h"
#include "contain.h"
#include "ObjDlg.h"
#include "ObjNameSet.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CObjDlg dialog


CObjDlg::CObjDlg(CObjNameSet * pSet, CWnd* pParent /*=NULL*/)
	: CDialog(CObjDlg::IDD, pParent)
{
	//{{AFX_DATA_INIT(CObjDlg)
	m_ObjectName = _T("");
	//}}AFX_DATA_INIT
	m_pSet = pSet;
}


void CObjDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CObjDlg)
	DDX_LBString(pDX, IDC_OBJECTLIST, m_ObjectName);
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CObjDlg, CDialog)
	//{{AFX_MSG_MAP(CObjDlg)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CObjDlg message handlers

BOOL CObjDlg::OnInitDialog() 
{
	CDialog::OnInitDialog();
	
	ASSERT( m_pSet->IsOpen());

	CListBox * pList = static_cast<CListBox *>(GetDlgItem(IDC_OBJECTLIST));
	
	while (!m_pSet->IsEOF())
	{
		pList->AddString(m_pSet->m_Name);
		m_pSet->MoveNext();
	}

	pList->SetFocus();

	return FALSE;  
}
