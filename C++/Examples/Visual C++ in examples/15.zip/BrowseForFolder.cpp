// BrowseForFolder.cpp : Defines the class behaviors for the application.
//

#include "stdafx.h"
#include "BrowseForFolder.h"
#include "BrowseForFolderDlg.h"

#include <shlobj.h>

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CBrowseForFolderApp

BEGIN_MESSAGE_MAP(CBrowseForFolderApp, CWinApp)
	//{{AFX_MSG_MAP(CBrowseForFolderApp)
		// NOTE - the ClassWizard will add and remove mapping macros here.
		//    DO NOT EDIT what you see in these blocks of generated code!
	//}}AFX_MSG
	ON_COMMAND(ID_HELP, CWinApp::OnHelp)
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CBrowseForFolderApp construction

CBrowseForFolderApp::CBrowseForFolderApp()
{
	// TODO: add construction code here,
	// Place all significant initialization in InitInstance
}

/////////////////////////////////////////////////////////////////////////////
// The one and only CBrowseForFolderApp object

CBrowseForFolderApp theApp;

/////////////////////////////////////////////////////////////////////////////
// CBrowseForFolderApp initialization

BOOL CBrowseForFolderApp::InitInstance()
{
	// Standard initialization
	// If you are not using these features and wish to reduce the size
	//  of your final executable, you should remove from the following
	//  the specific initialization routines you do not need.

#ifdef _AFXDLL
	Enable3dControls();			// Call this when using MFC in a shared DLL
#else
	Enable3dControlsStatic();	// Call this when linking to MFC statically
#endif

	CBrowseForFolderDlg dlg;
	m_pMainWnd = &dlg;
	int nResponse = dlg.DoModal();
	if (nResponse == IDOK)
	{
		// TODO: Place code here to handle when the dialog is
		//  dismissed with OK
	}
	else if (nResponse == IDCANCEL)
	{
		// TODO: Place code here to handle when the dialog is
		//  dismissed with Cancel
	}

	// Since the dialog has been closed, return FALSE so that we exit the
	//  application, rather than start the application's message pump.
	return FALSE;
}

CString CBrowseForFolderApp::BrowseForFolder(HWND hWnd, LPCSTR lpszTitle, 
												UINT nFlags)
{
	// We are going to use the shell to display a "Choose Directory"
	// dialog for the user
	
	CString strResult = ""; // initially empty so we can return an empty string
								// as an error
	
	LPMALLOC lpMalloc;	// A pointer to IMalloc

	char szDisplayName[_MAX_PATH];
	char szBuffer[_MAX_PATH];

	// Get the Shell's default allocator
	if (::SHGetMalloc(&lpMalloc) != NOERROR)
		return strResult;	// failed to get Shell's allocator
	
	BROWSEINFO browseInfo;

	LPITEMIDLIST lpItemIDList;
	browseInfo.hwndOwner = hWnd;
	browseInfo.pidlRoot = NULL;
	browseInfo.pszDisplayName = szDisplayName;
	browseInfo.lpszTitle = lpszTitle;
	browseInfo.ulFlags = nFlags;
	browseInfo.lpfn = NULL;
	browseInfo.lParam = 0;

	// This next call displays the Browse For Folder dialog box
	if ((lpItemIDList = ::SHBrowseForFolder(&browseInfo)) != NULL)
	{
		if (::SHGetPathFromIDList(lpItemIDList, szBuffer))
		{
			// At this point szBuffer contains the path the user
			// chose
			
			if (szBuffer[0] == '\0')
			{
				AfxMessageBox(IDP_FAILED_GET_DIRECTORY,
					MB_ICONSTOP|MB_OK);

				return strResult;
			}

			strResult = szBuffer;
			return strResult;
		}
		else
		{
			// The thing referred to by lpItemIDList might
			// not have been a file system object.
			// For whatever reason, SHGetPathFromIDList
			// didn't work!
			AfxMessageBox(IDP_FAILED_GET_DIRECTORY,
				MB_ICONSTOP|MB_OK);
		}

		
		// Free the lpItemIDList allocated by SHBrowseForFolder()
		lpMalloc->Free(lpItemIDList);

		// Release the shell's allocator -- memory could leak if we don't
		lpMalloc->Release();
	}

	return strResult;
}
